---
title: "Information Sheet - PPE Pick Up & Distro - M4D/DA"
driveId: 1kBzZZnrkHrApV_BLqyjrid4SiJi7PFL5t9HB1SeaIao
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-07-28T16:36:22.066Z
---

Information Sheet:  
PPE Pick Up & Distribution  
Masks For Docs/Distribute Aid

  
This guide will detail methods for safe distribution and pickup of PPE during the current Covid-19 crisis in conjunction with [MasksForDocs protocols](https://www.google.com/url?q=https://masksfordocs.com/resources&sa=D&ust=1601935361885000&usg=AOvVaw3BluXZrxJQFkrkVq9brUd3)

Guide Outline:

PART I: General prevention measures during COVID-19

PART II: Distribution Guidelines

1.  Establish a safe method of distribution/pickup of PPE with recipient/provider.
2.  During the distribution/pickup: maintain safe social distancing and hand/respiratory hygiene.
3.  Measures to be taken following the distribution/pickup

PART III: Employee/Volunteer Safety

- Undocumented Workers
- Reminder of what to do if stopped by ICE
- Provide Employees/Volunteers with Masks for Docs contact and information document which includes

Checklist for Employees/Volunteers

References

If you have something to contribute or are looking for a guideline and do not find it here, please contact the Distribute Aid Team at:  
<platform@distributeaid.org>

---

PART I: General prevention measures during COVID-19

In the current pandemic it is important organisations take preventative measures to reduce the spread of COVID-19 and keep employees/volunteers safe. The CDC, WHO and OSHA \[Occupational Safety and Health Administration\] recommend the following actions.

- Advise employees/volunteers to stay home if they are sick, except to get medical care.
- Encourage employees/volunteers to inform a supervisor if they have a sick family member at home with either symptoms or a confirmed case of COVID-19.
- Advise employees/volunteers to practice good respiratory and hand hygiene:
- Regularly wash hands with soap and water for at least 20 seconds. Use hand sanitizer (with at least 60% alcohol) if soap and water are unavailable.
- Avoid touching eyes, nose, and mouth with unwashed hands.
- Cover the mouth and nose with a tissue when you cough or sneeze or use the inside of your elbow.
- Throw used tissues in the trash and immediately wash hands as above.
- Discourage handshaking – encourage the use of other non-contact methods of greeting.
- Place posters that encourage respiratory and hand-hygiene at the entrance to the workplace and in other workplace areas where they are likely to be seen. Please see [CDC](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/prevention.htm&sa=D&ust=1601935361889000&usg=AOvVaw32BUlXcw7i4VcKinMHqEHf) and [WHO](https://www.google.com/url?q=https://www.who.int/emergencies/diseases/novel-coronavirus-2019/advice-for-public&sa=D&ust=1601935361890000&usg=AOvVaw32y-FTeaxB0JWXQBljEfWQ) webpage for up-to-date guidance and printable resources for your workplace.
- Place hand-sanitizers (with at least 60% alcohol) in the workplace/provide to employees/volunteers to encourage hand hygiene.
- Where able, provide gloves and masks to be correctly used by employees/volunteers and disposed of afterwards. Please [see here](https://www.google.com/url?q=https://www.cdc.gov/niosh/npptl/pdfs/PPE-Sequence-508.pdf&sa=D&ust=1601935361891000&usg=AOvVaw3QCbN939_kUBZy6PLbBWsW) for further guidance.
- Provide employees/volunteers with disinfectant wipes for use on commonly used surfaces (e.g. door handles, tables) during distribution/pickups.

If an employee/volunteer shows symptoms of COVID-19 (dry cough, fever, fatigue, shortness of breath):

- They must avoid contact with fellow employees/volunteers/recipients.
- They should immediately finish their work shift and seek medical guidance.
- They should contact an available supervisor they can notify.
- All employees/volunteers must be provided with contact of an available supervisor they can notify in this instance.

PART II: Distribution Guidelines

Guidance for adapting distribution and pickup methods during the Covid-19 pandemic, in accordance with the CDC and UK government recommendations for delivery services, are outlined below.

All employees/volunteers should have an understanding of these guidelines prior to performing distributions and pickups in the community. Where possible, employees/volunteers should be provided with a briefing and hard copy of these guidelines for reference when performing distributions/pickups.

1.  Establish a safe method of distribution/pickup of PPE with recipient/provider.

<!-- end list -->

- Notify potential clients of Masks for Docs services that enquiries must NOT be made in person but via a telephone number/email - advertise this clearly via posters or website.
- When arranging distribution or pickup:
- Agree an approximate delivery/pickup time and exchange contact information with the recipient/provider.
- If completing multiple distributions at a fixed location, ensure the agreed pick-up times are staggered to minimise risk of virus spread.
- Agree on a drop-off/pickup point with the recipient/provider that ensures employee/volunteer can maintain social distancing protocol (see step 2).
- Introduce a way for recipients of PPE distribution to notify you on their health status. In case of them being infected with COVID-19, preventative measures should be strictly followed and the recipient’s property/workplace should not be entered.
- All employees/volunteers should have access to a charged mobile phone during distributions so they can make contact with recipients/providers of PPE as required.
- Prior to loading PPE for distribution, vehicles used should be sanitised using approved disinfectant.

CDC recommends using disinfectant products that meet EPA’s criteria for use against SARS-CoV-2, the cause of COVID-19, and are appropriate for the surface. Appropriate guidance can be [found here](https://www.google.com/url?q=https://www.epa.gov/pesticide-registration/list-n-disinfectants-use-against-sars-cov-2&sa=D&ust=1601935361896000&usg=AOvVaw3GaArwlfjerWIIGDBzBqrd).

Those in receipt of PPE distribution should also be provided with a contact number for any complaints/general enquiries regarding PPE distribution service. It may be therefore beneficial to have a person/office responsible for managing the complaints.

2.  During the distribution/pickup: maintain safe social distancing and hand/respiratory hygiene.

When making distribution/pickup, there should be no physical contact between employees/volunteers and the recipients/providers of PPE. Employees/volunteers should:

- Contact recipient/provider of PPE via phone upon arrival at agreed distribution/pickup point.
- Clean hands thoroughly using hand sanitiser provided.
- Do not touch face or hair
- Have long hair tied back, and facial hair shaved (if applicable)
- Put on gloves so that the gloves fit over long sleeves so that no skin over the wrist is exposed
- Put on a face mask, ideally a N95 respirator. Surgical masks and cloth masks are also acceptable
- Wearing gloves and masks, unload PPE and place at the agreed location.
- If mask needs adjusting, sanitize your gloved hands first and adjust via the straps and not the part of the mask covering your mouth/nose
- Do not pull off your mask or pull down your mask so that your nose and/or mouth become exposed
- Oversee distribution of PPE at safe distance (6 feet/2 metres) from others.
- Ensure the recipient collects PPE and signs any distribution information.
- Once recipient has moved to a safe social distance (6 feet/2 metres) pick up any signed information.
- If picking up PPE, do so in accordance with social distancing measures above.
- Upon return to vehicle remove/dispose gloves and sanitize hands for 20 seconds after each distribution/pickup.
- If unable to park close to drop-off/pickup point, maintain safe social distance from others whilst walking to and from vehicle.
- If performing a distribution from a fixed location where there may be multiple recipients:
- Instruct recipients to form a queue with a 6 foot/2 metre distance between each person.
- If possible, the entrance to distribution point should be separate to exit.
- Recipients must enter the room/area where the distribution is taking place one at a time.
- Place PPE items on a pre-disinfected table at the distribution point.
- Step back from the table, maintaining a social distance of 6 feet/2 metres.
- Recipients can then safely collect PPE from the table.

<!-- end list -->

3.  Measures to be taken following the distribution/pickup:

- Disinfect work surfaces following distribution/pick-up (e.g. vehicle, work surface, PPE storage spaces).
- After cleaning, remove/store the cleaning supplies in a secure location.

To disinfect, the CDC recommends using products that meet EPA’s criteria for use against COVID-19. Appropriate guidance can be [found here](https://www.google.com/url?q=https://www.epa.gov/pesticide-registration/list-n-disinfectants-use-against-sars-cov-2&sa=D&ust=1601935361902000&usg=AOvVaw0wOj3KG6SlGMSAz71x7pY7)and [here](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/cleaning-disinfection.html?CDC_AA_refVal%3Dhttps%253A%252F%252Fwww.cdc.gov%252Fcoronavirus%252F2019-ncov%252Fprepare%252Fcleaning-disinfection.html&sa=D&ust=1601935361903000&usg=AOvVaw275HzPlY5bWC2if5j6DugF)

- Wash hands for 20 seconds with soap and water or hand sanitiser (at least 60% alcohol).
- Remove shoes prior to entering living spaces, and sanitize the bottoms of shoes
- Sanitize any objects that were brought with you on the distribution (e.g., keys, wallet, phone, charger)
- Remove gloves by pulling at the wrist and rolling the gloves off of your hand so as to not touch the outside portion
- Remove the face mask by pulling the elastic, not touching the mask itself. Pull the elastics away from your face so that the external portion of the mask is never touched. Close your eyes and let the mask drop into a bin, which should ideally have a closed top.
- Keep records of distribution/pickup locations to track cases of virus and risk of exposure. In case of confirmed COVID-19 cases in a previous drop off/pickup point:
- Affected employees/volunteers should be informed and seek medical guidance.
- They should be sent home to self-isolate for 14-days to ensure they have not been infected with COVID-19.

PART III: Employee/Volunteer Safety

Due to ongoing restrictions made by the US government concerning work and travel, there is a risk that employees/volunteers may be stopped by authorities/law enforcement whilst performing distribution/pickups. Basic guidance on how to mitigate these risks and ensure operational efficiency is as follows:

For up-to-date information on government restrictions in response to Covid-19 pandemic please check [https://www.coronavirus.gov/](https://www.google.com/url?q=https://www.coronavirus.gov/&sa=D&ust=1601935361906000&usg=AOvVaw0WtRIL_ipcstUbFBpgA9c8).

Undocumented Workers:

- Consistent with its sensitive locations policy, during the COVID-19 crisis, ICE will not carry out enforcement operations at or near health care facilities, such as hospitals, doctors' offices, accredited health clinics, and emergent or urgent care facilities, except in extraordinary circumstances.

Reminder of what to do if stopped by ICE:

- Stay calm
- Know your rights (remember you have the right to remain silent)
- Ask to speak to your attorney and think twice about signing anything
- Present information document containing: the organization you are working for; the task you are travelling for; contact numbers of the organization; and the official signature/stamp of the organization.

Provide Employees/Volunteers with MasksForDocs contact and Information Document (see template) to be carried with them whilst on MasksForDocs supply runs which includes:

- Name of organization and its charity registration details.
- Name and date of birth of employee/volunteer (employee/volunteer should also carry on their persons supplementary ID such as driver’s license as supporting identification).
- Contact information of supervisor/organization.
- Brief description of essential work (i.e., PPE distribution and pick-up employee/volunteer is carrying out).

If stopped by authorities whilst on shift, employees/volunteers should act calm and show completed Information Document with contact information.

Know your rights if stopped by police:

- Both passengers and the driver have the right to remain silent

Checklist for Employees/Volunteers

Prior to a distribution or pickup being completed please ensure that employees/volunteers have on their persons:

✅  Contact information for a supervisor who is available if needed.

✅  Contact information for recipients of distribution/site of pick-up.

✅  Hand sanitiser of at least 60% alcohol content.

✅  Disinfectant wipes.

✅ Gloves and masks.

✅ Bag for waste.

✅  A charged work mobile phone.

✅ ID for documented workers.

✅  Information Document containing contact/organisation info if employee/volunteer is stopped by authorities whilst performing distribution/pick-up.

✅ When possible a hard copy of these guidelines to refer to when doing distributions/pick-ups whilst out in the community

EXAMPLE DOC SHEET:

\[GROUP HEADER/LOGO HERE\]

Name of organisation:

Charity/Non Profit registration details:

Name of employee/volunteer:

Employee/volunteer date of birth:

Contact information of supervisor/organisation:

Name:                                                                Position:

Contact Number:

Description of work carried out for the organization:

Name/signature of supervisor:

Date:                                                                           Organization logo/stamp

(if applicable):

---

References:

[https://www.aclu-ms.org/en/news/know-your-rights-if-ice-agents-come-your-door](https://www.google.com/url?q=https://www.aclu-ms.org/en/news/know-your-rights-if-ice-agents-come-your-door&sa=D&ust=1601935361916000&usg=AOvVaw13FHc9RPBwq6orBTu7bxlA)

[https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/cleaning-disinfection.html?CDC_AA_refVal=https%3A%2F%2Fwww.cdc.gov%2Fcoronavirus%2F2019-ncov%2Fprepare%2Fcleaning-disinfection.html](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/cleaning-disinfection.html?CDC_AA_refVal%3Dhttps%253A%252F%252Fwww.cdc.gov%252Fcoronavirus%252F2019-ncov%252Fprepare%252Fcleaning-disinfection.html&sa=D&ust=1601935361917000&usg=AOvVaw2CMCgPnTMsKVFIU6GqppIh)

[https://www.cdc.gov/coronavirus/2019-ncov/community/guidance-business-response.html](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/community/guidance-business-response.html&sa=D&ust=1601935361918000&usg=AOvVaw3hmMPReTF1JOMCOLz2OrBT)

[https://www.cdc.gov/coronavirus/2019-ncov/community/index.html](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/community/index.html&sa=D&ust=1601935361918000&usg=AOvVaw3nGSFxl21Sy-NHa6UszWk_)

[https://www.cdc.gov/coronavirus/2019-ncov/daily-life-coping/essential-goods-services.html](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/daily-life-coping/essential-goods-services.html&sa=D&ust=1601935361919000&usg=AOvVaw2VV9Onjw2qsx3I6uhGLVx_)

[https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/prevention.htm](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/prevention.htm&sa=D&ust=1601935361919000&usg=AOvVaw0-pa7Rx7Gy2hVG7jiDFtJs);

[https://www.cdc.gov/niosh/npptl/pdfs/PPE-Sequence-508.pdf](https://www.google.com/url?q=https://www.cdc.gov/niosh/npptl/pdfs/PPE-Sequence-508.pdf&sa=D&ust=1601935361920000&usg=AOvVaw0E0w0PeraBYP5Bt5-f6KSf)

[https://www.coronavirus.gov/](https://www.google.com/url?q=https://www.coronavirus.gov/&sa=D&ust=1601935361920000&usg=AOvVaw3Vip8cziKS58nEp9K37Kn9)

[https://www.epa.gov/pesticide-registration/list-n-disinfectants-use-against-sars-cov-2](https://www.google.com/url?q=https://www.epa.gov/pesticide-registration/list-n-disinfectants-use-against-sars-cov-2&sa=D&ust=1601935361921000&usg=AOvVaw36M_Kl2OY-vo1BEqr8N-Ei)

[https://www.gov.uk/guidance/social-distancing-in-the-workplace-during-coronavirus-covid-19-sector-guidance\#shops-running-a-pick-up-or-delivery-service](https://www.google.com/url?q=https://www.gov.uk/guidance/social-distancing-in-the-workplace-during-coronavirus-covid-19-sector-guidance%23shops-running-a-pick-up-or-delivery-service&sa=D&ust=1601935361921000&usg=AOvVaw1nMesEiPlIT8mBlINX5dNu)

[https://www.ice.gov/news/releases/updated-ice-statement-covid-19](https://www.google.com/url?q=https://www.ice.gov/news/releases/updated-ice-statement-covid-19&sa=D&ust=1601935361922000&usg=AOvVaw1taxUelJC_Whc0cZxnL8o_)

[https://www.osha.gov/SLTC/covid-19/controlprevention.html](https://www.google.com/url?q=https://www.osha.gov/SLTC/covid-19/controlprevention.html&sa=D&ust=1601935361922000&usg=AOvVaw1WwloswScxYjV4Z2NlOwoA)

[https://www.who.int/emergencies/diseases/novel-coronavirus-2019](https://www.google.com/url?q=https://www.who.int/emergencies/diseases/novel-coronavirus-2019&sa=D&ust=1601935361923000&usg=AOvVaw3mil6EOv_bdc2XYszjDvcH)

[https://www.who.int/emergencies/diseases/novel-coronavirus-2019/advice-for-public](https://www.google.com/url?q=https://www.who.int/emergencies/diseases/novel-coronavirus-2019/advice-for-public&sa=D&ust=1601935361923000&usg=AOvVaw0EmheGx-w4u0QKoqqx4AX2)

Additional resources on distro:

[https://www.who.int/docs/default-source/coronaviruse/advice-for-workplace-clean-19-03-2020.pdf](https://www.google.com/url?q=https://www.who.int/docs/default-source/coronaviruse/advice-for-workplace-clean-19-03-2020.pdf&sa=D&ust=1601935361924000&usg=AOvVaw0l4dNxZVa-vyulgPdB-UCJ)

[https://www.who.int/hac/network/interagency/b6_non_food_items.pdf](https://www.google.com/url?q=https://www.who.int/hac/network/interagency/b6_non_food_items.pdf&sa=D&ust=1601935361924000&usg=AOvVaw1dnLb-aao6029sPtDoyUts)

[https://www.humanitarianresponse.info/sites/www.humanitarianresponse.info/files/documents/files/shelter_and_nfi_distribution_guideline_in_the_context_of_covid-19_outbreak.pdf](https://www.google.com/url?q=https://www.humanitarianresponse.info/sites/www.humanitarianresponse.info/files/documents/files/shelter_and_nfi_distribution_guideline_in_the_context_of_covid-19_outbreak.pdf&sa=D&ust=1601935361925000&usg=AOvVaw0xSLA_Nn0T4HaFqj8SLWDx)

[https://emergency.unhcr.org/entry/43130/commodity-distribution-nfis-food](https://www.google.com/url?q=https://emergency.unhcr.org/entry/43130/commodity-distribution-nfis-food&sa=D&ust=1601935361925000&usg=AOvVaw0HyYqcEkDmwBloZAt2_Mat)

[https://interagencystandingcommittee.org/system/files/2020-03/IASC%20Interim%20Guidance%20on%20COVID-19%20for%20Outbreak%20Readiness%20and%20Response%20Operations%20-%20Camps%20and%20Camp-like%20Settings.pdf](https://www.google.com/url?q=https://interagencystandingcommittee.org/system/files/2020-03/IASC%2520Interim%2520Guidance%2520on%2520COVID-19%2520for%2520Outbreak%2520Readiness%2520and%2520Response%2520Operations%2520-%2520Camps%2520and%2520Camp-like%2520Settings.pdf&sa=D&ust=1601935361926000&usg=AOvVaw3j4VRLzx4OeAxlSnvdwTyl)

[https://cms.emergency.unhcr.org/documents/11982/43126/MSF%2C+Non+Food+Items+Distribution%2C+Version+1.0%2C+2009/1fbb9f68-826d-4d57-8198-6392519b6eba](https://www.google.com/url?q=https://cms.emergency.unhcr.org/documents/11982/43126/MSF%252C%2BNon%2BFood%2BItems%2BDistribution%252C%2BVersion%2B1.0%252C%2B2009/1fbb9f68-826d-4d57-8198-6392519b6eba&sa=D&ust=1601935361926000&usg=AOvVaw339_KKRupEZSrjf1GEPAXb)

[https://fscluster.org/sites/default/files/documents/safe_distribution_guidelines.pdf](https://www.google.com/url?q=https://fscluster.org/sites/default/files/documents/safe_distribution_guidelines.pdf&sa=D&ust=1601935361927000&usg=AOvVaw11NSRiHKAncMD8D4gS4S9v)
