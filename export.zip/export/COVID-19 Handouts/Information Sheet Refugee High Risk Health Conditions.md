---
title: "Information Sheet: Refugee High Risk Health Conditions"
driveId: 1KI-yUxgUPOlXrYI45ahhyczFmxhLIR3twhBBJRAjOxo
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-04-24T14:56:08.867Z
---

Refugees who have one or more of the following health conditions are at greater risk of experiencing health complications from COVID-19. These people should be monitored by medical teams and if possible in the event of an outbreak, be isolated.

Most high risks groups of Covid-19:

- Cancer - especially blood or bone marrow
- Severe respiratory conditions - cystic fibrosis / severe asthma / severe COPD / emphysema / bronchitis
- Rare diseases and inborn errors of metabolism that significantly increase the risk of infections - SCID / homozygous sickle cell
- Neurological - Parkinsons / Motor Neurone Disease / Multiple Sclerosis / Cerebral Palsy
- Immunosuppression therapies and steroid users
- Spleen complications - Sickle Cell Disease / Spleen Removal
- Pregnancy with significant congenital heart disease
- HIV / AIDS (without access to antiretrovirals)
- Serious heart conditions
- Severe obesity (BMI of 40 or higher)
- Diabetes
- Chronic kidney disease
- Liver disease
- High blood pressure
- Tuberculosis
- Long-term smokers

Extra Resources:

COVID-19 with pregnancy and breast-feeding  
[https://www.cdc.gov/coronavirus/2019-ncov/need-extra-precautions/pregnancy-breastfeeding.html](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/need-extra-precautions/pregnancy-breastfeeding.html&sa=D&ust=1601935362161000&usg=AOvVaw3b-a7Oc12kH-qpoc7GprvS)

People with disabilities:  [https://www.cdc.gov/coronavirus/2019-ncov/need-extra-precautions/people-with-disabilities.html](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/need-extra-precautions/people-with-disabilities.html&sa=D&ust=1601935362161000&usg=AOvVaw1y48ADulV6ooFDo28e-AsC)
