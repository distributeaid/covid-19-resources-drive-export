---
title: " Information Sheet: STEP How To Decide To Continue Operations "
driveId: 10e8Ds1t0hVQ6mjznkiabbIx_QGF_tTCkJDmtP2Uk2n8
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-04-24T14:55:41.218Z
---

## Information Sheet:

S.T.E.P. Up or S.T.E.P. Back

If there is an outbreak - should you S.T.E.P up or S.T.E.P back?

STOP   
Is this operation crucial to daily life?  
If the answer is no, refer to page 12 of the guide to see if you can adapt your operations. If you are unable to do this you should suspend activities for 14 days.  
If it is yes you should;

THINK   
Will this operation contribute to the spread of the virus within the camp?  
If the answer is yes, refer to page 12 of the guide to see if you can adapt your operations. If you are unable to do this you should suspend activities for 14 days.  
If the answer is no you should;

EVALUATE  
Is it within my power to reasonably ensure I can protect my staff and asylum seekers?  
Consider your staff that fall into the high risk category.  
If the answer is no, refer to page 12 of the guide to see if you can adapt your operations. If you are unable to do this you should suspend activities for 14 days.    
If it is yes you should;

PLAN    
Sit down with your team and create a plan on:  
\- how you will operate on a daily basis within camp settings  
\- how to best practice good hand and respiratory hygiene during operations with the supplies you have

\- what conditions would cause you to suspend your operations, where do you draw the line to keep people safe?
