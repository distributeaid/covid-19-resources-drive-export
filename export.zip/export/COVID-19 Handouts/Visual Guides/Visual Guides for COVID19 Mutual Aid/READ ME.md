---
title: "READ ME"
driveId: 18LWyjfx-zAWdmeEn6TJ1D4b67rMPy9xWeeCbqCBCmns
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-04-19T14:23:47.179Z
---

Visual guide to stop the spread of  COVID-19 while helping your community

Last updated 19th April 2020 by Lara.

[Description](#h.qeu1ezu808rr)

[Content](#h.xj7f4767dsd5)

[Contributing](#h.7ddws9v9w4z7)

[Feedback](#h.os38ijjkz3d5)

[Please comment on the slides.

Authors and acknowledgment](#h.hefoullyvuk4)

[Versions](#h.3q2uj9qsnjwb)

[License](#h.oja1kkiv2v46)

[Sources](#h.46pp2lr0pfdb)

[Disclaimer](#h.dlqkszlbwxn6)

# Description

This visual guide aims to provide accessible guidance to neighbours who are helping each other.

This guide is based on international, national and local from trusted sources and checked by several medical teams. However, we are not epidemiologists or healthcare professionals. For up-to-date medical advice you should continue to check your national healthcare service. Please note that as advice changes often the guide might be already outdated (it was issued on the 13th April).

Please update the visual guidelines, translate them and adapt them to your local context.

The visual guides are optimised to be easy to edit and shared on social media by Mutual Aid groups.

# Content

Project folder [Visual Guides for COVID19 Mutual Aid](https://www.google.com/url?q=https://drive.google.com/open?id%3D1J6h4tTFnXt5SIVCB2FJD4fBF7pohcznF&sa=D&ust=1601935364682000&usg=AOvVaw3gcRo3zzPQZ-RvjUexzlPM)

README.TXT https://docs.google.com/document/d/18LWyjfx-zAWdmeEn6TJ1D4b67rMPy9xWeeCbqCBCmns/edit?usp=sharing

# Contributing

Please contribute to create visual guidelines for other activities and countries, always based on trusted sources.

Add to [https://drive.google.com/drive/folders/1J6h4tTFnXt5SIVCB2FJD4fBF7pohcznF?usp=sharing](https://www.google.com/url?q=https://drive.google.com/drive/folders/1J6h4tTFnXt5SIVCB2FJD4fBF7pohcznF?usp%3Dsharing&sa=D&ust=1601935364683000&usg=AOvVaw1Qn1bVgXmNVKnhX64KXKPU)

Add the details to this README.TXT [https://docs.google.com/document/d/18LWyjfx-zAWdmeEn6TJ1D4b67rMPy9xWeeCbqCBCmns/edit\#](https://www.google.com/url?q=https://docs.google.com/document/d/18LWyjfx-zAWdmeEn6TJ1D4b67rMPy9xWeeCbqCBCmns/edit%23&sa=D&ust=1601935364683000&usg=AOvVaw2HSU5ftslmBEig9szwT-qh)

# Feedback

# Please comment on the slides.

Authors and acknowledgment

‘Visual guides for COVID-19’ have been started by Lara Salinas (l.salinas@lcc.arts.ac.uk), Min Deng (orehmm@gmail.com), Ruchika Karnani (ruchika.karnani96@gmail.com) and Marida Maiorino, in collaboration with their local Rotherhithe Mutual Aid group.

[Lara](https://www.google.com/url?q=https://www.arts.ac.uk/research/ual-staff-researchers/lara-salinas&sa=D&ust=1601935364684000&usg=AOvVaw0Cd7ZrOrS4MN08x7spZqKX) is a design researcher and educator at [London College of Communication](https://www.google.com/url?q=https://www.arts.ac.uk/colleges/london-college-of-communication&sa=D&ust=1601935364684000&usg=AOvVaw3QN0gZvLZz0xMmChYSVwo0), [University of the Arts London](https://www.google.com/url?q=https://www.arts.ac.uk/&sa=D&ust=1601935364685000&usg=AOvVaw0jN4zzUDc0NIK3HQB0b_FP). Min and Ruchika are post-graduate service design students studying [MA Service Design](https://www.google.com/url?q=https://www.arts.ac.uk/subjects/business-and-management-and-science/postgraduate/ma-service-design-lcc&sa=D&ust=1601935364685000&usg=AOvVaw0EdWS1Vdt1U_0KZoyEc9wa). Marida is a service designer and doctoral researcher.

#### Versions

Food_delivery_v1_EN-UK, by Min Deng, Marida Maiorino, Ruchika Karnani, 13th April 2020, UK and India.

Food_delivery_v2_EN-UK, by Lara Salinas, Min Deng, Marida Maiorino, Ruchika Karnani, 15th April 2020, UK and India. - Added the step to clean the counter after unpacking the food.

Food_delivery_v3_EN-UK, by Lara Salinas, Min Deng, Marida Maiorino, Ruchika Karnani, 15th April 2020, UK and India. - Some minor rephrasing.

Alimentos_domicilio_v3_ES-UK, by Lara Salinas, Min Deng, Marida Maiorino, Ruchika Karnani, Coral Hunt, Javiera Godoy, 19th April 2020, UK, India, Spain and Chile. - Spanish translation of v.3.

# License

This is an open source project: CC BY-NC 4.0 [https://creativecommons.org/licenses/by-nc/4.0/](https://www.google.com/url?q=https://creativecommons.org/licenses/by-nc/4.0/&sa=D&ust=1601935364687000&usg=AOvVaw08oQkUjcT1EB7lEyqkKQE6)

You are free to share, copy and redistribute the material in any medium or format, and to adapt, remix, transform and build upon the material. You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use. You may not use the material for commercial purposes. You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.For open source projects, say how it is licensed.

# Sources

QueerCare (2020a) Delivering items to someone who is immunocompromised protocol—Queercare. https://bit.ly/39XKvR1

QueerCare (2020b) Delivering items to someone who is (potentially) infected protocol—Queercare. https://bit.ly/2wuRCmo

Rotherhithe Covid-19 Mutual Aid Group (2020) Facebook. https://bit.ly/2JYDVzc

Liang, T (2020) Handbook of COVID-19 Prevention and Treatment. The First Affiliated Hospital, Zhejiang University School of Medicine (FAHZU).

Stephen, Park, and Woo-Ju Kim. (2020)  You Need To Listen To This Leading COVID-19 Expert From South Korea | ASIAN BOSS.[ ](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DgAk7aX5hksU&sa=D&ust=1601935364688000&usg=AOvVaw37RbIHiH0duwtnbxNQPfUV)https://bit.ly/2JXE3yY

# Disclaimer

Please note we are design researchers and practitioners, not epidemiologists or healthcare professionals. We have adapted written guidelines to make them more accessible and easier to follow. This guide might differ from your national advice. For up-to-date medical advice you should continue to check your national healthcare advice. Before engaging in a mutual aid project we recommend that you become familiar with QueerCare guidelines.
