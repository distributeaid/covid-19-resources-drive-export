---
title: "Food_delivery_v2_EN_UK_GENERAL (1).pdf"
driveId: 1rcEZo0qZOLkGRu-9RQO3-Z4aJtAmvsnT
modifiedTime: 2020-04-15T17:15:44.084Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1rcEZo0qZOLkGRu-9RQO3-Z4aJtAmvsnT/view?usp=drivesdk
---

# Food_delivery_v2_EN_UK_GENERAL (1).pdf

[Click here](https://drive.google.com/file/d/1rcEZo0qZOLkGRu-9RQO3-Z4aJtAmvsnT/view?usp=drivesdk) to download the file.