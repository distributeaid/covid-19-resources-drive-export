---
title: "Food_delivery_v1_EN_UK_GENERAL (2).pdf"
driveId: 19Fk_Ga1T6SVUsEMEAUWce_wD55_X3qPZ
modifiedTime: 2020-04-13T19:21:47.663Z
mimeType: application/pdf
url: https://drive.google.com/file/d/19Fk_Ga1T6SVUsEMEAUWce_wD55_X3qPZ/view?usp=drivesdk
---

# Food_delivery_v1_EN_UK_GENERAL (2).pdf

[Click here](https://drive.google.com/file/d/19Fk_Ga1T6SVUsEMEAUWce_wD55_X3qPZ/view?usp=drivesdk) to download the file.