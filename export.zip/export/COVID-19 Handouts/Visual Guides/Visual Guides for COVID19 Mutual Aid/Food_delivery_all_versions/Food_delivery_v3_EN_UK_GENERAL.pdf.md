---
title: "Food_delivery_v3_EN_UK_GENERAL.pdf"
driveId: 1b0Oe2Fp7pTVQo_IUvUygbfLFi4DuMcid
modifiedTime: 2020-04-19T10:15:45.000Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1b0Oe2Fp7pTVQo_IUvUygbfLFi4DuMcid/view?usp=drivesdk
---

# Food_delivery_v3_EN_UK_GENERAL.pdf

[Click here](https://drive.google.com/file/d/1b0Oe2Fp7pTVQo_IUvUygbfLFi4DuMcid/view?usp=drivesdk) to download the file.