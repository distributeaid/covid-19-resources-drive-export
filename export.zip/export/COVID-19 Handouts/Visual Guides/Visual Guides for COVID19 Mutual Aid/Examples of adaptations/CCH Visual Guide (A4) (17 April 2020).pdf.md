---
title: "CCH Visual Guide (A4) (17 April 2020).pdf"
driveId: 1htt9-R7bUeS3oHQkzHkBfJPhJneLM2OE
modifiedTime: 2020-04-19T08:36:58.000Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1htt9-R7bUeS3oHQkzHkBfJPhJneLM2OE/view?usp=drivesdk
---

# CCH Visual Guide (A4) (17 April 2020).pdf

[Click here](https://drive.google.com/file/d/1htt9-R7bUeS3oHQkzHkBfJPhJneLM2OE/view?usp=drivesdk) to download the file.