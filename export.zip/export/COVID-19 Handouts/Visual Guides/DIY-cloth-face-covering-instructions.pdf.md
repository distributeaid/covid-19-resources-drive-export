---
title: "DIY-cloth-face-covering-instructions.pdf"
driveId: 1GEU2QEokEH0iP28NTGrdp2wRE3a4kp5D
modifiedTime: 2020-04-07T11:30:14.714Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1GEU2QEokEH0iP28NTGrdp2wRE3a4kp5D/view?usp=drivesdk
---

# DIY-cloth-face-covering-instructions.pdf

[Click here](https://drive.google.com/file/d/1GEU2QEokEH0iP28NTGrdp2wRE3a4kp5D/view?usp=drivesdk) to download the file.