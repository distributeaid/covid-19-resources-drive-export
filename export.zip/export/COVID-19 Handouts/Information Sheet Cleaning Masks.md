---
title: "Information Sheet: Cleaning Masks"
driveId: 1jdjcHae6mSeCJoR1gjlLqYXZgQsbZOHACjk-Z9QWqpI
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-05-08T12:19:15.692Z
---

Though masks are typically not meant to be reused, due to the emergent COVID-19 pandemic these methods have been provided by the CDC for tried and tested methods that do not disrupt the structural integrity of the mask, not present any risk to the user, and remove any viral threat.

Autoclaving and the use of disinfectant wipes are not recommended as they may alter FFR performance.

Decontamination using an autoclave, 160°C dry heat, 70% isopropyl alcohol, microwave irradiation and soap and water caused significant filter degradation to both FFRs and particle penetration levels that do not meet NIOSH approval levels. Decontamination with bleach caused slight degradation in filtration performance and created an odor that would not be suitable for use.

Vaporous hydrogen peroxide, ultraviolet germicidal irradiation, and moist heat are the most promising decontamination methods.

Vaporous hydrogen peroxide (HPV) was one of the most useful decontamination methods, using an HPV generator.The HPV cycle included a 10 min conditioning phase, 20 min gassing phase at 2 g/min, 150 min dwell phase at 0.5 g/min, and 300 min of aeration. This was useful for up to 20 cycles.  
Ultraviolet germicidal irradiation had a 90-100% passing rate for up to 3 cycles.  
Moist heat incubation in cycles of 15 min–30 min (60°C, 80% RH) passed in 6 of 6 models

There is also some evidence indicating the effectiveness of steam treatments; one study used microwave steam bags to decontaminate six FFR models and achieved 99.9% inactivation of MS2 bacteriophage

Decontamination methods evaluated for each FFR model

<table>
<colgroup>
<col width="12%" />
<col width="12%" />
<col width="12%" />
<col width="12%" />
<col width="12%" />
<col width="12%" />
<col width="12%" />
<col width="12%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p>FFR Model</p></td>
<td><p>Type</p></td>
<td><p>VHP</p></td>
<td><p>UVGI</p></td>
<td><p>EtO</p></td>
<td><p>Steam</p></td>
<td><p>Moist heat</p></td>
<td><p>Hydrogen peroxide</p></td>
</tr>
<tr class="even">
<td><p>3M 1860</p></td>
<td><p>N95</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
</tr>
<tr class="odd">
<td><p>3M 1870</p></td>
<td><p>N95</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
</tr>
<tr class="even">
<td><p>3M 8000</p></td>
<td><p>N95</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
</tr>
<tr class="odd">
<td><p>3M 8210</p></td>
<td><p>N95</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
</tr>
<tr class="even">
<td><p>3M 9210</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>3M Vflex 1805</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="even">
<td><p>Alpha protech</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>Cardinal Health</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="even">
<td><p>Gerson 1730</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>Kimberly Clark PFR-95</p></td>
<td><p>N95</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
</tr>
<tr class="even">
<td><p>Moldex 1512</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>Moldex 1712</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="even">
<td><p>Moldex 2200</p></td>
<td><p>N95</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>Moldex 2201</p></td>
<td><p>N95</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
</tr>
<tr class="even">
<td><p>Precept 65-3395</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>Prestige Ameritech RP88020</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="even">
<td><p>Sperian HC-NB095</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>Sperian HC-NB295</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="even">
<td><p>U.S. Safety AD2N95A</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>U.S. Safety AD4N95A</p></td>
<td><p>N95</p></td>
<td><p></p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="even">
<td><p>3M 8293</p></td>
<td><p>P100</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="odd">
<td><p>Moldex 2360</p></td>
<td><p>P100</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
<tr class="even">
<td><p>North 8150</p></td>
<td><p>P100</p></td>
<td><p>x</p></td>
<td><p>x</p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
<td><p></p></td>
</tr>
</tbody>
</table>

Table 1. Summary of crisis standards of care decontamination recommendations

Method

Manufacturer or third-party guidance or procedures available

Recommendation for use after decontamination

Additional use considerations

Ultraviolet germicidal irradiation (UVGI)

Yes

Can be worn for any patient care activities

- Clean hands with soap and water or an alcohol-based hand sanitizer before and after touching or adjusting the FFR.
- Avoid touching the inside of the FFR.
- Use a pair of clean (non-sterile) gloves when donning and performing a user seal check.
- Visually inspect the FFR to determine if its integrity has been compromised.
- Check that components such as the straps, nose bridge, and nose foam material did not degrade, which can affect the quality of the fit, and seal.
- If the integrity of any part of the FFR is compromised, or if a successful [user seal check](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DpGXiUyAoEd8&sa=D&ust=1601935361102000&usg=AOvVaw3-kwsRD1RhkyJ2SDPSdqzv) cannot be performed, discard the FFR and try another FFR.
- Users should perform a [user seal check](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DpGXiUyAoEd8&sa=D&ust=1601935361103000&usg=AOvVaw087ePpM2_W4DCJklor2-ie) immediately after they don each FFR and should not use an FFR on which they cannot perform a successful user seal check.

Vaporous hydrogen peroxide (VHP)

Moist heat

Ultraviolet germicidal irradiation (UVGI)

No

Can be worn for patient care activities except when performing or present for an aerosol generating procedure

Vaporous hydrogen peroxide (VHP)

Moist heat



Table 2.  Summary of the decontamination method and effect on FFR performance

Method

Treatment level

FFR filtration performance

FFR fit performance

Other observations

References

Vaporous hydrogen peroxide (VHP)

Battelle report: Bioquell Clarus C HPV generator: The HPV cycle included a 10 min conditioning phase, 20 min gassing phase at 2 g/min, 150 min dwell phase at 0.5 g/min, and 300 min of aeration.

Bergman et. al.: Room Bio-Decontamination Service (RBDS™, BIOQUELL UK Ltd, Andover, UK), which utilizes four portable modules: the Clarus® R HPV generator (utilizing 30% H2O2), the Clarus R20 aeration unit, an instrumentation module and a control computer. Room concentration = 8 g/m3, 15 min dwell, 125 min total cycle time.

Passed

FFR fit was shown to be unaffected for up to 20 VHP treatments cycles using a head form

Degradation of straps after 30 cycles (Battelle report)

3, 4

Ultraviolet germicidal irradiation (UVGI)

0.5–950 J/cm2

Passed

90–100% passing rate after 3 cycles depending on model

2, 3, 7, 8, 9, 10

Microwave generated steam

1100–1250 W microwave models (range: 40 sec to 2 min)

All models passed filtration evaluation for 1 or 20 treatment cycles as per test

95–100% passing rate after 3 and 20 cycles for all models tested

9, 10, 14

Microwave steam bags

1100 W, 90 sec (bags filled with 60 mL tap water)

Passed

Not evaluated

15

Moist heat incubation

15 min–30 min (60°C, 80% RH)

6 of 6 models passed after 3 cycles of contamination

Passed

3, 9, 10

Liquid hydrogen peroxide

1 sec to 30 min (range: 3–6%)

Passed

Not evaluated

3, 7

Ethylene oxide

1 hour at 55°C; conc. range: 725–833/L

Passed

Not evaluated

2, 3, 7

Table 3. Summary of decontamination method antimicrobial efficacy

Method

Treatment level

Microbe tested

Antimicrobial efficacy

References

Vaporous hydrogen peroxide (VHP)

Battelle report: Bioquell Clarus C HPV generator: The HPV cycle included a 10 min conditioning phase, 20 min gassing phase at 2 g/min, 150 min dwell phase at 0.5 g/min, and 300 min of aeration.

Bergman et. al.: Room Bio-Decontamination Service (RBDS™, BIOQUELL UK Ltd, Andover, UK), which utilizes four portable modules: the Clarus® R HPV generator (utilizing 30% H2O2), the Clarus R20 aeration unit, an instrumentation module and a control computer. Room concentration = 8 g/m3, 15 min dwell, 125-min total cycle time.

Kenney personal communication: Bioquell BQ-50 generator: The HPV cycle included a 10 minute conditioning phase, 30–40 min gassing phase at 16 g/min, 25 min dwell phase, and a 150 min aeration phase.

Geobacillus stearothermophilus spores

T1, T7, and phi-6 bacteriophages

\>99.999%

3, 4, 6

Ultraviolet germicidal irradiation (UVGI)

0.5–1.8 J/cm2

Influenza A (H1N1)

Avian influenza A virus (H5N1),

low pathogenic

Influenza A (H7N9),

A/Anhui/1/2013

Influenza A (H7N9),

A/Shanghai/1/2013

MERS-CoV

SARS-CoV

H1N1

Influenza A/PR/8/34

MS2 bacteriophage

99.9% for all tested viruses

12, 13, 14

Microwave generated steam

1100–1250 W microwave models (range: 40 sec to 2 min)

H1N1 influenza A/PR/8/34

99.9%

14

Microwave steam bags

1100 W, 90 sec (bags filled with 60 mL tap water)

MS2 bacteriophage

99.9%

15

Moist heat incubation

15–30 min (60°C, 80% RH)

H1N1 influenza A/PR/8/34

99.99%

14

Liquid hydrogen peroxide

1 sec to 30 min (range: 3–6%)

Not evaluated

Not evaluated

Ethylene oxide

1 hour at 55°C; conc. range: 725–833 mg/L

Not evaluated

Not evaluated



Full references [available here](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/hcp/ppe-strategy/decontamination-reuse-respirators.html&sa=D&ust=1601935361148000&usg=AOvVaw0ZeoesSxcFGZ4-RaXEbXY7)
