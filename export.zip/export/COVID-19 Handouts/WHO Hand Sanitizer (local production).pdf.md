---
title: "WHO Hand Sanitizer (local production).pdf"
driveId: 1OHVXFuIlQB2gXgo9o5WYazGnglfWJkx4
modifiedTime: 2020-05-05T06:59:40.000Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1OHVXFuIlQB2gXgo9o5WYazGnglfWJkx4/view?usp=drivesdk
---

# WHO Hand Sanitizer (local production).pdf

[Click here](https://drive.google.com/file/d/1OHVXFuIlQB2gXgo9o5WYazGnglfWJkx4/view?usp=drivesdk) to download the file.