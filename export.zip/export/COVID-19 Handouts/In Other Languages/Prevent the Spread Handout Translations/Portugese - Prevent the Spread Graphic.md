---
title: "Portugese - Prevent the Spread Graphic"
driveId: 1UkIEwXC6AV8b4Ej621dEtEPxTZgXOl6MtHFPkJnm5JM
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:03:08.520Z
---

PREVENÇÃO DO COVID-19

Lave as mãos

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh6.googleusercontent.com/Wl1fHQHWU96mkkr0CHD3Szbwpaqgol8W635Qmq5DyKq8ZghJerXN3igkZaY0to0DC-4BoS0ZJu6vueWc-2rXcX0xUigReDMUjI8Ets-Woi_P6oLf0Je0ngWSB9zgy8ufpTQmQtxu" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/q0gZ-OKPjEBpHpeWc7GLP0CY5qFLAnnDv_LfG2pr7VRSXVCDLMUrOwIA6w3Pk-QSWIoTK_E8OddIoPg2FoMwkYTuw0onBRAMrgdIsJPsI29XjycQty-MKbS2XWcFw-SRTDOYwUbs" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/jF0c0x3MsM5ASJ42Dtw4Q3D9V3jNbYOWawlY4yDO_6jIxIrHmjibY9Fe8HhS-5vX2CyH3bZw8WIc7hhjgqQ1vJJhu5UdAtZA4rgP7dOeFgJR_wcHnvfxxcNAIlU8fId4zIL9m5GV" /></p></td>
</tr>
<tr class="even">
<td><p>Com sabão &amp; água limpa</p></td>
<td><p>Por 20 segundos</p></td>
<td><p>Com frequência</p></td>
</tr>
</tbody>
</table>

Cubra nariz e boca ao tossir

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/vOnMvsh7eeltQlgQPORGoQACW2oAFm1AJ07pDEcUK2aOwypj78QGRfa4medbrE2LkT4DrGkhA82OpngXG04chwJlbj0giyUc-An76q4Tcl5h04DMOYgyXynmKqJ9qdn8lRKL93rD" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/XEMhIUuF8WAhF1nRiushhCjomgeVy-i9ac7Xm_1zh5sArsGT_41WIJFiop2djQhlQu8_pBv1yzzButMWh6AJzX4l2LsEMfHY0hEZOzv7Bx4fMd6pTHsg90i9064kUSy6ne3KNi5v" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/4Pi-V6xlo5vxffXFHt2Ab1sZ7pdW7uQltp-WPQ3YBfC_jJpulPEeyEzMODy2kfsKfPE_7o8RusrJzFr7V_XQlyOnR5ttR-NcuY-ZmdI2GtOajiuREnEYl-zaLxzQfFsAURCPQNwe" /></p></td>
</tr>
<tr class="even">
<td><p>Use um lenço</p></td>
<td><p>Ou seu cotovelo</p></td>
<td><p>Nunca as mãos</p></td>
</tr>
</tbody>
</table>

Evite tocar no rosto

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/HAPfSwLJb1d31aJ_ymgL5iW3eNnt7NkNOth11MsvsYTNvPzSW9No0KqRJrUTpPDNf-NNbgDgB-zh2rdo_hjW5wa0kmfKG3XYlwBKGV-oD-oXqe06fOUrteMcW2S4ghQWAzl9Cytd" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/rE4yujX5rFc8FQavqsTr0Rn1ZCW6quYLumNhuLyVwnT5Qy44fXyADjJsjh80KD0CDESFtZ-hIZQQ8rM-khIvYEhBIitg8jAwZgMJfte7js8obhAO1IBeCHscASCj5NBjAxGE3TTe" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/L46pwk94RvcPZDsXMi5xBQKN3oZIEDT5LedRrMxoR1jhVganTJAfdkMYp3uqkJmNzS7AaMUHt3GOaMxgZJSm7ApDjmxHipRiHG8x3spaYaWiPyMudHiXVomEIGCtcgXLZanhWtVW" /></p></td>
</tr>
<tr class="even">
<td><p>Não toque olhos</p></td>
<td><p>nariz</p></td>
<td><p>Ou boca</p></td>
</tr>
</tbody>
</table>

Mantenha distância

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/tROIz8yWfw98kNIxiAZ4JcKxpruOHPnvhRS7GKYAmrEXztVkXwILSwKzWIH7-tycA_ATbxW-tKLk9tvT8DXdwzBtrE_ydysbWjU9QmIVBhtiWnRpJ9lGerzVgRS010eiNoa_VvGh" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/ehwpExmgYDCg5EhFX9t0-Wgp5l5dIsmPrvd0gUYOFBM77gjjyuiEHhZO6lnSRELln2jsDzvf1Bd7HOZP6TMydWFSx6lPjltI6EegiKawrQSF31JHUmDP5hSo0d-4KzOgiXSURSEO" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/g6hPyTrrydeyeFoTtsaFy5cQojxONRTOVXid7-6RZ9GNOw3gDXxhcygdg99iGRzLsrT-5lEjvC5TQhG4eeTJna-CKN9mBIz0ms9W8_6-2Bb2TvPoE3lKUNqblAXOio7h1xfQaPzu" /></p></td>
</tr>
<tr class="even">
<td><p>Pratique o isolamento social</p></td>
<td><p>Evite aglomerações</p></td>
<td><p>Mantenha-se afastado</p></td>
</tr>
</tbody>
</table>
