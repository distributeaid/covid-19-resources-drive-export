---
title: "Dutch Handout - Prevent the Spread Graphic"
driveId: 1HJ_gap0Sx2nar0Jg5YwRcg6Oyx9JXfhE4I491xtRI9g
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:03:45.970Z
---

VOORKOM DE ZIEKTE VAN COVID-19

Was je handen

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/f7dCO_HVjnBas0ETw3DeyF5jnVCG_tZuyoGmAHotDp0by5sNeQLsBsGmLw2gdefCexZ4TxVC6bqVGCbj33w71_Ic4RNaHv5XQwdMdLrl9sMlrS5dEtIBQ79p6uRytBPELUdnwIw5" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/2hd4JyL-_qQUFInILjJKlTLP3Ayt7tscs9r3BW1MYxUOP0B183CwD-2dt40NpoiSBx1kBVljlaTwe5XHLfSkixlXgj4tZEzxDiWERyUIKrPaUQV4KmnMlG_l-Bt3L3LEgBatQvW2" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/1_50swYBFprARCxj1nsXvmfSu11AIpXH7cY5nIL7NW5OYvV-FGyadVorOzqg3u8yoAjhwZOqTLrkJm3J6DVt6Xjuqlsnm5nhZCRUnpfxKpVK_G7XWDus_mvGDErezCKKokHzvoys" /></p></td>
</tr>
<tr class="even">
<td><p>met zeep &amp; schoon water</p></td>
<td><p>voor 20 seconden</p></td>
<td><p>Vaak (meerdere keren op een dag)</p></td>
</tr>
</tbody>
</table>

Hoesten en niezen

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh6.googleusercontent.com/MzSo1Ew0zAfv438BXzmKlKhDqJjj0LZnS5m5Y6Be-pNYzdRce7l-3rmJ9JOh6ZynMpjChodNi03qVs5iQ_rU_TJ7wnQbMRMfvWwYqJPwGIhZf7sh9KfgrFn7GrMTcvuFVa84aJnx" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/-qRXWwqKxv-6HsAqbovn-HRcp9lYxftaKhsBOmevA2JpdcVEd-71bHejGbbNwAuTGTmDmLjeLTNQ91nhCGAotp2NWjYTguKQ36XqJUJ31ilTPRZNeqru9fQJFqkmjHctlZAUD_pW" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/csdg3Plzb_09JDBf2NbN75BB1UlRP5UPiXkUVEsG7DxyeQjfG8Q6OxEmwOdl836Vt5OZwFdt2KfmL22wYmKD8ke7bZTSvWobBG9W_QdEu0xFwB6WGESbnrWHXMBmd0y5C0S9qrZj" /></p></td>
</tr>
<tr class="even">
<td><p>gebruik een papiertje/ zakdoek</p></td>
<td><p>of een elleboog</p></td>
<td><p>niet direct je handen</p></td>
</tr>
</tbody>
</table>

Raak je gezicht niet aan

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/uFO_5ctHqplHECxFoZFKpDn7HWVDFSVpE1FC3wW5M4Qs0TpsiBNynMVgv2YI5A4QKt1WJa9ziiEisiv7o2if1NHQzeLN79D29MoqjAE_yjNCGLJPTqWeCjzARt5rf6RHKvnHoWrh" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/lk5NrW55KuJ3kdiLa3T5SZfdTDipabUjGfaz3TvQOY0dl9Jx1tOSeXxKNkzslLX1_0POX-UQ5y5v7NHW0bbpsbf2RoyOuy006gkVsH4c6I8MgXnBhNHT3n3AWUkIwdD2hxKmqZVY" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/z5ouoXgMLA8lqFE0hOkFiAttYc_-knIBiuPVGVZaB7aIOzduRmaa6TDWtJF9Xl04PGRY9CrYYqzOjDteZHf3ecUxFZHKY8DQKFn7APHCxdWH4EufaU-RbUrO2ddc3W6C9Q964CYc" /></p></td>
</tr>
<tr class="even">
<td><p>raak niet je ogen</p></td>
<td><p>neus</p></td>
<td><p>of mond</p></td>
</tr>
</tbody>
</table>

Hou afstand van elkaar

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/4UuUnMpc9DW3BXN9Ndmk-7sXbciONZaUG2lnvIGOc0hXfgdMb2jX-YBuPtAoFcNrYTdyIb0ydC7pvbMXotK51X_H8OtC1q2HVIzzS-fAgBNF7bvMVK3AHn3THuSa-ZiGj-TOCaF-" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/U2dGuiRUsDmTQuoc4meenajrW6bo1de5P_78Iesa_4VTzuRoLE7oKb0fM5d-gQvnEPMI7BUsm6KnGHiq07okiGAyeYfeOYabQTl0v-azA11fUnyCCchJ6eRoXPAAVRDB2KXB-F0k" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/cySMhyIsXpwTt1D9DnVS1AMx18-IVeKwtGt6QBcz1AKo7Q96FLdtWERUXP4V90IdSJQwuwZC6qWgqHd7lvn8649aSgZj09GjJz8JM5K3YyIqSYLe4KSYvqfFjjmtdOx2A1x_GGlc" /></p></td>
</tr>
<tr class="even">
<td><p>blijf bij je famillie of in je huis</p></td>
<td><p>ga niet naar grote feesten/ groepen</p></td>
<td><p>hou 2 meter afstand van andere mensen</p></td>
</tr>
</tbody>
</table>
