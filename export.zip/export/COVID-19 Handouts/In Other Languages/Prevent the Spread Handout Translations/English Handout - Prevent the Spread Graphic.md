---
title: "English Handout - Prevent the Spread Graphic"
driveId: 1Uvkk5fUlsTZdmSHOXdN3M9fZpwA0fFeGXN9zDrWs0Ao
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:03:59.001Z
---

PREVENT THE SPREAD OF COVID-19

Wash your hands

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/u9lAsZSbZ8EbAjRiT8TupF5sLhJH_rDT3B2D4l1ckfzstDyRydNWtXJ1IkHfYc5R_YhEBLYlVubYPLC1pyxyG3WjjeORCtnD5olLY0uVB_wzEnXPCi2H6ngMNTRGiCvOR9U1HC3_" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/rmi33fIaRT-ZuTyO4FgJxRJ24IUwUpnMG8Z4TqQwp7CVdLH477Q8nzHRw8ifM2mrl92vW7RFln1KHDbNKqaLgxcO-zfMd6F3i5kjnmU8hgYjLg1nbeR-XQVI4lQ8R3oYMBvv-WVP" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/xsPAcjGHxFA_3KvShHGKnynsinRVGdcZAx-9wuYN8lBfvm1h4bhTpUHAzJpEa-dm_ke8KoUCsPQ2sp7aWwYhRxWqTUb6cwwQpKmu6XyIkxd43Uyx1hT0cGAOJSgvEXNKaJJSAej5" /></p></td>
</tr>
<tr class="even">
<td><p>with soap &amp; clean water</p></td>
<td><p>for 20 seconds</p></td>
<td><p>frequently</p></td>
</tr>
</tbody>
</table>

Cover your cough

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/pr1QiHpGhdLPNl0TUqHWGLGilT5BmaLVN3cgUSRJzIeJVORgES0Fat7yrhQLzTsr3A7Y78sxWtkmGIh_vfZwdTcKbXTkpZONymMljz7TiIaQBqCUmlm9_XEaMJBu5xpJASZtmfQf" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/3xicTaV6sJB8HV2eschYk--YSnLzjstYIXyZH35mBasiLm0qLRFS0ahP4cXBJ-V4IutdyFxQngUzNgc_GDNYGgHqLo6RwIuzTEef8oEnvM80lGvzcc1MF9Quqx9g089NFnqg8II-" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/_eqR3bKWqsOPJitYBBGDyfQrFQF-lX_IUtE0S7SbaZBI_dEN5tSE0MML5g_57xytCFoYFeisnhYU7mboMirreakqfaEpjE7Og3EloNfqfcK4JT0Rja3yTD81CvSVWEHENg-gJnf6" /></p></td>
</tr>
<tr class="even">
<td><p>use a tissue</p></td>
<td><p>or your elbow</p></td>
<td><p>not your hands</p></td>
</tr>
</tbody>
</table>

Avoid your face

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/fJ_LxDblxWkzXb6kUgyfkNLCRBQAxDZNg6ssvOL653a9BA1uCeCPwR2k4svtMXmwZe4RJDg70xJ073h8nDDmztMsLGASABZc7NI_QFxT0T_sg5TmZ3Lfu7XIZpviLPuTBvX0mWB4" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/PujnFkXr00tKFjmceHaOQDW2LaYhvs2JrA-tdiLbIskB2hYt1CWC22uXGc6mNuENHyihW6esAreO9ju42HsKavV8Gb_wN3C5OgkixzL47P8L8NgQpToyTwOUJhD5EfWUzumko67b" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/JAlMJBve8CS4HF2G9VuZhS9VgocFnvjEM765FaV5ko_EBnJ-2JqVZQW5PszHdtP-DK-eSTCOGiG41OWUEX7iVY-WGYmIxUk_nbM9gnFXXOdEk6uMlQR-0Xd_V0Z-75L2P24AlMMt" /></p></td>
</tr>
<tr class="even">
<td><p>don’t touch eyes</p></td>
<td><p>nose</p></td>
<td><p>or mouth</p></td>
</tr>
</tbody>
</table>

Keep your distance

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/x-14q8V1GOdJy5Ql_rBXfuL195XjM_BHvpx_17VzAL9bcD1lM0q5MMsGHDSu04eIEo8GoDXwpkUqs-aew1paXN6GnlJF-ww8ZgRfGRP8qp5nZ9MDOri3EDIUQ8m3S3j_Z5sVLJ2s" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/fRTVFo9dkdvNcdQFojCrwrGnzpw7yjmlviAjrcHe6jYrLnYXCabzlDGyq0tOUzLAc-aaDxraCOoPspFVN0-oPkjk2Xdbp6F4GwijRJ9ZCQ44PRryqJBhg39s_Sir8clSxyZM4LcF" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/WwO8k12LjlKSR-FHpNJr1tdG-KQAnjBQd4SzMF4ci7kXg-Wwhjpu1lMddY_K58tuKZ39IBSCZqa6ciZW06SoUAgrcxT_PbPBMdDLgIehZLKMqXk2ifSXFe7AdWyELOOsLv3ALBfH" /></p></td>
</tr>
<tr class="even">
<td><p>practice social distance</p></td>
<td><p>avoid large gatherings</p></td>
<td><p>stay out of reach</p></td>
</tr>
</tbody>
</table>
