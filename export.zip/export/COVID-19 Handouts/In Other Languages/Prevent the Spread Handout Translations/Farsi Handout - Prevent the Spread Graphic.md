---
title: "Farsi Handout - Prevent the Spread Graphic"
driveId: 1Jdk-nt-UQXDl6ERcDzEFIUGOb975VmaXt3X-t12-95g
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:04:11.201Z
---

جلوگیری از شیوع ویروس کرونا (Covid 19)

دست های خود را بشویید

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/TGrcmJPvOVvR-W6h9UVATU2smNLCYNXcGAz_kXalFahokXbzvzz3R5OMsQtjkdwfRGgzBONROZ4q9kI13F1PPZsYbslaLPUyct8eM1Xsl9mhSPmW7wuFfIYPB3TzC6w_BvHt1WfJ" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/XIM51co2fMV7AL4wrPgcDowSaWu-cIwugBXNYmygmaV2QZPxl6aXPHaBrTsFPYSDe3EsJEne--jecr4o69xiQVnHnNsvzjNwCFu6y_wTM22CFjcUJ0Zqv01EHAyB1pIaEmR1HhJ-" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/F4jA0Q0Ub9P8skfWD53Sx8-JeEmaae-1wJ0SdcRIg-9zbIfEEmMB8A2414yFsc0R1YB1igy0BZa-cT0U1IzebTb8RMJovNpoN0POq_uclLCLyJaNw8Ddh4rNYImFgZMpmwierHr_" /></p></td>
</tr>
<tr class="even">
<td><p>غالبا</p>
<p></p></td>
<td><p>برای ۲۰ ثانیه</p></td>
<td><p>با صابون و آب</p></td>
</tr>
</tbody>
</table>

به هنگام سرفه و عطسه دهن خود را بپوشانید

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/oUiiN_69V9vq55oE2aJJ1FKHWM1e7r3SZBvB-uJdiysWoSPMF8-fkXs7D9NBoeSSd0ykctp1szF5FTI16ZpQJhR4SqKU84IoBvfVpdKhw9uuc4Kz-uOn_QObZQUfrc40cgQ8B9y1" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/yyPajccmSyTPAiYcofZl8g7L_OBQRlHwml8gVkY6xnv9-_pm4tFf1SH_oxRmOFHDd4VxfjSFSsyK-xeDmrZPqN0i2aR-XJi1K4xmcbgQvcYydrg3Ynf8Qm_lRXqCq6KOxgvq2B1D" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/AoaxYEI9aM1fbnscZVPSHM8ASQeUnrX060Sl1afcicT6RSUcqRRlsLnVPDoRshIrgI4FTee8wJCU3bkhbrqdFnz7Kk8yQK9xLVX3nImWAYecfMpS5L6skvANB34RaKWtZjz98Pvi" /></p></td>
</tr>
<tr class="even">
<td><p>نه از دست خود</p></td>
<td><p>یا آرنج خود</p></td>
<td><p>از دستمال کاغذی استفاده کنید</p></td>
</tr>
</tbody>
</table>

صورت خود را دست نزنید

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/LCtE45WtkI-HNhKTiM39K-oWyQGOt-zmUWQrdhizDIPfQmtZf0Ne7V9X-goIRequ21YHriQ9ySY0LXEhRa2k48yx0dqRdnyDr4sWu30EIF2rxqrXlVPgJVXC8VF5z21ZVZSORRPa" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/uKuhfb25rzCXTbvFQirZMmaXkPgPbceaGAKC5VWhk8qtG3Tn57Eb8e9Xdne191TOa6WfcBpAIQh08xXA4DFhl13AwBnSELlUnPC6YIueHnUnTSNisB-hHq5enlt7o2YnmBVn_H1D" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/rP557ulUaAd23IFX2OQ9lvrojukir4FkIKckgWlz1BNJeEtXGBSVQQhglcCyImuRi0bL4beU3Ac80rhNouPch9tNGH30q8Pt6OXg7v-iK3kNUUnDLj_4TiXzH-VV1hQhhTwuz5AA" /></p></td>
</tr>
<tr class="even">
<td><p>چشم ها</p></td>
<td><p>بینی</p></td>
<td><p>دهن</p></td>
</tr>
</tbody>
</table>

فاصله خود را نگه دارید

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/v2R2TqjvIo0lMSzcB56cNlcoPUC5TxsAhRmY3z4v7tK3_LEQ-l9-eS6yndZwaSId0sLsGVDvzBV4HVeigl3gL56ull-I1kyk2Uvgq1oC9Uh9FXDAUleJjL2nWvRBvbOI84XtaVWv" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/1_ArWSzrFpTKDO3btPhH2L93ApPs8yDxXo3OOz8a8OaXvq902R5RM_hrMEpZ27uhUkNJvrbuD6Kr8u6XZ_KMCcS4L4feyPq-DkSROLh4e18OhQR-IGNsXwkO7IUPxhed5YdYDLv4" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/cbGvRYS_c4TFBtmRb9LwURnnuwpPppPcvgHdqVEpWkx6zBqMNJwuygLlh5_MSpvlvzPe7hkmkSPJ3rTetFaZXWZEy9lgDNEdeEbutthiKiY-BexkGskbkq_wmLfIYaC9Kk0PMoGq" /></p></td>
</tr>
<tr class="even">
<td><p> حفظ فاصله با افراد دیگر</p>
<p></p></td>
<td><p>اجتماعات بزرگ را جلوگیری کنید</p>
<p></p></td>
<td><p> دور از دسترس دیگران بمانید</p></td>
</tr>
</tbody>
</table>
