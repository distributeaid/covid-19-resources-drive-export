---
title: "Spanish Handout - Prevent the Spread Graphic"
driveId: 1ZYKEPSEhDWrseHoKboob82L2WuyuCbUVLy9E-3OGjaM
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:02:37.165Z
---

PREVENGA LA PROPAGACIÓN DE COVID-19

Lave sus manos

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh6.googleusercontent.com/RTw_2wi_ZRKEsF5q66f1bczUMuYsMJWGQ2d2z1FvrMoFhHpxbR-Vh5fziofG9dBOaGXxjH2Eh1niE18p3VyOY4ZlgT-P9lqGPm3KZxM6gk5qYapUhI_SnvmdhKxxr-HRFKOpY9UY" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/JQZlYSz0CegMb3oIeBN7LgQ_6Ogg03hdv_MONclIDdlLw3uNDjS58BzHq6f_X6J5n96KszcQTuJTD2mitIEBNbp97s_JDCAxD9h6hJVzSQkQGqIiFOaJo2AoacxeOjTwhCNEJ3Li" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/Kbukmbc8q2IRK24OleHmHCxl5CSjUphBrDxQul8sDkwEpYnXT2JmZ4YFKVSwfopFdRoQfz0_2rLsUC96MK0Dv79siFW0BM88-fdTc1sO0ceqF8rcD0InvbMuq7D4pPlnbS81oWFi" /></p></td>
</tr>
<tr class="even">
<td><p>con jabón y agua limpia</p></td>
<td><p>por 20 segundos</p></td>
<td><p>frecuentemente</p></td>
</tr>
</tbody>
</table>

Cúbrase su tos

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh6.googleusercontent.com/by2pfsKgDwbK-sCuCSg6sMt5Zg_kvIXh3wPr4Ogb-x-oYI1UCJFyFGYmbDK96GLC2bwDRcxfvBPEANDIDC0C2D5wdtiI3dbT_TtyXBncMWLoLZKJ-1uD73_Dy_ldUrIKOJ7PWYRU" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/4Kr4QYhakjIudMAph4Epj9fQuGQmGYScLLfYuPaw_BVCzDGFA9q_PfEgKFS1tUIomLT9VjpO_EkhnOyP7ymTwveCpOyN79NT8T3okVzOvJwFqs6Mzzfh1SlOyRVjXzZrwcVFsad_" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/jdXzNwgafkM7MoMgmu7iw-8CKFoWsfKM13mGHvUffKkyAWPztjqntfklpHgtG1Pln88NOGo06lJMH8NeWymh6Jue6awLXUke1j6cUGrI07fg76lEz6qX0aZXHEkmF4I770o0x2Y9" /></p></td>
</tr>
<tr class="even">
<td><p>use un pañuelo</p></td>
<td><p>o su codo</p></td>
<td><p>¡no use sus manos!</p></td>
</tr>
</tbody>
</table>

Evite su cara

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/Lt0NIx1gLhrdGvhnqncahmhHfeloVfY-p151dkZj57eKiYGzUvla9UcRB1_WZsZvXjHQnF_ECkN6o7wQ_7P788Z1mrOu97UUp3KrPUD90igglWxuKyH5g7xQjUY6A20ACEqCIH7L" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/99kSOgc3Xgr_G9PztgQo59dj7noHjQuOnFwVCneJrc5uitj8UuwVqV2AVCjyJ1TIlhIzJVumjCgQkRcetCzUag8hPC9U2PIO3894y6NKjFPotE_QuWrAYvQPOP2kLSZkMP7wk7SY" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/dhxM6q2HEa33VaQmjWf4Pm6F3EyP1Ol0f3n-GUBKR2aF9Zk6nLjJpX0Wj9z5XBUcY0Se1ziYILfsGqlZYZfdBW1iOdyxyizCNDpSu6d2plqUdOs9qGFlAf88d875z_wZR4N0mYSa" /></p></td>
</tr>
<tr class="even">
<td><p>no toque sus ojos</p></td>
<td><p>nariz</p></td>
<td><p>o boca</p></td>
</tr>
</tbody>
</table>

Mantenga una distancia

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/T4SfVwT_fxJI5qTwD_KDJjIyfZd4WIUWi_5LB9AypthVqX8oTHOnLbxtDcXdzLP7_LWnTvp-IoDSu0nn4mqYNDMie8yde9Qvag5iw7VBPxHnX0f0k1NPu4PKcU6IS4RaPTkYHm1o" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/CF8vTDTCWAU0LVySRrnqXJhAgfqvdGDdI7lOQSTs-CclmO9p36OOKGVPLLGQAtuT4MQuTnUEpwH5GOnVGhBsZZ8qiYLWTA8jEZ9ki3PNNcUIqWlg6QuegEsxdX7Ua-KKboI-tdCS" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/Gn44cpBP91eAiot9p0E5I3KLmUWpwGQyv_oDvXLRbyueGzw2PXi1rndB9SnQay9Vdh6n5lqijU6vFRcSAa6ZpkF3HmQmmlzfBKXl4NqawWO-60sHfdDR4qHPnIUpBzNpUlVLhj41" /></p></td>
</tr>
<tr class="even">
<td><p>pratique “distancia social”</p></td>
<td><p>evite las reuniones grandes</p></td>
<td><p>manténgase fuera del alcance</p></td>
</tr>
</tbody>
</table>
