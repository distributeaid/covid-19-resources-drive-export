---
title: "Turkish Handout - Prevent the Spread Graphic"
driveId: 1O7fo4C9RM1ebNmRbNiLG0VNqQKfWUz3HjsYRKxRBXK8
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:02:23.465Z
---

COVID-19’in yayılmasını engelleyin

Ellerinizi yıkayın

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/bOhmLlyTJknLL1-7oYdhwSvyRchNPi6q40bZMH-36pjE9g9aFUh9kmIzM_D36oMFxq_PdYo2PQ88j6Gr_OkGJZl7Q_7sTD5NIRAvjBsTnM3YvgmXyADvbcPr0jgD1ZNckczN9K46" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/hJnIQxEwEXEWtsZq_xOe7OuTuNODSYjBidcs32SUpsJoIgEE2eLMcrCTZ2ZnvduDeCKJMrPRDm9FKwDFlraCA05eh5xlAnbxQAPMoP_h4KjYjLpjQQ2cA67XlACdnvqZV5aGbHz1" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/ZaeB3zvzCt3aDbsQp3J0JX-ykPrmsKvbw74JxpXVFUvj_Y1CG51ZtTHjuvTHBFdqkb1StSdrM_tyyvX2IeiImekaK1RM9HYtijtTjjkM1hOmZsyj6BQ4_zneF0NFQLLCAoSLg4vx" /></p></td>
</tr>
<tr class="even">
<td><p>Temiz su ve sabunla</p></td>
<td><p>20 saniye süresince</p></td>
<td><p>Ve sık sık</p></td>
</tr>
</tbody>
</table>

Öksürürken ağzınızı kapatın

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/lG46DhIEWVEiyYQZSOIni_Jkmo86eAs-mhPjnJNalNLWKwRVQMhEzp4UzYpvepC5hs_fcdud8ABjc7qV89jGpNeuwjqAsoUFxpGwKawavipT6QPbwh0B13OUJ0pSEmhdgNT0g1dj" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/v4pOxcjuHfPCdFX6uLWPV41DeyvT_P1PZ0RBNHE4XqEHN5S2vcExMG5CrqXQyvMoSJNFTiEF0A53lSBwPpkHtL2WCmVte8W6TgYtqFElAv1C54mqqM4msKWnbo4C9fwXvpmL0E4P" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/C0YxSRK_3hxrltAzhMlR59UpKHVEle2sTizIUpFUSkmCTAAzh-8cAUJh-moCnS0-lmvNnfWcY2vmGlOHzcd_IYlLD7KVdgbffR_QtviG-MlK14Kv_4t-PqLQR2Wve9wkYYWmHFCB" /></p></td>
</tr>
<tr class="even">
<td><p>Kağıt mendil kullanın</p></td>
<td><p>Dirsek içini kullanın</p></td>
<td><p>Ellerinize öksürmeyin</p></td>
</tr>
</tbody>
</table>

Yüzünüze dokunmayın

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/UreoGPUBKaJGX6FhYVkuuU-Bl6MsZl6hUSIu9D9CtetpSMDIYkfPiV0cqH_cUkWRqxtjH6YD51Mt9DsYVosGE0R7H4Pf4dsEmUjgvToFjqA84SxrzZgznGMuBIq2RWgYIymZJ3sw" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/qzhou3yEJwkIY8Ie8EiJBc37VXTZrxV5Zh5QwIaIDCUDPE0g_3niKhjNmXqPuhduw_oiprh8DYrsP0jWNciowp_CkCpCRD4IhiR8h1lv8v37aa0QKi7_Psdo_o7ydLID01lEJ70u" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/1g47hpzYvVkFmI04yoqURzuNVzAS_s8DdLd0AHpbEs8KMmOQOWSUjaQ-T1KdhudXhNTXzvzef-WCOudLA7sdnUhZucjJU0aKzLquBU4iha9HFt4SHaGKISk9wRGUjsPolruYAaBI" /></p></td>
</tr>
<tr class="even">
<td><p>Özellikle gözlerinize</p></td>
<td><p>burnunuza</p></td>
<td><p>ya da ağzınıza</p></td>
</tr>
</tbody>
</table>

Mesafenizi koruyun

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/PCmejKOS3yXaBxiUKltbQ21ekmONoVkNBezxzb4PRpkLGhaZl15MjuckhXTzxKr4fGH-w7r_WT3JEYlj6VIPi71z817hpDR1oaZdG0F6T3l-2HdL7Sm9OWznrzhuC3vje5cB9zL4" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/I2QTiAJ5HN97Ls5WxKjY9EHZHP_u4H-BPmSwjt8p_5v8FJ7ZSv0uR9PSpur3OwG4LZKNhYuoFX2_qvcxSs4wA3Itr6d7HX-zN1RfL2cp-d4kPb7v2FzCpQoMGxKUWxmmNOpnd5Sr" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/TQKyBxiqIjqI-TH2edWoflU8i2AtW7f-IoYc8N7iVuYjVazA0gcgBRUPlH9TLlFkQ_1e6OuFxWqbf9LvSwb0R3vj5hg2a1oiycq3RIk8lWIV8jlimArizNpR43KcrepLPfd2Rh34" /></p></td>
</tr>
<tr class="even">
<td><p>Sosyal izolasyon uygulayın, evinizde kalın</p></td>
<td><p>Kalabalık ortamlara girmeyin</p></td>
<td><p>Diğer insanlara 2m’den fazla yaklaşmayın</p></td>
</tr>
</tbody>
</table>
