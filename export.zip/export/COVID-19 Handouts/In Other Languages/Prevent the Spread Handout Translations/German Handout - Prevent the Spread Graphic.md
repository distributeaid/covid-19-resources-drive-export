---
title: "German Handout - Prevent the Spread Graphic"
driveId: 1fP99QSzdyKPYVU5VKxWDT1GaLMjO37ze73HDM7rapuA
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-05-07T14:56:36.786Z
---

VERHINDERE DIE AUSBREITUNG VON COVID-19

Wasche Deine Hände

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh6.googleusercontent.com/R3gCM2Gwh1MqrG3MFVjvbCBU6bbLF4VzaGbrVzaHo4R91vbka5m-I67cP7p8XAOZ86ov3cQ3ztcbRuiqBKFe6x1QozBH4tscl8pk1EN-QOdvZiZGimZ47QNHv6jhn_ibcLIcHEoi" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/n7Lc6TbcagkapLdC0_IpQkqKqsbWCAkDz7rKzfyj7OEAAYUpHpu6ciyPrrdscnNiGG3qD6VX-W8neW3aPYLIejJd1zDRCvb-Gia9zUPnHGTM8BwDNN08kOiRcsiM4HdaXQ-HrqiT" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/mJnc_Sr1bYyNGeTpYtYlK90Aa_4HtZz7ghqYRlt4AlInoijNR8dsm2zCfvcYAYJHwuHmipLFAniQ4tbpOwajUudDfIbn_nqMJNyI2vozpb4xNGQq4eeJtRBq73CKSlRHwZ-vIJdV" /></p></td>
</tr>
<tr class="even">
<td><p>mit Seife und Wasser</p></td>
<td><p>mindestens 20 Sekunden lang</p></td>
<td><p>mehrmals am Tag</p></td>
</tr>
</tbody>
</table>

Husten und Niesen

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/_Y_rtR-zioUHr4qUzcOO4T5KuszFXJ8JfmvLTuk2Wsat7uc8dcJ2J5Gt34cMWqrUkNL9fGUYeNbFb6DQUNiaH4OdZ1eqw_TkOzMP6Suf9FF1gRbyizKSp37rp5E4m7pINOZGxIa5" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/bik-OnYLGWuG_-Ba072d8JEaRfpL5Pj00CZ1RMh9qh-6FyMuBIRTGIqmU_TBBXlFFX6ZztbyRpCoDGpgijjhw0PI09-vnDJJAh-DNkkZu9h6Vsmclp-LsT5BkAKLxYL3SsD1ruI7" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/xZYS-kc9cP8fcvkz8QKaVxW_nsmqQ-2OZIZpySMelALWtaSlQ2Osd0BKfd8iB5cGENH8JUbCwIA8pi9T_3S8yN9vQ4_kPsk_3j572OysVTs3XJm1tYZk8nnMfEbJNYVBOWz-G08Z" /></p></td>
</tr>
<tr class="even">
<td><p>in ein Taschentuch</p></td>
<td><p>oder in Deinen Ellenbogen</p></td>
<td><p>Nicht in Deine Hände!</p></td>
</tr>
</tbody>
</table>

Berühre Dein Gesicht nicht

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/p4VlnMfUbINxe0qsE13oGBcB4xvLuHOa-6c00j_HSNjMet0B7cASYBGADFZ92EX6qEwfwof_Dw2sfP9mU5k3c-dZcWzJWE_ooADYP7s4Dk_QpBx6Z2gE5yy3mn-2akLxEa-7PEew" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/a-wYHb7HKyHitLA8N4MbF18v9KNSZqh3vFnhOoCVtWy14OKh726gwVJcE1uD99xYt8h97ro_t3txm-lotNgw6IZYBTPB9jG_wURlmEfMxYIwOV3QsNJ0FxhwiOpkM5r69lQKjGOx" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/xyGgdK6VXnPhvgLW9-_F1QO9Iw7Q9BkR8-J6IEHoW9LbgbmXTNp_pt1jT-pp0TEaWZ0w3dCEK3eN0Bezl9cwy-wk61-rv7J1vfCfxp4BtTEUfDWGJuqfI8JXys8vKYtfj0ADXR4u" /></p></td>
</tr>
<tr class="even">
<td><p>Weder Deine Augen</p></td>
<td><p>noch Deine Nase</p></td>
<td><p>Oder Deinen Mund</p></td>
</tr>
</tbody>
</table>

Abstand halten

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/g8_-A5VF5V3IgN4lsP-ZOCIAHA2nBqoUrPsVjDmLIlV6M7a86KxvxUAxhtABEJMRDYSMlmloZxZmGWtg_h4ovbJe4kb8BMLaLxunttaw3WDCYP7vlMRCEKsJOkR_YqxOrJtvshFl" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/0bcKT-OsqrAOkZOqnCrQZWkSA7TikaCTCwe2MyWnoV_yu55i0Odt-Qh0hifdz0qAmlDwBh3Ynp8YG5Ytw-9n4bz7zOROzDDMbePvPh2GPj0qQ-AWso0NnOGQn4d7A7wBgSEjRibl" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/vRKri2gBZhJ5TpPcPE0m7kAAry4uR1UMYEKHyjHcyyY3ZfjslZkkM9PhkNUn120zirPqgwdzGDimHPW63hOdZaz7q5iUtkhP7oP5ztfJce6gpjNEqnSb1rp03TmIS5QrVPj2pdPe" /></p></td>
</tr>
<tr class="even">
<td><p>Bleib bei Deiner Familie und in Deinem Haus oder Wohnung</p></td>
<td><p>Vermeide Parties undGruppen!  </p></td>
<td><p>Halte 2 Meter Abstand zunderen</p></td>
</tr>
</tbody>
</table>
