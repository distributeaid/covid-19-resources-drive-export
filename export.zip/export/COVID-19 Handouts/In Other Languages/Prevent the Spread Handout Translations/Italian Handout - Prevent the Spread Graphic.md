---
title: "Italian Handout - Prevent the Spread Graphic"
driveId: 1sEY31xMxxuklsWezoHlT8gHS1YJB3c3QEdm0tL8FLIA
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:03:21.892Z
---

PREVIENI LA DIFFUSIONE DEL COVID-19

Lavati le mani

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/8NsMhOBJRVO9Ji0CxinJ3tMtmpesoWWDniJ5i-xNEWnHevMYBUQGBqPQJgDY_HesP59lnQdFn2EmYVQeRBrRJRzDsp3mlkHsHeiSv8-tXcSrhEqSwCOFYZFytZ-d5yBsp4w--3lG" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/JXOg-zeSWbK0pn4KsMUIus62VVXElxPN9Mqhd0md0yWcAkk4Jquw1BIdo2ZpRhmR1kiGz9OGZlDIZaB3V1vRTmpwaU55nBI3BcHtsoqHrAgANhkzyuYl8oMHTQPS7TGjm8yP5Gcf" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/d6RW36S0ccPoghY0gQJTm7DFjkmE3wziSAuAgQP6lwX7uzmo_5sGQ18-abpEJSMumk5Q-KxE4ryziBb8VgoYgb0d69EgjCytknMV__V0bm_yGJn9iioCfZfIIK14gR6J6o4aDIhr" /></p></td>
</tr>
<tr class="even">
<td><p>con sapone e acqua pulita</p></td>
<td><p>per 20 secondi</p></td>
<td><p>spesso</p></td>
</tr>
</tbody>
</table>

Copri la bocca quando tossisci

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh6.googleusercontent.com/nfXVoxwDg3Bfn57JvEBt4C4XDOvpxohVPqW8CgI2x_P6p2hJiDU_zGlcNGJll1JKmEA8pLUxbuDu0pA6fWgtIdt0XvzNb-LqduZE7r3p-UVQvtMTlyDFcC7Bf3tRUsEP0T4Ub6TL" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/Qsf9bYjMmzm4xkelOE33O8GU2rdO1zMEzjE6FXTWP253s2DJ7kT3Q1O3JwiVxo1DL6XB3u5n5W_WJ_pcGgQycGJ50CliwfM3HhjfGsDJHC1t8qTI1uXFtWslQ-KvZTnVXbKwLO38" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/e-ji3XnTofdyv35v3H8_0bOFVXQiMsNUD3A1ic2PBLeqxATfzcNQf5Ya4asvu16KYXznKOg1YIQx_azh1J51e-zygGxGpojncCdxFRNBWXWcADcTlJax-YHjhvPs40qCpIz8GivL" /></p></td>
</tr>
<tr class="even">
<td><p>usa un fazzoletto</p></td>
<td><p>o il gomito</p></td>
<td><p>non le tue mani</p></td>
</tr>
</tbody>
</table>

Non toccare la faccia

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/hLSWOKn_FSoee8VbQas9Z8_iUMVlFnIlXy7pwQdB163s2DqXcZp1uDPIM7LpeVE0z0GatkhebK93Z2txN8OiavtmIgavAEnj0Wyo0E-qqaNgvLbWJWEhg7E9nfbqNurOpKppQE0A" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/M1-yEcc1vk9gM4tZhPlqKo78_2EYWQ3g39u33kpCVgcMLHrQno3C9sd3WhfewovP-xcORofCAZqlTJ8WriUFwJ1c2kf-kVl2C8jlPi2UZ_0tNGx8Sf3zYFFO_4wZ2ir7zhOCYHUW" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/XbC5sXYzC0_CRdYlDUQ6Ozu5DdqKcLQblpMKPHsXjS5uMgHreB0desJnHulHCFau8sNRwjugXhtDvb-zhQbEGYFIsRNwOO0belp7_UkEAud3p5tp-gcoeGvZml531BXnY3lVodUh" /></p></td>
</tr>
<tr class="even">
<td><p>Non toccare gli occhi</p></td>
<td><p>Il naso</p></td>
<td><p>O la bocca</p></td>
</tr>
</tbody>
</table>

Mantieni le distanze

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/ROAkgN8YLSIsDPam6j5RRIJcaCI5yJHveijH3q_cGKbqaiBJLHUzcU0rnAZmDktnXjS2aLGNKMvnm-cpj9pV_ZNl_3HEVkXYydyV39ieQeBEy8QY2KMRsTOT7S0yjc5OZd2NuTTz" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/-POHWggTQyTYyhKog_u9MHqAUGJIDuoReztPkx33SYYo1GszSeM0hTrQuTvI0GGkNk44PhE2LVsQZaTF74m_V27BWwDWZ3Zqgo2nRGrbsbPDmLuLVGiX3lz25uoEvsV3o4bnP-Pe" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/68xCpRez-pL5_kjJ1o2WM8kBoQ-OsT83JZlMDBUw3YI2SPsvqQ3i4u-4HrOGD57YiKSf-_jVT9ssik5Fp-wMYDHqbQTmhr4Zq0k2Pk7fvuO7YjFrylcj775Tf6BpNpRLvaDJ0QhR" /></p></td>
</tr>
<tr class="even">
<td><p>Pratica la distanza sociale</p></td>
<td><p>evita gruppi larghi</p></td>
<td><p>stai fuori dalla portata</p></td>
</tr>
</tbody>
</table>
