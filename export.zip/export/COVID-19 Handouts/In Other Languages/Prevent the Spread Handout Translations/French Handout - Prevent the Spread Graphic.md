---
title: "French Handout - Prevent the Spread Graphic"
driveId: 139X3CRTVl8M1KvEscCnR-ZgyMQ4inSFANe0b5hb0Of4
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-05-06T15:09:52.041Z
---

PREVENT THE SPREAD OF COVID-19

Lavez-vous les mains

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/Jcm-nZ9LXPc_R6vc5MYunLEHWlJb2YY5rd8c2yTogAevUdhebeHNqKQFbhGv01b1G3vQh1zy8dnIhleGRSDrnwTpna9dRxnMMCW8434ih_gHh8M6QZRMcj3rhuBy0pslbf_2wgKa" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/DHbyDP8sUv1-u8UuESynkADGfLBtNHRZCuQKKXU1HpduJq01gLH0_yWJeNMsNLfI1AwLxFJnaT0Qn-es_9ukjgKGaq6DFW_OpOBb8YIp9FvohPqip0YK3GY8YxEgO419C-MB26Gj" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/rM1a42kgA9Xzx7dwwPZYblDkYzbxQXl7ESRInHi_0Z19XZk6sKC0X-D8wawUT3Uej7MSM90141Lp2irYuPlUWT2pufJ09BKjklY3d7yKpbDy-Rcmp1IqcIu22Kp_M7baq9_y01NF" /></p></td>
</tr>
<tr class="even">
<td><p>Avec du savon et de l’eau propre</p></td>
<td><p>pendant 20 secondes</p></td>
<td><p>frequemment</p></td>
</tr>
</tbody>
</table>

Couvrez votre toux

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/jjhB3olR2z47s-3Z7meplPFnuAwM7iSsbPQYFLeNaIF4lgRXhH8chhwqRUXZnrgxK6e7SsI4pXA-P9SKGQVu2fKcNvt8diP63U7r819Su2DAyBodNhDlKHib0KW_wCl4hTExLckn" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/srIOafu2bXecDSFTNQLJ5ERzNb6zeT9hb3X-q6fBElPmxsstgrBzFgMFz54v3KNPlBlrKlRgf0_-L0G6nCi76y7-4dJOmDNLNqHS4y-HeFhVhv3F1E4P9VhR89SXHcOSaQNsmqK5" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/n_Bmh1-0Pqe9YfWGu-_A4xYwS0ibr_Ouab6X7T0mX3o_IlJh4T1qMyCcNP4cBxKUzsL96P3s2vM1rHMT4biED9CYDeny0vuPNczIF5GjYCDpEFg6HuW4njh9jffRueg1le_blpd9" /></p></td>
</tr>
<tr class="even">
<td><p>Tousser dans un mouchoir</p></td>
<td><p>Ou dans votre coude</p></td>
<td><p>Mais pas dans vos mains</p></td>
</tr>
</tbody>
</table>

Ne touchez pas votre visage

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/MXhSAvyKhinJu8vUjM4YOEz3saQzR1OjQkDbBvLLa1eB09vh5e86-qpoBRKghWydaB8qhHQdTTb5QkvnVwwCCAcTWTl2RUjpKO1lPeOJoZTs3uzl4_XE_oZ2kK8cOgs6t3acmwX1" /></p></td>
<td><p><img src="https://lh4.googleusercontent.com/Pa-5d--65YL6GTorGdQ7t1mCNiyVw8TMF7_qxypTKIFBPjmpSdyqfHq77dKLZR8d2V-k6cncrRUmwvVc8bGV6TRn-ZdsE-5Gk6Z2del5vCBPGjMdnimHJ1-vXQKRqkVCAOVHUM6X" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/65h6RVxWGUOm-enq8lCIPUd9waehJ6CJDU1ZaNOP7DGIsfPqc_p9azKZDs2HhFxN6knwaTaGvp3q4zo9emGtvGTus8lfRPreGrzXjYPhqelfFCn5wvO7840Y2wn6S3WuIW3jLrqV" /></p></td>
</tr>
<tr class="even">
<td><p>Ne touchez ni vos yeux</p></td>
<td><p>Ni le nez</p></td>
<td><p>Ni la bouche</p></td>
</tr>
</tbody>
</table>

Gardez vos distances

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/m_a3uJyMiHVzTshlp3UueZzyRxn_CC10CVVb0GF2ZO1rIh3kxDtjq1Ba35vaFxOOOzjKT-mddnZNnwUxXH6QpJX6iZlpETBt_Id0Ql_nJnn8zLQkILONll8MSHqoa8npp0h2C1r7" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/Ftbk39WabojaYpF8gBr7P5n4QpzUZyNfvtTMCQ6Pj9fBvuELUV_feZen_sCvb6ZgRJJb1gBwzVNgu3iBmq4IE4PpNrQLtVWsZG7mR57ADNzRDvG-H5EHzxTAVHQZzYmZv77MnlMR" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/IGu73-zDcTGzyznjJ0g4N6XWl2bqbUsjqWk98EZ3EvVaKjXGdD-OSXt1st96GRTmQryTQNCQ8tz9ECkw3TfYIMs-Nk6zmOOOV2h5Izz6VD4ONaFpzVOk_1kXIkAeXJp1AAuryixk" /></p></td>
</tr>
<tr class="even">
<td><p>Pratiquer la distance sociale</p></td>
<td><p>Éviter les rassemblements</p></td>
<td><p>Rester à distance des autres</p></td>
</tr>
</tbody>
</table>
