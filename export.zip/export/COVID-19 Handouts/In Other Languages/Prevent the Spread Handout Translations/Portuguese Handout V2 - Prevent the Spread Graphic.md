---
title: "Portuguese Handout V2 - Prevent the Spread Graphic"
driveId: 1S8vWKmClnSalgHYeytQwrZ0ZU4nQNpAaUudzwhf-Q88
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T00:53:57.873Z
---

PREVINA A PROPAGAÇÃO DO COVID-19

Lave suas mãos

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh5.googleusercontent.com/riJ82wtQ8f-bXAktqoKNNLm-TLMDnDTwTWy8CLW5PeuQZZU_5TFQ-BwSFtbKI3AbmeYbt6ZhR8ESAbCUTNOjDXDLLb5wbAAF68aSsDz5fFMmPV3wxHlcP8k8ib3xZLYVNfRVzB0B" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/P2NNs4nbLMLoR9gkH1YXuy3P21Y4tkuILhQdC8dMAhg-h249lvd5hFGfAXOsAbT3CFclb4XG_oj8NUfwPpr2BOZ5FnUxe6mSo1JIJqpZKjZkKjIhsIFmJk_QvETCQNyfmNnAImMV" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/HdWldDVdz_b65dYjhrLLFRH7RUuBAxXZ7aO-Sc2J9tQzeRVHzeIbNpk1URiyY529m0D-3uCf_RcLyT0zQ9ufyzbrzXEKMZOh_GrW1qEHgvcSmIUFJoh2o1pDOjmMXhjUbVCbUCsW" /></p></td>
</tr>
<tr class="even">
<td><p>com sabão e água limpa</p></td>
<td><p>por 20 segundos</p></td>
<td><p>frequentemente</p></td>
</tr>
</tbody>
</table>

Cubra sua tosse

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh4.googleusercontent.com/QhcXEgWXao2q3nCMRRckeiBQNw3XUwT0gcKCfDrph8GGK7prXiU3ACtIXk9_ZTdtCpTt413nRWQ3QGmaDAMScH26bLiRL8JbaLGLyAjESIjwicEm2fLZ1v3f66TZYrHUHGjZmKzc" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/yI5tbUDk1FsSEZ5OXiZ2VGGAdr3s-ptYonr7SB8-nxGAnsaS8WPg-V3c4EczWv5Pu6mfhY7YZa4lM9bSAB0FokPyAAeXCJslHkhPfKk4gEP9IRtTY2KHZGlHMWlrX48Dq4M5gVR0" /></p></td>
<td><p><img src="https://lh6.googleusercontent.com/JzPVQp6Q3CnbyxD4mc-nK4tT4obX-YS_K6pdjmcdtxuMnzMeLlsvu-NadDUf3Zm0Js1Kd2W-h71OhCjNlNKYI6AsVBI07dIvBuWmjTK74PRYXOOWLASRZyjO3IIu1IpwjSDGd9CL" /></p></td>
</tr>
<tr class="even">
<td><p>use um lenço</p></td>
<td><p>ou seu cotovelo</p></td>
<td><p>não suas mãos</p></td>
</tr>
</tbody>
</table>

Evite seu rosto

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh3.googleusercontent.com/SLM3w6RygTAsh2DXvsZd8salbpmVJJR26JXqa7bVU1MMQpDtXw-JV0Qc4X7ixpdg8ue1OoH7eedf0XFeVY3niicfUAy6yM8qIV1ImCs7vOYstiILdQ8I7ZCyrK5paCWX7IIWA9Lt" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/1gf-6C3gsp8LjdrTV06u8gkuscBXm1zqC4qIEz4dncyGW_mjTW4LCf3VWPfxIHHIqfRp_T_qDsai6VXQHCGbmBIgn_2XjaNaMY5VZkiQGa2XKrCN2P0k_4Gnl8CpMOHt55VNi5-S" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/EAW9P1Xux0Y7H-eGCTBdpzzWAgPU1vkjc6KNnObDeR9JEikLRqiZqmKFQoSbtut1R2_UXUxgMiRypRnqRB68WusOq9DWB4MHbYem1ZZFDyKQ0R81DqJANCRqcLIigI3TmsXNUYgS" /></p></td>
</tr>
<tr class="even">
<td><p>não toque seus olhos</p></td>
<td><p>nariz</p></td>
<td><p>ou boca</p></td>
</tr>
</tbody>
</table>

Mantenha distância

<table>
<colgroup>
<col width="33%" />
<col width="33%" />
<col width="33%" />
</colgroup>
<tbody>
<tr class="odd">
<td><p><img src="https://lh6.googleusercontent.com/lIb22ejDOVa161JRudgsn26oM2PoPqd6mx8DKJ_DnHfChqx_yq2Wu21QSR8_UmWL1fr7hzyLHPHzEqsLMXKosLDPjJzP373QsYZ1llKCMPNShAbmn9F322JH_mII5kJjMbAXyySC" /></p></td>
<td><p><img src="https://lh3.googleusercontent.com/h5-xrKyVgXkJS9fXdXNO3LRTmKgglvkO7KJxLqAYXDBYizyI09w2EnrLj2l1POsabISnjHhOdSl-pFbOusOI7K08HsZ8LdRfGFEpIVBUGwUL5q0Ou8exEbGeipEOdikaZsS0UO7U" /></p></td>
<td><p><img src="https://lh5.googleusercontent.com/AplbTDC-yDE6JQOFZK13ChLfqWCvxkDHhHBsyToue7l8jk4mXcK_F6CSysM0XaE25ip6lyrkvkqiV8ldJEapPT4B5sh62aWy2V_S2qX_O5Lc0lgoukwtfpPF4lQJmUyj324-l4Bi" /></p></td>
</tr>
<tr class="even">
<td><p>pratique distanciamento social</p></td>
<td><p>evite encontros com muitas pessoas</p></td>
<td><p>mantenha uma distância segura</p></td>
</tr>
</tbody>
</table>
