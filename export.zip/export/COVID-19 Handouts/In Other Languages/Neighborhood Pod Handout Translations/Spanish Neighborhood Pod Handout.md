---
title: "Spanish Neighborhood Pod Handout"
driveId: 1mECXYIGYWjO5Rp5SrnHSdkBXdyPp7KgIjMVPt_ExNbE
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T00:59:40.518Z
---

## ¡Hola\! Me llamo \_\_\_\_\_\_\_\_\_\_\_\_ y soy su vecino en la dirección \_\_\_\_\_\_\_\_\_\_\_ y mi número de teléfono es \_\_\_\_\_\_\_\_\_\_\_\_\_. Le estoy contactando porque sé que el coronavirus (COVID-19) está propaganda en nuestro área, y quiero estar conectado con usted y nuestros otros vecinos para que podamos mantenernos en contacto, recoger recursos, y apoyarse en este aprieto. Voy a coordinar un chat grupal o un “árbol de teléfono” (un grupo telefónico) para que podamos comunicar. Por favor, me envíe un mensaje de texto cuando recibe mi mensaje de invitación si le gustaría participar en esta red. ¡Si no prefiere comunicarse por texto, llameme y nosotros podemos comunicar de esa manera\!

## Neighborhood Pod Contact Sheets to Print/Copy

![](https://docs.google.com/drawings/d/sMaby3Q8A3EZqXLOQiHNfyg/image?parent=1mECXYIGYWjO5Rp5SrnHSdkBXdyPp7KgIjMVPt_ExNbE&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sXZh9GHwnLCJeC2ni9pKa6w/image?parent=1mECXYIGYWjO5Rp5SrnHSdkBXdyPp7KgIjMVPt_ExNbE&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/snHy2OUiYvO7kn135yTOong/image?parent=1mECXYIGYWjO5Rp5SrnHSdkBXdyPp7KgIjMVPt_ExNbE&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sPEc_3iJxyJDB2YKh7BB4mg/image?parent=1mECXYIGYWjO5Rp5SrnHSdkBXdyPp7KgIjMVPt_ExNbE&rev=1&h=402&w=342&ac=1)
