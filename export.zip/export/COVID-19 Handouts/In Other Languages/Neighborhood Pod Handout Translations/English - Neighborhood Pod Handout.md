---
title: "English - Neighborhood Pod Handout"
driveId: 1fOAJ1FXAVu_cZN-O2qE9KZ1VFsl3UneAKzty99VK-Dk
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:01:32.654Z
---

## Neighborhood Pod Contact Sheets to Print/Copy

![](https://docs.google.com/drawings/d/s2SfQX5iUJz9hm3pyxzGJYA/image?parent=1fOAJ1FXAVu_cZN-O2qE9KZ1VFsl3UneAKzty99VK-Dk&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sOYieYjGtUmloOwxXKMfzhA/image?parent=1fOAJ1FXAVu_cZN-O2qE9KZ1VFsl3UneAKzty99VK-Dk&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sU0WJqu-8drLiDMSo3gfrqw/image?parent=1fOAJ1FXAVu_cZN-O2qE9KZ1VFsl3UneAKzty99VK-Dk&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/suqDsue1JcXx2wm-nDdokjw/image?parent=1fOAJ1FXAVu_cZN-O2qE9KZ1VFsl3UneAKzty99VK-Dk&rev=1&h=402&w=342&ac=1)
