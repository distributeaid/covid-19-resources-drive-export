---
title: "Italian - Neighborhood Pod Handout"
driveId: 1i5D3cKYUWN8LpdqGK8RwTsg5_x-XmH4JuCwl64AbYH4
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:00:45.420Z
---

## Neighborhood Pod Contact Sheets to Print/Copy

Ciao\! Mi chiamo \_\_\_\_\_\_\_\_ e sono il tuo vicino. Vivo in/a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ e il mio numero è \_\_\_\_\_\_\_\_\_\_\_\_. Ti scrivo perchè so che il coronavirus si sta diffondendo nella nostra zona, e voglio mettermi in contatto con te e i nostri altri vicini cosí che possiamo tenerci aggiornati, unire le nostre risorse, e aiutarci in qualsiasi altro modo. Sto per creare un messaggio di gruppo o un elenco di persone da chiamare \[I have no idea how to translate phone tree - I don’t know if it’s a concept in Italian - also this message is full of idioms rather than simple sentences, so not sure how easy it is to understand\] cosí possiamo tenerci in contatto. Per favore mandami un messaggio al telefono quando ricevi questo biglietto se vorresti fare parte del gruppo. Se preferisci non parlare via messaggio, chiama il numero cosí possiamo parlare al telefono\!

![](https://docs.google.com/drawings/d/s3G2mnwcmeSP5as6zB6TzZg/image?parent=1i5D3cKYUWN8LpdqGK8RwTsg5_x-XmH4JuCwl64AbYH4&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sCfMRGNXoKgYZhVNjm7z-Ew/image?parent=1i5D3cKYUWN8LpdqGK8RwTsg5_x-XmH4JuCwl64AbYH4&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/soourzR1jWUZ1JvXDtTFXLg/image?parent=1i5D3cKYUWN8LpdqGK8RwTsg5_x-XmH4JuCwl64AbYH4&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sAsDx91Ug686qmBqbz9AE0A/image?parent=1i5D3cKYUWN8LpdqGK8RwTsg5_x-XmH4JuCwl64AbYH4&rev=1&h=402&w=342&ac=1)
