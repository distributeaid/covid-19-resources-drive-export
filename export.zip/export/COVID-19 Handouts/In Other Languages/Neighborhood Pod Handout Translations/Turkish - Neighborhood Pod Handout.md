---
title: "Turkish - Neighborhood Pod Handout"
driveId: 1P79Q21V-HdjMyVKn21Us9EhZFBvuDt_5UCPOHo8yrWM
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T00:59:25.182Z
---

## Neighborhood Pod Contact Sheets to Print/Copy

![](https://docs.google.com/drawings/d/srwSqPIX5BE1vbPsEBLzosQ/image?parent=1P79Q21V-HdjMyVKn21Us9EhZFBvuDt_5UCPOHo8yrWM&rev=1&h=394&w=326&ac=1)![](https://docs.google.com/drawings/d/sU62W1icyNN4p_hL9WcZLMQ/image?parent=1P79Q21V-HdjMyVKn21Us9EhZFBvuDt_5UCPOHo8yrWM&rev=1&h=394&w=326&ac=1)![](https://docs.google.com/drawings/d/sYwf1zU_jKBnBkCu9KIXpWg/image?parent=1P79Q21V-HdjMyVKn21Us9EhZFBvuDt_5UCPOHo8yrWM&rev=1&h=394&w=326&ac=1)![](https://docs.google.com/drawings/d/s_3L60J8-UFqNvyXp5XJATA/image?parent=1P79Q21V-HdjMyVKn21Us9EhZFBvuDt_5UCPOHo8yrWM&rev=1&h=394&w=326&ac=1)
