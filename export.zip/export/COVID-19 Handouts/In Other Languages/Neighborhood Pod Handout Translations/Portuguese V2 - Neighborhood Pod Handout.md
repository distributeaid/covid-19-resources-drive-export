---
title: "Portuguese V2 - Neighborhood Pod Handout"
driveId: 1y8kEE5nAEpzGIbmf9qG2GqbKsDB6SMkBssKNvV_ZwZU
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:00:07.142Z
---

## ![](https://docs.google.com/drawings/d/swRr9q8RcHD4ECENFl8AVjQ/image?parent=1y8kEE5nAEpzGIbmf9qG2GqbKsDB6SMkBssKNvV_ZwZU&rev=12&h=415&w=342&ac=1)Notas para contato do Grupo do Bairro para imprimir/copiar ![](https://docs.google.com/drawings/d/s1omt4tYwBT1WOaa2uy0KUA/image?parent=1y8kEE5nAEpzGIbmf9qG2GqbKsDB6SMkBssKNvV_ZwZU&rev=913&h=415&w=342&ac=1)![](https://docs.google.com/drawings/d/s61DRhVgfLwMdEiVWr1H_vA/image?parent=1y8kEE5nAEpzGIbmf9qG2GqbKsDB6SMkBssKNvV_ZwZU&rev=12&h=415&w=342&ac=1)![](https://docs.google.com/drawings/d/sWWytZsPPaMbSTI74B0dYZQ/image?parent=1y8kEE5nAEpzGIbmf9qG2GqbKsDB6SMkBssKNvV_ZwZU&rev=15&h=415&w=342&ac=1)
