---
title: "French - Neighborhood Pod Handout"
driveId: 1skWYE2YI1kDBYR7LHe5rgPXQjK6Oe9NqPnjPaCbF3Tg
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:02:04.017Z
---

## Neighborhood Pod Contact Sheets to Print/Copy

![](https://docs.google.com/drawings/d/sLQq3zdTeakhNV7ANTS0k0w/image?parent=1skWYE2YI1kDBYR7LHe5rgPXQjK6Oe9NqPnjPaCbF3Tg&rev=672&h=414&w=342&ac=1)![](https://docs.google.com/drawings/d/sAyMRbiSCx2vzYe6fvMLHxA/image?parent=1skWYE2YI1kDBYR7LHe5rgPXQjK6Oe9NqPnjPaCbF3Tg&rev=3&h=414&w=342&ac=1)![](https://docs.google.com/drawings/d/sbKWiXj6vZrUVQU2lJBcRiA/image?parent=1skWYE2YI1kDBYR7LHe5rgPXQjK6Oe9NqPnjPaCbF3Tg&rev=3&h=414&w=342&ac=1)![](https://docs.google.com/drawings/d/sjZzrsJCR3x9l-HSNeEdGHQ/image?parent=1skWYE2YI1kDBYR7LHe5rgPXQjK6Oe9NqPnjPaCbF3Tg&rev=3&h=414&w=342&ac=1)
