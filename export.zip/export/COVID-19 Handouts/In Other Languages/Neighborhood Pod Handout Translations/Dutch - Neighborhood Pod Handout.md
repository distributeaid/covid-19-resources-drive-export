---
title: "Dutch - Neighborhood Pod Handout"
driveId: 1sVihVjba2843u8HU92lkxklq3AVlwKKjgzevqzDfebM
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-05-06T15:05:28.355Z
---

## Buurt Pod Contact Informatie om te printen en delen

1.  Hallo\! Mijn naam is \_\_\_\_\_\_ en ik ben uw buurman/vrouw op het adres \_\_\_\_\_\_\_ en mijn telefoon nummer is \_\_\_\_\_\_\_\_\_\_\_. Ik schrijf omdat ik weet dat het Coronavirus toeneemt in onze buurt, en ik wil graag contact met u en onze buren opzoeken dat wij elkaar beter kunnen helpen. Ik zal een groeps chat of telefoon lijn opzetten voor het geval dat wij elkaar willen bereiken. Als u dit bericht heeft ontvangen, schrijf mij alstublieft een bericht (SMS/Whatsapp) als u mee wilt doen. Als u liever via telefoon spreekt, bel mij dan direct.

![](https://docs.google.com/drawings/d/sHxEN_c70MWatBL8XbJvmvg/image?parent=1sVihVjba2843u8HU92lkxklq3AVlwKKjgzevqzDfebM&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/s4yGRJATTAxfuYXBfOjgCKQ/image?parent=1sVihVjba2843u8HU92lkxklq3AVlwKKjgzevqzDfebM&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/s2mBjFrzhxAHRn7h0dpkdKQ/image?parent=1sVihVjba2843u8HU92lkxklq3AVlwKKjgzevqzDfebM&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sYB7QKs10AJ4UEAfbpRzHoA/image?parent=1sVihVjba2843u8HU92lkxklq3AVlwKKjgzevqzDfebM&rev=1&h=402&w=342&ac=1)
