---
title: "Farsi - Neighborhood Pod Handout"
driveId: 1lWFIHcWiYBz4duPVcC4OsKMjtJ2cVbQBPPuWLx8YKlE
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:01:47.466Z
---

## سلام. اسم من ـــــــــــــــــــــــــــــــــــــ است و من همسایه شما در ــــــــــــــــــــــــــــــــــــــــــــــ هستم. شماره تماس من ــــــــــــــــــــــــــــــــــ می باشد.  به خاطر اینکه می دانم که ویروس کرونا در منطقه ما در حال گسترش است من با شما تماس میگیرم من میخواهم با شما و همسایه های دیگر در تماس باشم، از منابع همدیگر شریک بشویم و در هر کاری که پیش می آید همدیگر را پشتیبانی کنیم. من یک پیام یا چت گروهی را ایجاد میکنم که در تماس بمانیم. اگر دوست دارید عضو این گروه بشوید، لطفا وقتی که این پیام را دریافت کردید به من پیام بفرستید. اگر ترجیح می دهید زنگ بزنید، می توانیم صحبت کنیم.

##

## Neighborhood Pod Contact Sheets to Print/Copy

![](https://docs.google.com/drawings/d/scilkfsN94e3qyHM3dedcrA/image?parent=1lWFIHcWiYBz4duPVcC4OsKMjtJ2cVbQBPPuWLx8YKlE&rev=41&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sc_Tif7p1HcGiHupjGFdh9g/image?parent=1lWFIHcWiYBz4duPVcC4OsKMjtJ2cVbQBPPuWLx8YKlE&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/s-H1zZAt5rdhCDBhfg2WwYw/image?parent=1lWFIHcWiYBz4duPVcC4OsKMjtJ2cVbQBPPuWLx8YKlE&rev=1&h=402&w=342&ac=1)![](https://docs.google.com/drawings/d/sI1zh10p5gCHtVvC0lX6_Ug/image?parent=1lWFIHcWiYBz4duPVcC4OsKMjtJ2cVbQBPPuWLx8YKlE&rev=1&h=402&w=342&ac=1)
