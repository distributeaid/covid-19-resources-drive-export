---
title: "Portugese - Neighborhood Pod Handout"
driveId: 1547U2ELd8-1ym61M_rUK7rdSs3-P1ns2rxQVhrUvAgk
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:00:30.356Z
---

## Notas para contato do Grupo do Bairro para imprimir/copiar

Translation:

![](https://docs.google.com/drawings/d/sNKlW1WmnLkPJZeoEkjABhw/image?parent=1547U2ELd8-1ym61M_rUK7rdSs3-P1ns2rxQVhrUvAgk&rev=932&h=439&w=342&ac=1)![](https://docs.google.com/drawings/d/sHjPgmd04kZStXA5K8II2oA/image?parent=1547U2ELd8-1ym61M_rUK7rdSs3-P1ns2rxQVhrUvAgk&rev=1&h=439&w=342&ac=1)

![](https://docs.google.com/drawings/d/sN-QAoR4J3iNqW9Bdmvdbww/image?parent=1547U2ELd8-1ym61M_rUK7rdSs3-P1ns2rxQVhrUvAgk&rev=1&h=439&w=342&ac=1)
