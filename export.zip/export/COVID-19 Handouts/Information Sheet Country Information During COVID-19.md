---
title: "Information Sheet: Country Information During COVID-19"
driveId: 1MPTeKGWThw0ldqRwpS4buejglDD9FEYTSoBuXw9Ka8I
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-07-28T16:37:11.156Z
---

Information Sheet:  
Country information during COVID-19

Global port restrictions database:  
[https://www.wilhelmsen.com/ships-agency/campaigns/coronavirus/coronavirus-map/](https://www.google.com/url?q=https://www.wilhelmsen.com/ships-agency/campaigns/coronavirus/coronavirus-map/&sa=D&ust=1601935360358000&usg=AOvVaw37maG3YtxH7aeAhY8r6XzC)

Global travel restrictions and airline information database:  
[https://data.humdata.org/dataset/covid-19-global-travel-restrictions-and-airline-information](https://www.google.com/url?q=https://data.humdata.org/dataset/covid-19-global-travel-restrictions-and-airline-information&sa=D&ust=1601935360359000&usg=AOvVaw32qANEVpJCmPrZWgIX4cNc)

Global border restrictions:  
[https://www.iatatravelcentre.com/international-travel-document-news/1580226297.htm](https://www.google.com/url?q=https://www.iatatravelcentre.com/international-travel-document-news/1580226297.htm&sa=D&ust=1601935360360000&usg=AOvVaw1GguZw_Ta_8jSKXgBXIA2J)

COVID-19 country information database:

[http://www.euro.who.int/en/health-topics/health-emergencies/coronavirus-covid-19/country-information](https://www.google.com/url?q=http://www.euro.who.int/en/health-topics/health-emergencies/coronavirus-covid-19/country-information&sa=D&ust=1601935360361000&usg=AOvVaw1brgceGK0_5ARrZSn3gke1)

If you cannot find the relevant country in the database, please check this list:

Morocco: [https://www.sante.gov.ma/Pages/corona.aspx](https://www.google.com/url?q=https://www.sante.gov.ma/Pages/corona.aspx&sa=D&ust=1601935360362000&usg=AOvVaw2zo-rsra78zcHJHAMfY045)

Algeria: [http://covid19.cipalgerie.com/en/](https://www.google.com/url?q=http://covid19.cipalgerie.com/en/&sa=D&ust=1601935360362000&usg=AOvVaw0nQxVni5Ltx6w48s4NLqc1)

Tunisia: [http://www.pm.gov.tn/pm/content/index.php?lang=en](https://www.google.com/url?q=http://www.pm.gov.tn/pm/content/index.php?lang%3Den&sa=D&ust=1601935360363000&usg=AOvVaw3aRQcyvVu8d-DeOXM8ZTa4)

Libya: [www.libyaobserver.ly/covid-19?qt-sidebar_tabs=1\&qt-libya_weather=2\&page=3](https://www.google.com/url?q=https://www.libyaobserver.ly/covid-19?qt-sidebar_tabs%3D1%26qt-libya_weather%3D2%26page%3D3&sa=D&ust=1601935360363000&usg=AOvVaw0I2NjDnnNa29j8cafFgoJT)

Egypt: [https://eg.usembassy.gov/u-s-citizen-services/covid-19-information/](https://www.google.com/url?q=https://eg.usembassy.gov/u-s-citizen-services/covid-19-information/&sa=D&ust=1601935360364000&usg=AOvVaw1C1MyhNQ8V_zIlvYrMt0zX)

Jordan: [https://www.gov.uk/foreign-travel-advice/jordan/coronavirus](https://www.google.com/url?q=https://www.gov.uk/foreign-travel-advice/jordan/coronavirus&sa=D&ust=1601935360365000&usg=AOvVaw3BHC70KcrTpl_TGssi4Jeg)

Saudi Arabia: [https://www.gov.uk/foreign-travel-advice/saudi-arabia/coronavirus](https://www.google.com/url?q=https://www.gov.uk/foreign-travel-advice/saudi-arabia/coronavirus&sa=D&ust=1601935360366000&usg=AOvVaw2-c1Kcq8AoFnmyjpEM896R)

Afghanistan: [https://moph.gov.af/en](https://www.google.com/url?q=https://moph.gov.af/en&sa=D&ust=1601935360366000&usg=AOvVaw0T8Jb0tsQshE0iYnAaVBzC)

Pakistan: [http://covid.gov.pk/](https://www.google.com/url?q=http://covid.gov.pk/&sa=D&ust=1601935360367000&usg=AOvVaw1vijsZ7btjV1pvtmXYuKb9)

Palestine: [http://www.emro.who.int/pse/palestine-news/landing-page-for-covid19.html](https://www.google.com/url?q=http://www.emro.who.int/pse/palestine-news/landing-page-for-covid19.html&sa=D&ust=1601935360367000&usg=AOvVaw1yVhE7mHrtI_Ge7iI7dnoZ)

[https://il.usembassy.gov/covid-19-information/](https://www.google.com/url?q=https://il.usembassy.gov/covid-19-information/&sa=D&ust=1601935360368000&usg=AOvVaw0fkPrczLKrlhHGTiCqe3gG)

(Israel: [https://govextra.gov.il/ministry-of-health/corona/corona-virus-en/](https://www.google.com/url?q=https://govextra.gov.il/ministry-of-health/corona/corona-virus-en/&sa=D&ust=1601935360369000&usg=AOvVaw1EIz0PJkyZo97VTgiZ8p4y))

Iran: [https://en.mehrnews.com/tag/Iran+Defense+Ministry](https://www.google.com/url?q=https://en.mehrnews.com/tag/Iran%2BDefense%2BMinistry&sa=D&ust=1601935360369000&usg=AOvVaw0xbbKejXt2OkDFxlq_XjtE)

Kuwait: [https://www.e.gov.kw/sites/kgoEnglish/Pages/HomePage.aspx](https://www.google.com/url?q=https://www.e.gov.kw/sites/kgoEnglish/Pages/HomePage.aspx&sa=D&ust=1601935360370000&usg=AOvVaw2vX6FbxigcqgMLmUqYIwn2)

Lebanon: [https://www.moph.gov.lb/en/Pages/2/24870/novel-coronavirus-2019-](https://www.google.com/url?q=https://www.moph.gov.lb/en/Pages/2/24870/novel-coronavirus-2019-&sa=D&ust=1601935360371000&usg=AOvVaw0_zkHjB2Yrcqc-XoLcy0gz)

Iraq: [https://gds.gov.iq/](https://www.google.com/url?q=https://gds.gov.iq/&sa=D&ust=1601935360371000&usg=AOvVaw2zS9NRc1el0JKIBTQ5BaiT)

Syria: [https://www.sana.sy/en/?tag=health-ministry](https://www.google.com/url?q=https://www.sana.sy/en/?tag%3Dhealth-ministry&sa=D&ust=1601935360372000&usg=AOvVaw11YU9XZlia9XEdItWU6lLE)

Additional resources:

General information on national responses. The timeline of the spread and the measures put in place to limit the spread for most countries are available:

[https://en.wikipedia.org/wiki/National_responses_to_the_2019%E2%80%9320_coronavirus_pandemic](https://www.google.com/url?q=https://en.wikipedia.org/wiki/National_responses_to_the_2019%25E2%2580%259320_coronavirus_pandemic&sa=D&ust=1601935360373000&usg=AOvVaw2-ldQQ5NQ0pnorBz2nq6BO)

Measures taken in European Union countries due to COVID-19:  
[https://ec.europa.eu/transport/coronavirus-response_en](https://www.google.com/url?q=https://ec.europa.eu/transport/coronavirus-response_en&sa=D&ust=1601935360373000&usg=AOvVaw1rpc8ITp8a-Yzy9oxshivh)

Here the latest update on the main policy responses (fiscal, monetary, social responses) worldwide:  
[https://www.imf.org/en/Topics/imf-and-covid19/Policy-Responses-to-COVID-19](https://www.google.com/url?q=https://www.imf.org/en/Topics/imf-and-covid19/Policy-Responses-to-COVID-19&sa=D&ust=1601935360374000&usg=AOvVaw08KcMm7CCM9iiVFCOO5_S9)

Examples of civil society + small scale + digital responses worldwide: [https://www.opengovpartnership.org/collecting-open-government-approaches-to-covid-19/](https://www.google.com/url?q=https://www.opengovpartnership.org/collecting-open-government-approaches-to-covid-19/&sa=D&ust=1601935360375000&usg=AOvVaw29ls3NNHJPnuY34llk6NJk)

Other links:

European countries COVID related stats and containment measures: [https://jrc-covid.azurewebsites.net/Home/Dashboard](https://www.google.com/url?q=https://jrc-covid.azurewebsites.net/Home/Dashboard&sa=D&ust=1601935360376000&usg=AOvVaw3byVfN2AtycNCzDmPjBKBA)

If you have something to contribute or are looking for a resource and do not find it here, please contact the Distribute Aid Team at:  
<platform@distributeaid.org>
