---
title: "Information Sheet - Mass Gatherings - World Health Organisation/DA  "
driveId: 1nJsvsmcAtcjHkYd8kC6EsPZamsLrbOlRbP7aFvapni8
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-05-08T10:15:05.434Z
---

Information Sheet:  
World Health Organisation  
Preparing for Mass Gatherings Course Notes

Course date: 6/5/2020  
Attendee: Davina Whiting  
NGO: Distribute Aid

Disclaimer: These course notes are being made available for aid workers and operational planners to take into consideration whilst altering their operations without attending the full course. To access the full course and claim your certification [please click here](https://www.google.com/url?q=https://extranet.who.int/hslp/training/course/index.php?categoryid%3D49&sa=D&ust=1601935361174000&usg=AOvVaw2P76l4VijNRekVN_dMpPh0). Distribute Aid does not take any responsibility or liability for your adapted plans.

# Module 1: Mass Gatherings

MG = Mass gatherings

MG = Events attended by a sufficient number of people for a defined period of time, which have the potential to strain the planning and response resources of the host nation or defined community

Different types of MG:  
\- spontaneous (unknown/unplanned),  
\- planned - recurrent (yearly events like festivals, football)  
\-  one-off (celebrations - wedding etc)

MG additional health risks:  
\- Strain on health systems  
\- increase in political and media pressure  
\- potential introduction and dissemination of new diseases  
\- the need for an all-hazard approach (higher risk of deliberate events)  
\- new of additional stakeholders

During planning you need to consider:  
\- testing the plan and systems before the event

\- Identify relevant stakeholders and obtain their engagement

\- Identify potential public health risks

\- Minimise and respond effectively to public health emergencies

# Module 2: Risk Assessment & Management

Health Hazards at MG’s:

\- Environmental (noise, air pollution, land contamination -  illness or exacerbation of existing conditions)

\- Poor food safety and hygiene practices (outbreak of gastro diseases)

\- Access to alcohol and drugs (heighten injury risk from falls,trips and risk of violence or impeding a person's response to a situation)  
\- Venue infrastructure (crowd safety, protection from weather)

Strategic risk assessment and management process:

\- Identify risks that may improve, prevent, degrade or delay the MG and mitigation actions to action these

\- Provide results based on logical analysis as well as a methodical approach to inform all planning activities

\-Review existing programmes or arrangements through identifying gaps or opportunities (are they fit for purpose or are changes needed? Are they timely, sensitive and flexible?)  
\- Establish interactions, comms and consultations with internal and external stakeholders    
\- Provide through doccumentation  
\- Help focus on those events that are most likely to occur or will have the highest impact  
\- Identify resources and training (how will working arrangements/roles/responsibilities change?)

MG heighted risks:

\- Potential for import/export of infectious diseases  
\- Mixing of people who may be more susceptible to certain diseases  
\- global disease transmission  
\- emergency response capacity could be compromised  
\- crowds create additional risks

Strategic risk assessment:  
Proactive assessment for a MG and will inform all planning activities. This should take a broad, preventible approach

Case-based rapid risk assessment:  
Reactive and is carried out in response to an incident from initial alert until completion of response

Risk Management:

systematic approach and practice of managing uncertainty to minimise potential harm and loss (of life, assets and resources, injury, illness and other adverse effects)

In terms of MG Legacy  
Surveillance and response:   
\- systems ability to rapidly detect and implement appropriate and commensurate measures to contain/minimise the impact on health  
\- ability to maintain a state of alertness for prolonged periods of time, including through false alarms and fatigue  
\- systems surge capacity  
Medical:

\- Local hospital system and health services and its ability to manage an increased number of patients and if necessary to rapidly reach a surge operation in case of crisis

Food and water safety:  
\- Ability of local infrastructure to ensure safe preparation and delivery of food and water to attendees of MGs  
Improvements:  
\- Through implementations and recommendations of International Health Regulations (IHRs) which can result in a significant legacy of strengthened public health capacity

Risks can be managed or treated by broad methods:  
\- Treat. Can the hazard be removed or the risk it poses be prevented?  
\- Terminate. Can the hazard be removed?  
\- Transfer - can the responsibility for protection from the hazard be transferred?

\- Tolerate - what can be done to minimise the risk?

# Module 3: Legacy and Evaluation

Legacy falls into 2 categories:

What is left behind (host country legacy)  
\- legacy may include improvements in public health systems, improved inter-agency relationships etc.

\-What is passed on (legacy for future organizers and events). Sharing learnings with others helps to improve the delivery of future events and contribute to the global knowledge base. Sharing what did not work well is equally as important.

Measuring the impact:

\- Evaluation enables organizers and other to understand and capture the learning from what has gone well or not gone well during planning and delivery of an event  
\- Evaluation is needed to demonstrate the legacy benefit of a MG and is an integral part of the legacy planning

The 4 types of evaluation:  
Research - generating an evidence base for international activities as a whole and to inform research  
Effectiveness - Identify effective ways of working and return on investment  
Resources - assessing the efficient use of resources  
Reviewing - Learning from challenges and adverse events

Legacy planning allows:  
\- to gain stakeholder engagement and agreements  
\- to demonstrate impact and value for money  
\- to ensure and secure the necessary resources for legacy  
\- to establish processes for evaluation and knowledge sharing within planning delivery and review stages of MG’s

Factors:  
\- baseline capacity and capability  
\- How improvement can be maintained long term sustainability

Before Event:  
\- Review the event contact and risk assessment, including gaps and opportunities based on assessment of local health status and needs  
\- reviewing legacy and evaluation information from other MG’s  
\- developing, implementing and testing new systems, processes and policies  
\- training staff and developing resources  
\- developing a baseline for evaluation purposes

\- documenting activities, lessons learnt and evaluation processes

During event:  
\- capturing and documenting the outputs, activities and impact

\- host an observer programme for future MG organizers so they can learn from your event

After event:  
Hot and Cold debriefs

Evaluations

7 key areas that are recurrent and widely recognised for health legacy from MG’s:  
\- Public health and surveillance system and situational awareness  
\- Relations and legislation, and policies (IHR)  
\- Emergency preparedness and response  
\- Environmental health

\- Health promotion, awareness, enhanced knowledge and understanding

\- C4: Strengthening communication networks and collab within and between orgs  
\- Organizing capacity and capacity building

# Module 4: The concept of Operations (ConOps)

Concepts of Operations : ConOps

C4:  
Command - enables the effective and efficient use of availability resources through planning, organising, directing coordination and controlling their use to safely and successfully conduct an event. Command operates vertically.

Control - Concept that during the planning and delivery of an event, leadership must organise the resources to respond to demands in a timely manner, including managing risks that may arise during the MG. Control operates horizontally and across organisations.

Communication - organisation of the different elements of  plan or activity to enable them to work together

Coordination - Timely and coordinated dissemination of information related to the awareness and response to operational issues

Concept of operation:

Objectives, operational strategy, capabilities, roles and responsibilities, logistics, reporting and response, working arrangements. Conops are supported by Standard Operating Procedures (SOPs). All participating individuals and agencies should understand their roles and responsibilities as defined and agreed in the ConOps

Additional challenges of MG:

Shorter time frame to respond to any public health threat or incident  
Lots of people together in a location may contribute to:  
\- faster spread of disease  
\- higher incidence of injury and illness compared to usual community rates  
\- poor crowd behaviour/stampedes

\-mobile population (domestically and internationally) makes it harder to trace them to give them information or treatment

\-Heightened media, political and public interest and visibility  
\- additional pressure to provide rapid and accurate information on any public health event (to provide assurance or discredit rumors)  
\- the adverse consequences of any negative health event to be greatly magnified

The need to provide business as usual service alongside additional requirement for MGs  
\-Consider the capacity and flexibility in systems to scale up (and down) a response in the event of a public health incident within the MG context or externally

new and different stakeholders involved  
\- unclear roles and responsibilities and decision making hierarchy  
\-confused communication pathways internally and externally  
\- lack of alignment across operational plans and procedures

Incident Command System (ICS)

ICS is a standardized, detailed hierarchical structure that is used to establish the structure for roles and responsibilities within the command and control structure. It allows for a cooperative response by multiple agencies, both within and outside the government. IT aims to address potential problems which may arise when managing complex events (e.g too many people reporting to one person/lack of structure for coordinated planning and response)

![](https://lh6.googleusercontent.com/QOhBn766G4Da7v90YstvKf6hyZT7de7d_vMEmMw3I8X88JiQ0baHttHD81SH6iDc6StUELPnvlxbdpuux8Jm6UXAX5JyodX_3PHKaN7GQBhpJu-8IxEwt6HcGCrthcfBQq6oi1Ag)

Incident   
Responsible for safety, providing public information, liaison with other agencies and with the four other management functions

Public Information Officer   
Responsible for engaging and providing incident-related information to the public and media and engaging with other agencies as required

Safety Officer   
Responsible for the health and safety of incident management personnel. Including monitoring incident operations and advising on all matters relating to safety

Liaison Officer   
Responsible for being point of contact for other stakeholder engagement: govt agencies, NGOs and private-sector organisations

Operations Section    
Responsible for establishing tactics and directing all operational resources to enable reaching the incident objectives

Planning Section  
Supports incident action plan by tracking resources, collecting/analysing information and maintaining documentation

Logistics Section    
Planning and coordinating.

Finance/Admin Section  
Provides accounting, procurement, time recording and cost analyses related to the incident

The benefits of using ConOps in public health responses with cross disciplinary coordination:

\-Strengthened surveillance (recognition of public threats)  
\-Better communications across the health system, stakeholders and MG participants

\- Improved communication with the local, national and international community

\- Improved response to public health incidents

\- Ability to monitor and manage resources across the system,

\- Reduced risk, impact and potential escalation of a threat, averts morbidity and saves lives

The benefits of clearly defining roles and responsibilities:  
\- Clear boundaries between roles and orgs (avoiding duplication of work efforts)

\- Decisions taken at the appropriate level (lowest possible)  
\- Individuals acting within the limits of the authority (as defined)  
\- Experts being empowered to do their role and not to be dictated to from above

Testing and exercising before an event:  
This is critical to event delivery. The scenarios should be chosen and informed by the risk assessment. By testing, it ensures all involved understand ways of working, roles and responsibilities during a MG. ConOps should be tested prior to scenarios as it will identify any other training needs.

During an event:  
It is important to monitor resources availability, and as the MG progresses deal with any issues or potential gaps. Continues communication and liaison with other agencies (security/law enforcement/event management) and keeps timely and accurate records of any incidents or changes to the ConOps structure.

After an event:  
Immediately following the event, evaluate the effectiveness of the ConOps, including the C4 arrangements that impacted on communication, preparedness and response. This could be a verbal debriefing or a written report such as a After Action Review. It’s important to record what went well and use this to inform future planning for MGs. Any SOPs that failed during the event should be amended or removed as to not happen at future events.

# Module 5: Surveillance and Alert Systems

All-hazards approach: An approach to emergency management that takes into consideration all possible hazards - including biologica, chemical, radionuclear and natural disasters.

Surveillance can:

\- Serve as an early warning system  
\- Document the impact of an intervention and/or track progress towards specific goals

\- monitor and clarify epidemiology of health events to allow priorities to be set and to inform public health policy and strategies

Other reasons to  increase capacity for surveillance and alert systems during a MG  
\- Reporting

\- Outbreak

\- Crowd

\- Rumors

\- Nil report

Risk assessment for scoping survilland and alert systems:  
\- What diseases, syndromes or hazards should surveillance be conducted for and what is the risk of these?

\- What are the events most likely to occur or of high impact in order to focus the systems

\- What are the best systems to use?

\- What public health surveillance systems are already in place and what needs to be improved?

\- What are the special considerations for outbreak or public health response during a MG

\- What processes and pathways are already in place for directing, reporting and managing both positive and negative results?

The two guiding principles that should be used:  
1\) Systems should be geared towards detecting those conditions and events most likely to affect and have high consequences for the MG  
2\) Systems should only collect information that will be used, reviewed and where necessary acted upon

# Module 6: Incident and Outbreak Response Management

Important to take the business as usual model for incident and outbreak response processes, and review it to ensure it is fit for purpose considering the event context. Due to increased pressure of MG, setting thresholds/goals in the smarter and lower bracket is advisable.

Key considerations:

\-Case and contact management

\-Management of overseas visitors  
\-Management of fatalities  
\-Mass dispensing  
\-Psychosocial support

Processes and systems in the event of deaths will need to reviews and agreed upon to ensure that they are in place:  
\-Victim identification  
\-Death certification (especially for those from abroad)  
\-Transportation of victims back to their home country  
\-Provision of emergency mortuary facilities

The three key principles:

1)Planning and risk assessment need to take place well in advance of the event to ensure all systems are adequate scoped, adapted and tested

2\) Effective C4 arrangements are in place for routine outbreaks and incident response, as well as in case of emergency, including pre-agreed decision making responsibility

3\) Incident and outbreak management needs to follow a business as usual model that has been improved to have smarter and lower thresholds to ensure adequate health protection of both the locals and overseas visitors

# Module 7: Environmental health (EH) considerations and protection of food & water

EH health risks:

Heat/cold

Air pollution

Noise pollution

Water (drinking and recreational)

Sanitation

Food hygiene/preparation

Examples of interventions that can be included in early planning stages to reduce risks:  
Provisions of shade

Transport policy for event

PPE

Access to hand washing facilities

Health promotion messages

Training (e.g food preparation)

During MG there are 5 key things that needs to be put in place:

Sanitation  
\- adequate toilet facilities that are concentiyl located and accessible  
\- separate toilets should be provided for men and women  
\- well constructed and maintained so they remain usable, hygienic and will not contaminate a water supply via leakage or seepage.

\- hand washing facilities located near toilets which should have an adequate, clean running (pressurised) water, soa and a method of hand drying  
\- adequate disposal facilities for water, paper towels and sewage.

Solid waste collection  
\-Adequate solid waste collection and disposal to avoid vectors and pests  
\-Located at convenient locations (especially near food service facilities)  
\-Containers should be leak proof and non-absorbent  
\-Emptied frequently at the appropriate place

Pest and vector control  
\-Measures to reduce vector load during and in advance of the event

Weather and Extreme Events  
\-Following meteorological reports and consider how the weather will affect your event  
\-Consider if the area of your event creates a risk for a natural disaster such as a earthquake, tsunami, hurricane etc

Air Quality  
\-Daily monitoring of the air quality health index will show if you need to consider postponing an event  
\- Will highlight if you need to put extra precaution in place for people attending with underlying health conditions such as asthmatics

Noise  
\- Ensure staff have adequate PPE  
\- Have PPE in place for guests who wish to use it  
\- Educating guests/ raising awareness for guests  who do not wish to use PPE on the health risks associated with exposure to excess noise

After the MG  
\- addressing the risks associated with clean-up activities  
\- damage control to infrastructure that will need repair and refurbishment

\- Post-event surveillance should continue, especially for waterborne and food-borne diseases

Additional challenges MG pose:  
\-Heightened water quality testing in case of water events

\-Visitors may be more vulnerable to endemic food and waterborne diseases  
\-High crowd density can contribute to a rapid spread of some pathogens  
\-Waste disposal systems will be overwhelmed and this could lead to contamination of land and water through poor sanitation practices  
\-Normal water and sanitation facilities and food protection measures and systems may be stretched by the higher number of people using them  
\-Food and water safety should be considered as there is the potential for deliberate contamination of water and food supplies

# Module 8: Health Promotion

This is the process of enabling people to increase control over, and to improve their health. It moves beyond a focus on individual behaviours towards a wide range of social and environmental interventions.

Social - Psychological - Socioecology - Communication Theories

Opportunities for health promotion targeting local and visiting populations:  
\-encouraging healthy eating and physical activity  
\-promoting responsible alcohol consumption  
\-promoting smoke free lifestyles  
\-improving sexual health

Opportunities to secure and focus resources to promote health and well being in local population and visitors:  
\-minimise risks to health by e.g health uptake  
\-build relationships with participants and communities  
\-gain political, media and community support.

They may however also encourage the negligence of normal health behaviour due to:  
\-high level of emotion

\-distance from home and lack of positive influences

\-alcohol abuse associated with certain MGs such as festivals  
\-lack of awareness of risk in another country (culturalism)

\-hastiness to travel and so ignoring travel advice (e.g vaccinations)  
\-language barriers

Guiding principles:  
Planning - Risk assessment - Communication

Before the event identify and understand your key audience and tailor your work and messages around them. Health messages need to be very clear and utilize appropriate media channels. Individual behaviour change is critical as people have different needs and a one size fits all approach will be ineffective.

During the event the main focus should be on implementing the planned health promotion.

# Module 9: Public Information

Conflicting information from various sources can cause tremors and misinformation. It is important to proactively engage and provide assurances to the public during a MG.

Public information has a twofold purpose

1\) To provide key information to the public and inform them of any risks to their health  
2\) To provide assurance/information to the population that actions have been taken to identify and respond to the first indication of a incident that might be linked to the MG

To avoid confusion and ensure accurate, consistent messages they must be agreed across partners prior to sending out. Once agreed the message can be sent out via multiple sources and avenues of communication.

Avenues of communication:  
Social Media:  
Event organiser utilising verifies channels such as twitter/facebook along with websites and any event apps

Message at the event:  
Through the use of big screens, loud speakers and posters

Stakeholders Distribution Routes:  
Stakeholders signposting to the official event information through various routes such as radio/newspapers ensuring alignment and dissemination to a wider audience
