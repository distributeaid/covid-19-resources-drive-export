---
title: "Information Sheet: Remote Tools for Medical Professionals "
driveId: 1O-ryOktLjisKlgPoBbn2FkBj9oSF8S0XVJZnzvf44Bg
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-07-28T16:35:39.941Z
---

Information Sheet:  
Remote Tools for Medical Professionals

This guide has been produced by Distribute Aid with the aim to provide guidance for doctors on 6 platform tools they can use to switch to remote consultations with video.

Overview:

Information from the [American Medical Association](https://www.google.com/url?q=https://www.ama-assn.org/practice-management/digital/ama-quick-guide-telemedicine-practice&sa=D&ust=1601935360689000&usg=AOvVaw2rJantNPukVlcCafx68fhU):  
Due to the COVID-19 pandemic the Office for Civil Rights (OCR) at the Department of Health and Human Services (HHS)  will exercise enforcement discretion and until announced otherwise and will not impose penalties on physicians using telehealth in the event of noncompliance with regulatory requirements under HIPAA. This is in connection with the good faith provision of telehealth during the COVID-19 national public health emergency.

In this guide we will show you which services are suitable, and explain how to use each platform These systems have a certain level of cyber security that is satisfactory to ensure patient privacy. Other platforms that have not been reviewed may not fully comply with the requirements of HIPAA rules and should not be used.

Whilst using telemedicine platforms you should still:

- Ensure you are still properly documenting these visits – preferably in your existing EHR as you normally would with an in-person visit. This will keep the patient’s medical record together, allow for consistent procedures for ordering testing, medications, etc. and support billing for telehealth visits.
- Ensure you receive advanced consent from patients for telemedicine interactions. This should be documented in the patient’s record. Check to see if your technology vendor can support this electronically.

You can find further information on setting up your practice[ in this web seminar](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DCj0s3alpZKI&sa=D&ust=1601935360690000&usg=AOvVaw3wcmT5btNTPA0sm-MCF5eS) by Dr. Sue Kressly which discusses Telehealth during COVID-19.

If you have any further questions please contact the Distribute Aid Team at:  
<platform@distributeaid.org>

Free Platforms:

Cisco Webex Meetings / Webex Teams  
Pros: Free version of the platform (Webex Meetings) directly supports consultations for healthcare professionals. Doctors can schedule a meeting and send the link/dial in information to the patient ahead of the meeting via email. The patient can wait in the call for the doctor to arrive and Webex supports Android and iOS  
Cons: 40mins limit on meetings on the free plan, mobile users will need to download an app (but not on the web version). Doctor needs to manually lock the meeting room for privacy as there is no meeting sign in for the patient. The privacy policy merely states that the host should state if they intend to start recording. Any files uploaded or preserved may be accessed after the meeting.  
Pricing: Free Platform, Monthly plans (at time of publication first month free) Annual plans (at time of publication 4 months free when signing up for an annual plan)  
Resources: [Guide for virtual consultations](https://www.google.com/url?q=https://www.webex.com/content/dam/webex/eopi/assets/healthcare/VirtualConsultationClinician.pdf&sa=D&ust=1601935360691000&usg=AOvVaw0o-kGphnHVa451i_VGK1FG) / [Collaborating with other healthcare professionals](https://www.google.com/url?q=https://www.webex.com/content/dam/webex/eopi/assets/healthcare/ClinicianCollaborateAcrossHealthcareFacilities.pdf&sa=D&ust=1601935360691000&usg=AOvVaw0wkD2hPUtau9jqA6qe9lFt)

Doxy  
Pros: This is an existing TeleMed App that has a free version of the platform that supports Android and iOS. It is very easy to use and is HIPAA compliant. It can be used on the web and doesn’t require the patient to download an app. Doctors can schedule and invite patients into their meetings via email and patients will be put in a virtual waiting room until the doctor arrives.    
Cons: The free version does not include many features but for short term remote use is very acceptable. The free version only offers support through email (but reviews state that there is still quick service help through this channel)

Pricing: Free platform version

Resources: [Intro to Doxy](https://www.google.com/url?q=https://www.youtube.com/watch?v%3D1K4NAldaflU%26list%3DPL6dNAFGMSznlW4CpUtaJYljWhgybGL7W8%26index%3D1&sa=D&ust=1601935360692000&usg=AOvVaw0JWqfLSrtjbugPrnSPsr2X) / [Step by step clinic overview](https://www.google.com/url?q=https://www.youtube.com/watch?v%3Dept3iZ3_j4w&sa=D&ust=1601935360693000&usg=AOvVaw2pX9LaYU-HEUBaDah-iVVR)

Google Hangouts  
Pros: Easy to use and mobile friendly if you don’t have two screens available and supports Android and iOS. Can also be used on audio only and provides a dedicated dial in number for users. Doctors can schedule a meeting and send the link/dial in information to the patient ahead of the meeting via email. The patient can wait in the call for the doctor to arrive. HIPAA compliant.  
Cons: There can sometimes be issues with video quality. Host needs to have a gmail account to schedule and create the meeting but the user can visit without any sign in.  
Pricing: Free until September 30th  
Video Resources: [Step by step guide on how to use Google Hangout](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DwGXI0KpkR50&sa=D&ust=1601935360694000&usg=AOvVaw3xRLjDf5-BhWW2d_0GTADh)

Paid Platforms:

Zoom for healthcare  
Pros: Zoom has a designated platform for medical services that supports Andriod and iOS. It allows for one to one meetings through video or audio and also hosts a dial in option. Hosts can choose whether participants can join the meeting before the host or have them wait in a meeting room until the doctor arrives. The doctor can schedule a meeting and send the link/dial in information to the patient ahead of the meeting via email  
Cons: You need to download the app to use it which may not be practicable for some older people if they are not technology inclined.  
Pricing: \$200 per host license (1 per practitioner) per month for unlimited use and HIPAA compliant.  
Cancellation: Cancel anytime on the monthly subscription  
Video Resources: [Setting up Zoom for telehealth professionals](https://www.google.com/url?q=https://www.youtube.com/watch?v%3D3ZLj5GRB6PQ&sa=D&ust=1601935360695000&usg=AOvVaw37xfeUh9U1bjKBUAIPPWMd) /[ Zoom for Healthcare](https://www.google.com/url?q=https://zoom.us/docs/doc/Zoom%2520for%2520Healthcare.pdf&sa=D&ust=1601935360695000&usg=AOvVaw3lqVCeFSGmj3Bp9eaychMq)

GoToMeeting  
Pros: Very mobile friendly if you don’t have two screens available. Android and iOS supported. The doctor can schedule a meeting and send the link/dial in information to the patient ahead of the meeting via email. If the patient clicks on the link before the doctor has launched the call, they are kept on a page which says that the organizer has not arrived yet. The appointment will automatically load from this page as soon as the doctor launches it.  
Cons: Web platform version may be confusing for some older patients who are not technology inclined.  
Pricing: $14 professional plan / $16 business plan per month for unlimited use. Both paid plans are HIPAA compliant  
Cancellation: Cancel anytime on the monthly subscription  
Video resources:[ How to join a meeting guide for attendees](https://www.google.com/url?q=https://www.youtube.com/watch?v%3D95dRdnMMgbQ&sa=D&ust=1601935360696000&usg=AOvVaw042fuoOvEX7ttZNddT9q_o)

Microsoft Teams  
Pros: Easy to use and mobile friendly if you don’t have two screens available and support Android and iOS. Doctors can schedule a meeting and invite the patient via the link. Patients do not need to register and will be put in a waiting room until the doctor arrives.

Cons: Privacy policy says that any text in the chat is automatically stored in OneNote (Microsoft App). It is however HIPAA compliant.

Pricing: Currently waiting for pricing information from Microsoft

Video Resources: [Microsoft healthcare information](https://www.google.com/url?q=https://products.office.com/en/microsoft-teams/healthcare-solutions&sa=D&ust=1601935360698000&usg=AOvVaw1dW_fSG1L-OhcmJKNlAcC2) / [How to schedule meetings](https://www.google.com/url?q=https://www.youtube.com/watch?v%3DfwsA2wC-c34&sa=D&ust=1601935360698000&usg=AOvVaw3UcirPEt4Qhgapk8gvi1sS)
