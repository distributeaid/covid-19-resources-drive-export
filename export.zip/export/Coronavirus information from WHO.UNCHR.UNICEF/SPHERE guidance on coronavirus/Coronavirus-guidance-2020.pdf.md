---
title: "Coronavirus-guidance-2020.pdf"
driveId: 1Q4RGd6W_r-um0q2GTBAe2SLqIlFwGlLD
modifiedTime: 2020-03-23T22:04:01.121Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1Q4RGd6W_r-um0q2GTBAe2SLqIlFwGlLD/view?usp=drivesdk
---

# Coronavirus-guidance-2020.pdf

[Click here](https://drive.google.com/file/d/1Q4RGd6W_r-um0q2GTBAe2SLqIlFwGlLD/view?usp=drivesdk) to download the file.