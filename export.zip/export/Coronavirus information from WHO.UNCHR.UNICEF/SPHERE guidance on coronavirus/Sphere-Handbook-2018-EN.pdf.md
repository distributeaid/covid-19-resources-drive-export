---
title: "Sphere-Handbook-2018-EN.pdf"
driveId: 1cweFJZtdmeE9FMlumh15mc_0fxMEbmyK
modifiedTime: 2020-05-02T17:41:31.000Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1cweFJZtdmeE9FMlumh15mc_0fxMEbmyK/view?usp=drivesdk
---

# Sphere-Handbook-2018-EN.pdf

[Click here](https://drive.google.com/file/d/1cweFJZtdmeE9FMlumh15mc_0fxMEbmyK/view?usp=drivesdk) to download the file.