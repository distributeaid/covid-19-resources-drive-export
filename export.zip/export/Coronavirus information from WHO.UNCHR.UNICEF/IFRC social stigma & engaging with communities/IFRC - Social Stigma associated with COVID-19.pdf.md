---
title: "IFRC - Social Stigma associated with COVID-19.pdf"
driveId: 1J3FJJXSWz08vVH2oeIfp-F_8fhg0g1FG
modifiedTime: 2020-03-23T22:03:43.056Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1J3FJJXSWz08vVH2oeIfp-F_8fhg0g1FG/view?usp=drivesdk
---

# IFRC - Social Stigma associated with COVID-19.pdf

[Click here](https://drive.google.com/file/d/1J3FJJXSWz08vVH2oeIfp-F_8fhg0g1FG/view?usp=drivesdk) to download the file.