---
title: "IFRC - Engaging with Communities on Coronavirus and COVID-19.pdf"
driveId: 1jByi2oFQCJEfcrpQvjDkovpplKTUjpPj
modifiedTime: 2020-03-23T22:03:42.024Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1jByi2oFQCJEfcrpQvjDkovpplKTUjpPj/view?usp=drivesdk
---

# IFRC - Engaging with Communities on Coronavirus and COVID-19.pdf

[Click here](https://drive.google.com/file/d/1jByi2oFQCJEfcrpQvjDkovpplKTUjpPj/view?usp=drivesdk) to download the file.