---
title: "protect-yourself-and-others"
driveId: 1gtNyhzhloqOMRmo5ZZeSnPPAxuT8w-dVvDDNJ3YSIpg
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-23T22:13:49.838Z
---

#

- [Home](https://www.google.com/url?q=http://www.emro.who.int/health-topics/corona-virus/index.html&sa=D&ust=1601935362041000&usg=AOvVaw11l3sf42ImeZ_jwr81W_zd)
- [Information resources](https://www.google.com/url?q=http://www.emro.who.int/health-topics/corona-virus/information-resources.html&sa=D&ust=1601935362041000&usg=AOvVaw39Tr7cxrxUQbs3_MzCGfcI)
- [Questions and answers](https://www.google.com/url?q=http://www.emro.who.int/health-topics/corona-virus/questions-and-answers.html&sa=D&ust=1601935362042000&usg=AOvVaw1iZn-oUFcdF8npqCIH4w2I)
- [Related links](https://www.google.com/url?q=http://www.emro.who.int/health-topics/corona-virus/related-links.html&sa=D&ust=1601935362042000&usg=AOvVaw0xCsf-UiXRjlJgQP4OqGQL)

- [Menu](#id.30j0zll)
- [Chercher](#id.30j0zll)
- [Contacter](https://www.google.com/url?q=http://www.emro.who.int/fr/commentaires-demandes.html&sa=D&ust=1601935362044000&usg=AOvVaw0FoMxSDuJ1OLmEVBEZ3QMB)

- [YouTube](https://www.google.com/url?q=https://www.youtube.com/channel/UCT7a_fVlSrjOs9jyvtH-uhA&sa=D&ust=1601935362045000&usg=AOvVaw1AZniy5o4VTowE_rTTk3zj)
- [Rss feeds](https://www.google.com/url?q=http://www.emro.who.int/rss-feeds.html&sa=D&ust=1601935362046000&usg=AOvVaw3w3PP6jzRY8W3YLjvplx8M)
- [Twitter](https://www.google.com/url?q=https://twitter.com/whoemro&sa=D&ust=1601935362046000&usg=AOvVaw13QWPtirVvhWKDdlbwl5u0)
- [Facebook](https://www.google.com/url?q=https://www.facebook.com/WHOEMRO?sk%3Dwall&sa=D&ust=1601935362046000&usg=AOvVaw3Tj1nYFD-hmPLYfazt4Q3P)

- [Accueil](https://www.google.com/url?q=http://docs.google.com/fr/index.html&sa=D&ust=1601935362047000&usg=AOvVaw2Gce2nQv0moQ_IGui_sQPU)
- [Thèmes de santé](https://www.google.com/url?q=http://docs.google.com/fr/health-topics.html&sa=D&ust=1601935362047000&usg=AOvVaw1Gsmb2_FFNbPDIyYeJyPNw)
- [Données et statistiques](https://www.google.com/url?q=http://docs.google.com/fr/entity/statistiques/statistics.html&sa=D&ust=1601935362048000&usg=AOvVaw2RQZGmULfkD8_w51biIDzX)
- [Centre des médias](https://www.google.com/url?q=http://docs.google.com/fr/entity/media/introduction.html&sa=D&ust=1601935362048000&usg=AOvVaw2oFvGJ1io71cTJCohD5dos)
- [Ressources](https://www.google.com/url?q=http://docs.google.com/fr/entity/information-resources/&sa=D&ust=1601935362049000&usg=AOvVaw1ImUXCVLkq8ijELGUtVApn)
- [Pays](https://www.google.com/url?q=http://docs.google.com/fr/countries.html&sa=D&ust=1601935362049000&usg=AOvVaw0CJb-J30a_tzInGILvJZR-)
- [Programmes](https://www.google.com/url?q=http://docs.google.com/fr/programmes.html&sa=D&ust=1601935362049000&usg=AOvVaw219lqDWubZABXGFqXd6nCD)
- [À propos de l'OMS](https://www.google.com/url?q=http://docs.google.com/fr/entity/about-us/&sa=D&ust=1601935362050000&usg=AOvVaw20VsOfqCUbm9YWP4Tyu12m)

[Coronavirus](https://www.google.com/url?q=http://docs.google.com/fr/health-topics/corona-virus/index.html&sa=D&ust=1601935362050000&usg=AOvVaw1kmbHhBUQqU-h4AVnLpF9S) | [Ressources d’information](https://www.google.com/url?q=http://docs.google.com/fr/health-topics/corona-virus/information-resources.html&sa=D&ust=1601935362050000&usg=AOvVaw1JZnrAnoqGDFur3txbSrdT) | Protect your self and others

###

Sections

#### Vous êtes ici

- [Coronavirus](https://www.google.com/url?q=http://docs.google.com/fr/health-topics/corona-virus/index.html&sa=D&ust=1601935362051000&usg=AOvVaw3wB0UakLHYEGOR8_z69vIq)
- [Questions fréquentes](https://www.google.com/url?q=http://docs.google.com/fr/health-topics/corona-virus/questions-and-answers.html&sa=D&ust=1601935362052000&usg=AOvVaw3LDpPQ0bNy6UHtTp9UDC-C)
- [Ressources d’information](https://www.google.com/url?q=http://docs.google.com/fr/health-topics/corona-virus/information-resources.html&sa=D&ust=1601935362052000&usg=AOvVaw0S5NBd6lkIkkBD_ymzNkLm)
- [Technical guidelines](https://www.google.com/url?q=https://www.who.int/emergencies/diseases/novel-coronavirus-2019/technical-guidance&sa=D&ust=1601935362053000&usg=AOvVaw06LDxzw-QA3iSOpKdblcaG)
- [Liens connexes](https://www.google.com/url?q=http://docs.google.com/fr/health-topics/corona-virus/related-links.html&sa=D&ust=1601935362053000&usg=AOvVaw2YrvzWOyN9f3bH32KuNDMJ)

##

Protégez-vous



- ### [Pour le grand public](https://www.google.com/url?q=http://applications.emro.who.int/docs/EMCSR255F.pdf&sa=D&ust=1601935362055000&usg=AOvVaw3jep-17v33PBhTv-tJo_Aq)

- ### [Pour les agents de santé](https://www.google.com/url?q=http://applications.emro.who.int/docs/EMCSR257F.pdf&sa=D&ust=1601935362056000&usg=AOvVaw0IlfM6WHtPteDF0TV2lYps)

- ### [Santé des voyageurs](https://www.google.com/url?q=http://applications.emro.who.int/docs/EMCSR256F.pdf&sa=D&ust=1601935362057000&usg=AOvVaw3mlEiaZFGB15a3HYniyHHZ)

- ### [Autres infographies](https://www.google.com/url?q=https://www.who.int/fr/emergencies/diseases/novel-coronavirus-2019/advice-for-public&sa=D&ust=1601935362057000&usg=AOvVaw2_3W8_7cBst-vKyr0w4aJF)

Share

- [Facebook](https://www.google.com/url?q=https://www.facebook.com/sharer/sharer.php?u%26t&sa=D&ust=1601935362058000&usg=AOvVaw0qz1NzfKBF3pyZElJpKHZQ)

- [Twitter](https://www.google.com/url?q=https://twitter.com/intent/tweet&sa=D&ust=1601935362059000&usg=AOvVaw3tUhNjcdc30C9kfVl1mz42)

- [Google+](https://www.google.com/url?q=https://plus.google.com/share?url&sa=D&ust=1601935362059000&usg=AOvVaw0oCyuBohq21j9sAD33jF0l)

-

###

Plan du site

- [Accueil](https://www.google.com/url?q=http://docs.google.com/fr/index.html&sa=D&ust=1601935362060000&usg=AOvVaw2guA4_-07Ya24CJE9_noLe)
- [Thèmes de santé](https://www.google.com/url?q=http://docs.google.com/fr/health-topics.html&sa=D&ust=1601935362060000&usg=AOvVaw34CWgGb1aLQvhGOqMjIJee)
- [Données et statistiques](https://www.google.com/url?q=http://docs.google.com/fr/entity/statistiques/statistics.html&sa=D&ust=1601935362061000&usg=AOvVaw1aNSxyWUSyknQXZGi3-89A)
- [Centre des médias](https://www.google.com/url?q=http://docs.google.com/fr/entity/media/&sa=D&ust=1601935362061000&usg=AOvVaw0T0StQgrjOFAc4ZGJmZoOf)
- [Ressources](https://www.google.com/url?q=http://docs.google.com/fr/entity/information-resources/&sa=D&ust=1601935362062000&usg=AOvVaw36pu45W6p6lyKiPQ3R4VmY)
- [Pays](https://www.google.com/url?q=http://docs.google.com/fr/countries.html&sa=D&ust=1601935362062000&usg=AOvVaw0kNYairSgQKNmSJ_0oYdYD)
- [Programmes](https://www.google.com/url?q=http://docs.google.com/fr/programmes.html&sa=D&ust=1601935362062000&usg=AOvVaw0ibb2MLdUg0iTkyRiIc2zI)
- [À propos de l'OMS](https://www.google.com/url?q=http://docs.google.com/fr/entity/about-us/&sa=D&ust=1601935362063000&usg=AOvVaw3MfgBMNiC4FgbSj_5vCzTH)

###

Aide et services

- [Emplois](https://www.google.com/url?q=http://docs.google.com/fr/about-who/employment-with-who/&sa=D&ust=1601935362063000&usg=AOvVaw07MVU_OFhLzsHVePnY9mxE)
- [Droits d’auteur](https://www.google.com/url?q=http://docs.google.com/fr/copyright.html&sa=D&ust=1601935362064000&usg=AOvVaw0ilKEYOTFz9drFxcaywFzB)
- [Confidentialité](https://www.google.com/url?q=http://docs.google.com/fr/privacy.html&sa=D&ust=1601935362064000&usg=AOvVaw3EMzCEe9Kqz8ypHQ43E5In)
- [Nous contacter](https://www.google.com/url?q=http://docs.google.com/fr/commentaires-demandes.html&sa=D&ust=1601935362065000&usg=AOvVaw1Q284r8zgR-pG4jaVgaR3K)
- [Accès à distance](https://www.google.com/url?q=http://outlook.emro.who.int&sa=D&ust=1601935362065000&usg=AOvVaw13fwdCny4gEt3_IokHxN2U)
- [Se connecter](https://www.google.com/url?q=http://docs.google.com/index.php?option%3Dcom_user%26view%3Dlogin%26Itemid%3D61&sa=D&ust=1601935362066000&usg=AOvVaw24k8ekPIgwyiPLIbuk3sSU)

###

Bureaux de l'OMS

- [Siège de l'OMS](https://www.google.com/url?q=http://www.who.int&sa=D&ust=1601935362066000&usg=AOvVaw0VjUne3aUeBPCnQSL62kPh)
- [Région de l'Afrique](https://www.google.com/url?q=http://www.afro.who.int&sa=D&ust=1601935362066000&usg=AOvVaw0eMGrvfHF2ZSWrV1c2FaZK)
- [Région des Amériques](https://www.google.com/url?q=http://www.paho.org&sa=D&ust=1601935362067000&usg=AOvVaw3T-bshsXfWXD10rVeytaXZ)
- [Région de l'Asie du Sud-Est](https://www.google.com/url?q=http://www.searo.who.int/en/&sa=D&ust=1601935362067000&usg=AOvVaw2xtezxa25zdmmeKyz-rMhA)
- [Région de l'Europe](https://www.google.com/url?q=http://www.euro.who.int&sa=D&ust=1601935362067000&usg=AOvVaw2UuWh7GKgm4fx7NGSp9hCZ)
- [Région du Pacifique occidental](https://www.google.com/url?q=http://www.wpro.who.int&sa=D&ust=1601935362068000&usg=AOvVaw3gfQrHepTgCkMY1lf--Rzy)

###

Connecter avec nous

- [YouTube](https://www.google.com/url?q=https://www.youtube.com/channel/UCT7a_fVlSrjOs9jyvtH-uhA&sa=D&ust=1601935362068000&usg=AOvVaw0TzE7rOc4uTZ8mS7X-voUV)
- [RSS feeds](https://www.google.com/url?q=http://docs.google.com/fr/rss-feeds.html&sa=D&ust=1601935362069000&usg=AOvVaw2I28cSloE1cDF5S1Jfdx7I)
- [Twitter](https://www.google.com/url?q=https://twitter.com/whoemro&sa=D&ust=1601935362069000&usg=AOvVaw2wy0SRj9T2PWWxLtGcUtBY)
- [Facebook](https://www.google.com/url?q=https://www.facebook.com/WHOEMRO?sk%3Dwall&sa=D&ust=1601935362069000&usg=AOvVaw2WakXNeuRI2tQ8LpMwuIOY)

[© OMS 2020](https://www.google.com/url?q=http://docs.google.com/fr/copyright.html&sa=D&ust=1601935362070000&usg=AOvVaw1nan7oHM5KDshUIoqaBg1G)
