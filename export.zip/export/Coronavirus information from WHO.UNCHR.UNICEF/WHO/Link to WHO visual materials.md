---
title: "Link to WHO visual materials"
driveId: 18_H57NKaSR6Hkdx8UHFoE7rE6kzs_cbVnnTovXY-SxY
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-03-24T01:06:00.994Z
---

Link to WHO visual materials: [http://www.emro.who.int/ar/health-topics/corona-virus/information-resources.html](https://www.google.com/url?q=http://www.emro.who.int/ar/health-topics/corona-virus/information-resources.html&sa=D&ust=1601935359611000&usg=AOvVaw0PS-T3M3zuvqY74zLXY3vx)
