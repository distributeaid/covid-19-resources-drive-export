---
title: "Flyer-urdu ver3 (1)_fnl.pdf"
driveId: 1T6kRPuTJUXkAP1IKhaA_Ev1Lef9T1VKZ
modifiedTime: 2020-03-23T22:13:34.924Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1T6kRPuTJUXkAP1IKhaA_Ev1Lef9T1VKZ/view?usp=drivesdk
---

# Flyer-urdu ver3 (1)_fnl.pdf

[Click here](https://drive.google.com/file/d/1T6kRPuTJUXkAP1IKhaA_Ev1Lef9T1VKZ/view?usp=drivesdk) to download the file.