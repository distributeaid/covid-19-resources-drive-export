---
title: "Flyer-urdu ver3_fnl.pdf"
driveId: 18kEwRExCh003bbYdbLqmDcF30xa1yLiC
modifiedTime: 2020-03-23T22:13:36.816Z
mimeType: application/pdf
url: https://drive.google.com/file/d/18kEwRExCh003bbYdbLqmDcF30xa1yLiC/view?usp=drivesdk
---

# Flyer-urdu ver3_fnl.pdf

[Click here](https://drive.google.com/file/d/18kEwRExCh003bbYdbLqmDcF30xa1yLiC/view?usp=drivesdk) to download the file.