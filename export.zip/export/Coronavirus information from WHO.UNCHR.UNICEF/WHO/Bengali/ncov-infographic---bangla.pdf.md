---
title: "ncov-infographic---bangla.pdf"
driveId: 1za2JsQoVXD1KD5M3OpkyI1mC3fzh5NG6
modifiedTime: 2020-03-23T22:13:30.342Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1za2JsQoVXD1KD5M3OpkyI1mC3fzh5NG6/view?usp=drivesdk
---

# ncov-infographic---bangla.pdf

[Click here](https://drive.google.com/file/d/1za2JsQoVXD1KD5M3OpkyI1mC3fzh5NG6/view?usp=drivesdk) to download the file.