---
title: "Questions-réponses sur la protection contre le coronavirus.mp4"
driveId: 1dfzxA-PqjCRRyUkTXhBqTo1_sQpUil0_
modifiedTime: 2020-03-23T22:13:56.002Z
mimeType: video/mp4
url: https://drive.google.com/file/d/1dfzxA-PqjCRRyUkTXhBqTo1_sQpUil0_/view?usp=drivesdk
---

# Questions-réponses sur la protection contre le coronavirus.mp4

[Click here](https://drive.google.com/file/d/1dfzxA-PqjCRRyUkTXhBqTo1_sQpUil0_/view?usp=drivesdk) to download the file.