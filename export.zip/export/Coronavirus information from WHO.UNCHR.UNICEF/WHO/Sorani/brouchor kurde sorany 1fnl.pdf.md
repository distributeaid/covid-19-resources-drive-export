---
title: "brouchor kurde sorany 1fnl.pdf"
driveId: 1eIDl1-nACw-ND1tiuMPNRiFhjhRzexAb
modifiedTime: 2020-03-23T22:15:00.935Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1eIDl1-nACw-ND1tiuMPNRiFhjhRzexAb/view?usp=drivesdk
---

# brouchor kurde sorany 1fnl.pdf

[Click here](https://drive.google.com/file/d/1eIDl1-nACw-ND1tiuMPNRiFhjhRzexAb/view?usp=drivesdk) to download the file.