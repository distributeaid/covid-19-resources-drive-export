---
title: "brouchor kurdy sorany_fnl.pdf"
driveId: 11k8dtI4xrFg4P8iWgidDA7cTW6Qde07W
modifiedTime: 2020-03-23T22:15:06.187Z
mimeType: application/pdf
url: https://drive.google.com/file/d/11k8dtI4xrFg4P8iWgidDA7cTW6Qde07W/view?usp=drivesdk
---

# brouchor kurdy sorany_fnl.pdf

[Click here](https://drive.google.com/file/d/11k8dtI4xrFg4P8iWgidDA7cTW6Qde07W/view?usp=drivesdk) to download the file.