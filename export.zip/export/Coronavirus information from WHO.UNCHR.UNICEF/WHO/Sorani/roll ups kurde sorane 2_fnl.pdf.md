---
title: "roll ups kurde sorane 2_fnl.pdf"
driveId: 1PngX2y9KxdomgWWV3bQ7ahHhEw8csLNt
modifiedTime: 2020-03-23T22:15:35.670Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1PngX2y9KxdomgWWV3bQ7ahHhEw8csLNt/view?usp=drivesdk
---

# roll ups kurde sorane 2_fnl.pdf

[Click here](https://drive.google.com/file/d/1PngX2y9KxdomgWWV3bQ7ahHhEw8csLNt/view?usp=drivesdk) to download the file.