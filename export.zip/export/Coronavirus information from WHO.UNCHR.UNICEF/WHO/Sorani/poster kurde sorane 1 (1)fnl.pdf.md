---
title: "poster kurde sorane 1 (1)fnl.pdf"
driveId: 1itl_zqcXhDN6jr34fmcbTW-ToucT7K1X
modifiedTime: 2020-03-23T22:15:12.025Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1itl_zqcXhDN6jr34fmcbTW-ToucT7K1X/view?usp=drivesdk
---

# poster kurde sorane 1 (1)fnl.pdf

[Click here](https://drive.google.com/file/d/1itl_zqcXhDN6jr34fmcbTW-ToucT7K1X/view?usp=drivesdk) to download the file.