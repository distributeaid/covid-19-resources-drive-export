---
title: "brochor kurde sorane 3_fnl.pdf"
driveId: 1xj27L3Zhme4jxIuHl8AdvUUkY5_3TlT2
modifiedTime: 2020-03-23T22:14:57.690Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1xj27L3Zhme4jxIuHl8AdvUUkY5_3TlT2/view?usp=drivesdk
---

# brochor kurde sorane 3_fnl.pdf

[Click here](https://drive.google.com/file/d/1xj27L3Zhme4jxIuHl8AdvUUkY5_3TlT2/view?usp=drivesdk) to download the file.