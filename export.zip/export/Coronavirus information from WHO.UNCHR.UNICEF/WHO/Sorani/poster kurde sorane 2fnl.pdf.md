---
title: "poster kurde sorane 2fnl.pdf"
driveId: 1xvVegdORKKm2zp9NeBaK4LHoAi22Nd7Y
modifiedTime: 2020-03-23T22:15:21.283Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1xvVegdORKKm2zp9NeBaK4LHoAi22Nd7Y/view?usp=drivesdk
---

# poster kurde sorane 2fnl.pdf

[Click here](https://drive.google.com/file/d/1xvVegdORKKm2zp9NeBaK4LHoAi22Nd7Y/view?usp=drivesdk) to download the file.