---
title: "poster kurde sorane 1fnl.pdf"
driveId: 1XyPG4-4a_loYqt5YOe_8TWw4kR13OOc8
modifiedTime: 2020-03-23T22:15:16.468Z
mimeType: application/pdf
url: https://drive.google.com/file/d/1XyPG4-4a_loYqt5YOe_8TWw4kR13OOc8/view?usp=drivesdk
---

# poster kurde sorane 1fnl.pdf

[Click here](https://drive.google.com/file/d/1XyPG4-4a_loYqt5YOe_8TWw4kR13OOc8/view?usp=drivesdk) to download the file.