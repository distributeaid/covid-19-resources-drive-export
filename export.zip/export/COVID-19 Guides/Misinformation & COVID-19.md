---
title: "Misinformation & COVID-19"
driveId: 1hhMKCdLF7zJGsv0gg4Ir4Mqo9t7GeUFYa6rssR8KH1k
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-06-02T11:46:32.481Z
---

# Combating Misinformation about COVID-19

## Introduction

### Purpose

This guide will give you tools and strategies to address the “infodemic” surrounding COVID-19. Spotting and combating misinformation about COVID-19 can help prevent the spread of the virus itself and also alleviate the fear, confusion, and potential harms caused by erroneous information. The more accurate information our communities have about COVID-19, the better prepared they will be to fight the spread and help take care of each other safely and confidently.

### Get Involved

Discover: You can find the latest version, translations, and other COVID-19 related guides and handouts on our website.  
[https://resources.distributeaid.org/](https://www.google.com/url?q=https://resources.distributeaid.org/&sa=D&ust=1601935360231000&usg=AOvVaw34HBktAW40pGsbUSq-danJ)

Share: This guide is free - share, print, rehost, or even remix it\!  We have released all of our COVID-19 guides under the CC-BY-SA license.

[https://creativecommons.org/licenses/by-sa/4.0/](https://www.google.com/url?q=https://creativecommons.org/licenses/by-sa/4.0/&sa=D&ust=1601935360232000&usg=AOvVaw2G9x1iLaDGbl20fzFYmrkn)

Contribute: Please see the contributing section of our website, and [join our slack](https://www.google.com/url?q=https://join.slack.com/t/distribute-aid/shared_invite/zt-cw357u9t-tbbd5CLDaaZCkiWd5LrOow&sa=D&ust=1601935360232000&usg=AOvVaw2ymuiE4Dk0_9Osxkbeg9Fm).

[https://resources.distributeaid.org/](https://www.google.com/url?q=https://resources.distributeaid.org%23contribute&sa=D&ust=1601935360233000&usg=AOvVaw3Fjyw0bk8cgdgi6lgOpe8Z)

Translate: Please see the translation section of our website, and [join our slack](https://www.google.com/url?q=https://join.slack.com/t/distribute-aid/shared_invite/zt-cw357u9t-tbbd5CLDaaZCkiWd5LrOow&sa=D&ust=1601935360234000&usg=AOvVaw3PzQuh0rZWsEuPosAbMC1m).

[https://resources.distributeaid.org/](https://www.google.com/url?q=https://resources.distributeaid.org%23translation&sa=D&ust=1601935360234000&usg=AOvVaw3ZKMEW8onum9Le-YyOA0Ou)

Donate: We hope this guide is helpful\! If you’d like to say thanks, please consider donating to Help Refugees.  They will direct your donation to a refugee aid group with critical needs.

[https://donate.helprefugees.org/campaigns/donate/](https://www.google.com/url?q=https://donate.helprefugees.org/campaigns/donate/&sa=D&ust=1601935360235000&usg=AOvVaw2H-BOCybneqcd-s-26JIoV)

## Examples of COVID-19 Misinformation

Buzzfeed is keeping [a running list](https://www.google.com/url?q=https://www.buzzfeednews.com/article/janelytvynenko/coronavirus-fake-news-disinformation-rumors-hoaxes&sa=D&ust=1601935360236000&usg=AOvVaw2oC5CaKSzLm3q77Fk2xzRn) of current misinformation and hoaxes surrounding COVID-19. Most of the misinformation seems to fall within a few main categories:

- Attempts to profit off of COVID-19 by advertising a particular product as a cure or preventive measure
- False claims from ‘anonymous insiders’ or ‘trusted sources’ about actions governments and organizations like the UN  are taking or will be taking
- False or misleading scientific/medical information about COVID-19 (how it’s spread, how it can be prevented, treatments and cures, etc.)
- False information stigmatizing a particular group of people, especially Chinese people and other people of Asian descent
- Scammers pretending to be from government organizations offering people payments in order to get their bank and personal information

## How to Spot Misinformation

### Common Signs of Misinformation

Misinformation ‘Red Flags’

While none of these factors is dispositive, these are some common signs that indicate information may not be accurate or needs to be verified before sharing:

🚫 The information has no verifiable source. Examples:

- No source is listed for the information
- The information is attributed to a ‘friend of a friend’
- The information is attributed to an ‘unnamed official’ or an ‘anonymous source’ within a legitimate and trusted agency like the CDC or Red Cross
- The information is attributed to a general job or position but not to a specific person or organization, such as ‘a doctor in Washington, D.C.’ or ‘a health official in Cairo’

🚫 The information comes from a source who may profit by the spread of such misinformation. Examples:

- You can prevent or cure COVID-19 just by using a particular branded product
- You can prevent or cure COVID-19 by purchasing a product the person who gives you that information is selling

🚫 The information seems too good or easy to be true. Examples:

- You can prevent or cure COVID-19 just by drinking hot tea or a lot of water
- You can test if you have COVID-19 just by holding your breath

🚫  The information is forwarded from a chain text, Whatsapp message, or email

🚫 The information contains sensational, inflammatory, and divisive language

🚫 The information targets, blames or stigmatizes a particular group of people (refugee aid organizations should be particularly wary of this sort of misinformation as it may be directed at refugees and/or aid workers)

### Verifying Suspect Information

Verification Questions



This set of questions can help you gather helpful background on a piece of information you would like to verify. Consider:

?  Are you looking at the original piece of this content? (Ex. looking at guidelines on the CDC website rather than a text message that claims it is citing the CDC)

? Where does the original piece of content come from/who published it?

? What’s the date on the content/when was it first published?

? What are the potential motivation(s) behind publishing that piece of content?

? Are claims made backed up by reliable evidence?

? If the content is image-based, what message(s) is the picture potentially sending?

Verification Tips

✅ Verify information using official and impartial sources like the CDC and WHO

✅ Check the date of the information to see when it was published (this is especially important given that a lot of information about COVID-19 is rapidly evolving)

✅ Check out the source’s purported author. Are they real? If so, are they credible?

✅ Check whether scientific research has been peer-reviewed yet - lots of research on Coronavirus remains totally unreviewed and so the claims they make may be invalid\! [Journalist’s Resources](https://www.google.com/url?q=https://journalistsresource.org/studies/economics/coronavirus-research-economy/&sa=D&ust=1601935360241000&usg=AOvVaw1H0IagrxG0z07QhQoVcofK) does helpful round-ups of verified research

✅ If the information is related to an image, [reverse-search the image](https://www.google.com/url?q=https://support.google.com/websearch/answer/1325808?co%3DGENIE.Platform%253DDesktop%26hl%3Den&sa=D&ust=1601935360242000&usg=AOvVaw0vIbf-bCtwYylZUWNv2Rbb) to check that it actually shows what it claims to\! Often images are misattributed

Cautionaries

🚫 Just because information is cited as coming from an official or trusted source, doesn’t mean it actually came from there - verify before sharing

🚫 Information may look scientific or have lots of numbers or charts - that doesn’t inherently mean that information is accurate

🚫 Not all research is created equal\! A ‘study’ may make a scientific or factual claim that’s based on very little evidence. Try and find peer-reviewed studies from reputable, trusted scientific and medical organizations

## How to Combat Misinformation

### Think Before You Share

One of the best ways to combat the spread of misinformation is not to share it. Consider the following questions before sharing:

? Why am I sharing this content? What purpose does it serve?

? Have I gone through the questions and steps in the previous section to verify this content before sharing?

? Have I read ‘beyond the headline’? Have I made sure to read all of the article or content that I am sharing?

? Does the content I am sharing include links to reputable organizations to back any medical or scientific claims it makes?

⭐ If you’re not sure, don’t share it

### Truth Sandwiches

Reporting inaccurate information first and then debunking it [may actually reinforce the inaccurate information](https://www.google.com/url?q=https://www.npr.org/sections/memmos/2018/06/20/621753252/lets-put-truth-sandwiches-on-our-menu&sa=D&ust=1601935360244000&usg=AOvVaw1UxNldQxRSRaVmfx4Bzm1c) in the minds of readers. Instead, we recommend the ‘truth sandwich method’:

1.  Start with the truth
2.  Indicate the lie (avoid amplifying the specific language, if possible)
3.  Return to the truth

⭐ Always make sure you repeat the truth more times than the lie(s) that you are debunking

Here’s an example of a truth sandwich in practice - to show you the different parts, we have bolded the truthful sections which contain the underlined inaccurate information they are debunking:

COVID-19 can infect people of any age, despite inaccurate information being spread online that the virus only infects older people. While most confirmed cases of COVID-19 have been in adults, children are not immune, as all age groups can become infected with the virus.

### Addressing Stigma

⭐⭐⭐Refugee aid groups should pay special attention to any misinformation that stigmatizes refugees and other vulnerable groups. [UNICEF reports](https://www.google.com/url?q=https://www.unicef.org/documents/social-stigma-associated-coronavirus-disease-covid-19&sa=D&ust=1601935360245000&usg=AOvVaw0ZlcSJUDH19AsYbAuhZN7I)that rumors and misinformation about COVID-19 are contributing to stigma and discrimination, which hampers response efforts. Some of these inaccurate and dangerous narratives about refugee groups can be countered by:

✅ Sharing sympathetic narratives, including stories that humanize the experiences and struggles of the stigmatized group affected by COVID-19

✅ Sharing stories of the stigmatized group positively impact COVID-19 prevention and response efforts, or supporting the surrounding communities impacted by COVID-19

✅ Challenging myths, stereotypes, and harmful misinformation about stigmatized groups and COVID-19

✅ Ensuring your organization’s materials portray diverse communities that are working together to fight COVID-19

✅ Amplifying the voices and stories of stigmatized people

See more on how to address COVID-19 related stigma here:

[https://www.unicef.org/documents/social-stigma-associated-coronavirus-disease-covid-19](https://www.google.com/url?q=https://www.unicef.org/documents/social-stigma-associated-coronavirus-disease-covid-19&sa=D&ust=1601935360247000&usg=AOvVaw0U6GjVGafcIpVGNoynG2Nz)

[https://www.cdc.gov/coronavirus/2019-ncov/symptoms-testing/reducing-stigma.html](https://www.google.com/url?q=https://www.cdc.gov/coronavirus/2019-ncov/symptoms-testing/reducing-stigma.html&sa=D&ust=1601935360247000&usg=AOvVaw2tOLLXpnZFy2RSzUxLAVkP)

## Reliable Sources of Information

- The [WHO’s coronavirus page](https://www.google.com/url?q=https://www.who.int/health-topics/coronavirus%23tab%3Dtab_1&sa=D&ust=1601935360248000&usg=AOvVaw3yPG2VILzZ8AYQNBLaGhC9) has updated statistics and recommendations
- The WHO has a [list of common COVID-19 myths](https://www.google.com/url?q=https://www.who.int/emergencies/diseases/novel-coronavirus-2019/advice-for-public/myth-busters&sa=D&ust=1601935360248000&usg=AOvVaw1Ft1-OJWJJ2mCRS8Udvf-O)
- Johns Hopkins has an [updated map](https://www.google.com/url?q=https://systems.jhu.edu/research/public-health/ncov/&sa=D&ust=1601935360249000&usg=AOvVaw1wJZE8mHlhtqj6vosXJMEO) tracking COVID-19’s global spread
- Medical News Today’s [list of COVID-19 myths](https://www.google.com/url?q=https://www.medicalnewstoday.com/articles/coronavirus-myths-explored&sa=D&ust=1601935360249000&usg=AOvVaw1YY4B8yc-D9ENhFlwZkQ_W) and updated  
  [medically-reviewed news about COVID-19](https://www.google.com/url?q=https://www.medicalnewstoday.com/coronavirus&sa=D&ust=1601935360249000&usg=AOvVaw3gOwSsr7n4dGb2YDlzUNLV)
- [Journalist’s Resources](https://www.google.com/url?q=https://journalistsresource.org/studies/economics/coronavirus-research-economy/&sa=D&ust=1601935360250000&usg=AOvVaw29zgM5oDA4Opxwt7AEfQ2V) does helpful round-ups of verified scientific research.
- [On Snopes](https://www.google.com/url?q=https://www.snopes.com/fact-check/covid-19-mask-efficacy-chart/&sa=D&ust=1601935360250000&usg=AOvVaw3XgArSBqQWuPak831Zx92R)you can verify articles, facts and info-graphics which are often spread via social media
