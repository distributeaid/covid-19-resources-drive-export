---
title: "Accountability in Aid Supply Chains"
driveId: 1DXVt1_beEFoltbh2lO8ADTmOQCIFn6O1mQOYEHJseqw
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-06-02T11:50:42.044Z
---

# Trust, Transparency & Transport: Accountability Standards for Aid Supply Chains

## Introduction

The goal of this guide is to provide general best practices and suggestions on how to increase transparency and accountability throughout each step of the aid supply chain process. This document is intended to give an overview of various key accountability considerations for aid organizations, while the resources linked throughout provide examples, templates, and more in-depth guides concerning specific parts of the supply chain process.

### Transparency & Trust

General Guidelines

Though steps to increase transparency and trustworthiness can be taken throughout the stages of the supply chain process, developing transparent organizational practices can and should occur prior to beginning a partnership or project.

Consider the following practices to increase organizational transparency and trustworthiness:

- Engage in unilateral information sharing with the broader aid group community, monitoring/welfare groups, and potential partners
- Develop and make public standards codifying the specific transparency obligations of your organization
- Make effective grievance or complaint mechanisms available and accessible; make your complaint and resolution procedures publicly known
- Include a process for anonymous reporting
- Ensure these processes protect the privacy of whistleblowers and guard against potential retaliatory actions
- Resolve to partner only with organizations committed to the same standards of transparency and accountability
- Have risk management procedures in place, which you can share with partner organizations
- Be candid about the status of your organization on your website (for-profit, non-profit & where registered, etc.), including your tax-exempt status (if applicable)
- Record all relevant data related to your aid work. It’s important to keep dated, organized records about your organization’s work and financials
- Write-up a set of data entry procedures for your organization
- Keep your data clean and updated (tips [here](https://www.google.com/url?q=https://www.sfgnetwork.com/blog/associations-nonprofits/nonprofits-need-clean-data-to-thrive/&sa=D&ust=1601935360348000&usg=AOvVaw310-wt_JO_3CefsBVRa8nb))
- Make sure any potentially sensitive data is kept in line with appropriate privacy measures (see Relief International’s data protection guidelines [here](https://www.google.com/url?q=https://www.ri.org/data-protection-policy/&sa=D&ust=1601935360349000&usg=AOvVaw3KabEH9dINXXGJkm9R7mTD))
- This is especially relevant in conflict situations or when dealing with authoritarian governments: poorly managed personal data in these environments can literally mean life or death
- Consider your country’s data protection laws

\*\*\*If you are involved in COVID-19 humanitarian efforts, consider publishing your data with the [International Aid Transparency Initiative](https://www.google.com/url?q=https://docs.google.com/document/d/11XTnrPw8K76JvBhFfnqo-1Z9BmgqzWv2bEz9QoDrw2k/edit&sa=D&ust=1601935360350000&usg=AOvVaw1y79ZdENEIyJGtFeLeroVQ)

Examples:

- Direct Relief provides their annual reports, donation policies, and financial policies [on their site](https://www.google.com/url?q=https://www.directrelief.org/about/transparency/&sa=D&ust=1601935360351000&usg=AOvVaw39sYwNuR_DM1hs9VWlCMTX) in order to increase transparency
- DG Echo financial statement [template](https://www.google.com/url?q=https://www.dgecho-partners-helpdesk.eu/_media/action_proposal/fill_in_the_sf/final_financial_statement_template.xls&sa=D&ust=1601935360352000&usg=AOvVaw3KLvVJKTfZq5fd8OH9BmtZ) and [sample](https://www.google.com/url?q=https://www.dgecho-partners-helpdesk.eu/_media/action_proposal/fill_in_the_sf/sample_financial_statement.xls&sa=D&ust=1601935360353000&usg=AOvVaw0jCXViLdVLi2MMOMxi7xyK) for humanitarian organizations they fund
- HP regularly releases [sustainability impact reports](https://www.google.com/url?q=https://h20195.www2.hp.com/v2/GetDocument.aspx?docname%3Dc06040843&sa=D&ust=1601935360353000&usg=AOvVaw2vYwVSTsJ-DcVf5vAcvY0L) (available in multiple languages)
- Four principles of [organizational trust](https://www.google.com/url?q=https://trustedadvisor.com/trustmatters/four-principles-of-organizational-trust-how-to-make-your-company-trustworthy&sa=D&ust=1601935360354000&usg=AOvVaw1MZ0BgHu2ebvpQsVJCKEXx)

### Dispute Resolution & Grievance Procedures

It’s crucial to have a dispute resolution process in place in case issues arise both internally within an organization or externally between partner organizations. This process should be agreed to at the beginning of any partnership or employment agreement, rather than waiting until a conflict occurs.

Dispute resolution & grievance procedures best practices:

- All parties should agree to a predetermined dispute resolution process and this agreement should be recorded by parties signing a written policy
- This should include how disputes may be brought for resolution (complaint process); who adjudicates disputes; what powers the adjudicator has; what rights the complainant or disputants have; whether the dispute resolution process is binding; if there is an appeals process available
- Consider this list of different internal dispute resolution [policy options](https://www.google.com/url?q=https://nonprofitrisk.org/resources/articles/grievance-procedures-and-internal-dispute-resolution/&sa=D&ust=1601935360355000&usg=AOvVaw2ZsHMhKF4IUyePOEsv_-ag)
- Complaint reporting should take place through appropriate channels
- Employees or partners with a concern should report it to the appropriate party as identified by the organization’s dispute resolution policy
- There should be protections in place to prevent retaliation against those bringing complaints through the dispute resolution process
- Complaints should be addressed immediately and disputes should be resolved as quickly as possible
- Disputes should be resolved impartially
- Both sides of a dispute should have an opportunity to present their case and be heard
- Complaints and conflicts should be dealt with in a confidential manner
- Only the parties involved in the conflict and those necessary for the conflict resolution process (e.g. the adjudicator(s), advocates for the involved parties)
- Consider your country’s laws surrounding grievance procedures, dispute resolution, and whistleblower protections

Examples:

- [Sample conflict resolution policy](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D5%26ved%3D2ahUKEwi30Pm5-ProAhV6gnIEHSriBa4QFjAEegQIBhAB%26url%3Dhttp%253A%252F%252Fwww.governinggood.ca%252Fwp-content%252Fuploads%252F2013%252F07%252FConflict-and-Complaint-Resolution-Sample-Policy.pdf%26usg%3DAOvVaw0-TMvukwl2kVOjzcK4tMAY&sa=D&ust=1601935360356000&usg=AOvVaw18QN5AsxVRZJqQuY5a86sC)
- [Sample conflict resolution template](https://www.google.com/url?q=https://www.shrm.org/resourcesandtools/tools-and-samples/policies/pages/cms_000517.aspx&sa=D&ust=1601935360357000&usg=AOvVaw2iYnsryUhzTDbEzGWBEKfZ)
- [Model grievance procedures](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D16%26ved%3D2ahUKEwjfkJDq__roAhUNnOAKHXEIC9wQFjAPegQIBRAB%26url%3Dhttps%253A%252F%252Fknowhownonprofit.org%252Fpeople%252FBasicgrievanceprocedure.pdf%26usg%3DAOvVaw2nylUwTqRvSM4qOlYjsiLC&sa=D&ust=1601935360357000&usg=AOvVaw1tieZCsg32c7zAtel9InI6) for small organizations
- Basic elements of a [formal written grievance procedure](https://www.google.com/url?q=https://guidelinesandprinciples.org/wiki/index.php/Grievance_Policy_%2526_Procedures&sa=D&ust=1601935360358000&usg=AOvVaw3oVmJAXxukbZQ72g-sOrPP)
- Red Cross [ombudsman office information](https://www.google.com/url?q=https://www.redcross.org/about-us/who-we-are/governance/corporate-ombudsman.html&sa=D&ust=1601935360358000&usg=AOvVaw2GZrUFQRuvupTwe91DSSOE)

## Partnerships

### Selecting Trustworthy Partners

The best motto for selecting partners is ‘trust, but verify’. You want to make sure you are working with other organizations that share your values and won’t expose your organization to legal liability or reputational damage. It’s important to do your research when selecting appropriate partner organizations.

Do Your Research

- Check out potential partners’ materials and mission statements  - do you share the same general values?
- Ask questions to determine if you share the same vision and goals for a given project on which you are considering partnering
- Ask potential partners for a reference list of past organizations they have worked with or ask around in the aid community about any potential partners that you are unfamiliar with
- See what sort of reputation they have - are they known for getting projects done well and on time? Have they been transparent about the processes and results of past projects?

Examples:

- How to choose a [partner organization](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D10%26ved%3D2ahUKEwiXkY2Z3ProAhVmoHIEHSB0AWoQFjAJegQIARAB%26url%3Dhttps%253A%252F%252Fgradsoflife.org%252Fwp-content%252Fuploads%252F2017%252F06%252FHowtochooseapartner-2.pdf%26usg%3DAOvVaw2cuedUE7P8E9Lyt7N-yty0&sa=D&ust=1601935360360000&usg=AOvVaw0K7R8QDmZsX4beGLJoj7Ho)
- Institute for PR’s guidelines for [measuring trust in organizations](https://www.google.com/url?q=https://instituteforpr.org/guidelines-for-measuring-trust-in-organizations-2/&sa=D&ust=1601935360361000&usg=AOvVaw2w9PmcVgQhwlWHuw_ozYgY)

##

### Agreements with Partner Organizations

You should come to an agreement with your partner(s) before any supply chain processes take place. Agreements should be formally documented, dated, and signed by all partners involved. This OECD document presents a comprehensive guide on building [successful partnerships](https://www.google.com/url?q=https://www.oecd.org/cfe/leed/36279186.pdf&sa=D&ust=1601935360362000&usg=AOvVaw1cNS-tqTmuMJaK2v1jBqpm) which we highly recommend reading.

These agreements should consider the following elements:

- What is the aim of the partnership?
- Goals should be as specific and tangible as possible, ex. getting 500 bars of soap to X organization to distribute within Y community in Z timeframe
- Which organizations will be involved in this project or partnership?
- All organizations should know of each other: there should be no unknown intermediaries
- What are the clear roles of each organization in achieving those aims? What are your explicit expectations of each other as partners in this common goal?
- What is the timeline for each partner to fulfill their specific role?
- Ex. fundraising completed by X date, shipping by Y date, distribution by Z date
- Do all partnership organizations have equal rights? If not, has that been agreed upon and made explicitly clear?
- Which organization(s) are responsible for what costs related to the project?
- Have you agreed on a specific distribution plan?
- What are the appropriate points of contact in each organization for this project?
- What transparency methods do you agree upon to hold each other accountable throughout this project?
- Ex. weekly check-in calls, sending daily updates, using shipment tracking technology, agreeing to an internal monitoring system
- What information needs to be shared for this project? Should this information be restricted to partner organizations, or can it be shared to third parties/more broadly? What data protection considerations are relevant to the type of information being shared?
- What is the process for changing the nature or details of our agreement, if the need should arise?
- What happens if one partner wants to leave the agreement or is incapable of fulfilling their commitments under the agreement?

\*\*\*We recommend keeping copies of your general communications with partner organizations. This can help avoid confusion later on and is a way of promoting accountability

Examples:

- DG Echo [Partnership Agreement](https://www.google.com/url?q=https://www.dgecho-partners-helpdesk.eu/_media/fpa_ngo_en_131211.pdf&sa=D&ust=1601935360365000&usg=AOvVaw36A-ls4P04Ga6ekoUZo1C3) with humanitarian organizations (see this agreement in French + other DG Echo partnership materials [here](https://www.google.com/url?q=https://www.dgecho-partners-helpdesk.eu/reference_documents/start&sa=D&ust=1601935360365000&usg=AOvVaw0QwFJsvUfUEzQBfd8kvC84))
- A comparison of [partnership agreement standards](https://www.google.com/url?q=https://www.icvanetwork.org/system/files/versions/UN%2520Partnership%2520Agreement%2520Review%25201%2520June%25202015.web_.pdf&sa=D&ust=1601935360366000&usg=AOvVaw0D3L33HpM77zGLiGlabJJf) within different UN agencies
- Nonprofit [partnership models](https://www.google.com/url?q=https://www.pimgconsulting.com/s/PIMG-White-Paper-2a-Emerging-Nonprofit-Partnership-Models.pdf&sa=D&ust=1601935360367000&usg=AOvVaw136KKmRBJdTtGrO3MwkBgl)
- Nonprofit [collaboration tips](https://www.google.com/url?q=https://philanthropynewsdigest.org/columns/the-sustainable-nonprofit/why-and-how-do-nonprofits-work-together&sa=D&ust=1601935360368000&usg=AOvVaw1dELbgNZR1RB4OQZB7xp3v)

## Fundraising

### Obligations to Donors

When you accept money from external sources, you incur an additional set of obligations. It’s crucial to be fully transparent about how other people’s money is being utilized in your work. Grants and government funding tend to have their own specific requirements for funding recipients. However, it’s important to be similarly accountable to grassroots funders and community donors.

Accountability to community donors:

- Your organization should protect donor information: do not give or sell donor information to other organizations without donors’ explicit permission
- If money was raised for a specific purpose, it should only be used for that purpose. If you have a situational change where you no longer need funding for the originally intended purpose, donors should be informed and offered the choice between having their money refunded or having it used to fulfill another need in your organization
- If money is donated to a general fund, donors should be informed what purpose(s) that fund is ultimately used towards (ex. shipping X quantity of Y goods to Z community)
- If you are purchasing products with community funds, it’s especially important to ensure you’re using those funds wisely and to their greatest efficacy
- Ask other aid groups for their recommendations on which suppliers are reputable
- Shop around for different price quotes from suppliers
- It is your responsibility to monitor community-funded projects from beginning to end. Your role doesn’t end when the money is raised and spent - you owe it to your donors to monitor, follow-up, and check-in with suppliers, distributors, and other partners to ensure the funds fulfill their intended purpose
- Your organization should keep up-to-date financial records that include all donations to your organization and their intended purpose if they are tied to a specific initiative
- It’s great for community donors to be able to feel engaged from beginning to end of the project, and this engagement can help ensure accountability. We suggest:
- Sending donors regular updates throughout each stage of the supply chain process (ex. Boxes have been loaded up into trucks today and should make it to X refugee camp by Y date\!)
- These updates can be given through your social media pages or sent directly to donors - it may be worth asking donors when they donate how they would like to receive updates about your group’s work
- Including pictures with these updates is an especially great way to keep donors connected - but make sure that you’re not taking/using photos of people without their permission or including vulnerable people in these photos

\*\*\*While you are accountable to your donors, your primary responsibilities are to the vulnerable populations that your organization serves. Reconsider accepting any donations that would threaten your organization’s mission or the quality of your work.

Examples:

- YWCA West Central Michigan [‘Donor Bill of Rights’](https://www.google.com/url?q=https://www.ywcawcmi.org/get-involved/donate/donor-bill-of-rights/&sa=D&ust=1601935360372000&usg=AOvVaw15loTaYOizjPIXVFHl9xS_)
- Center for Effective Philanthropy’s [Responsibility to Donors](https://www.google.com/url?q=https://cep.org/understanding-a-nonprofits-duty-to-donors/&sa=D&ust=1601935360374000&usg=AOvVaw0zWBBYQrAqS_4-4my9ErXd)

## Purchasing

### Considerations for Buyers

It’s important to ensure that you are using your organization’s funds responsibly. This requires doing your research, and trying to get the best deal possible while remaining fair to sellers and ensuring that their production processes are socially responsible.

Supplier selection standards:

- Consider social responsibility factors when selecting suppliers, such as ensuring they do not use forced labor or child labor and are following sufficient environmental protection standards
- The U.S. Department of Labor’s [‘Sweat & Toil’ App](https://www.google.com/url?q=https://www.dol.gov/general/apps/ilab&sa=D&ust=1601935360377000&usg=AOvVaw30gpUdGZwhTdeeZXxT-Llo) gives information on child and forced labor around the world, including the labor standards of countries and a list of goods being produced with child or forced labow
- Consider if the supplier’s Code of Conduct covers areas [suggested by](https://www.google.com/url?q=https://www.dol.gov/ilab/complychain/steps/3/topic/2&sa=D&ust=1601935360378000&usg=AOvVaw03MUunhkmRbxNUcQpCTTcM) the International Labor Organization’s (ILO) core labor standards and the US Department of Labor:
- Freedom of association and collective bargaining
- Discrimination in employment
- Child labor
- Forced labor
- Compensation
- Hours of work
- Occupational safety and health, including issues such as industrial hygiene, emergency preparedness, safety equipment, sanitation, and access to food and water

Examples:

- CommScope’s [supplier evaluation process](https://www.google.com/url?q=https://www.commscope.com/corporate-responsibility-and-sustainability/supplier-responsibility/&sa=D&ust=1601935360380000&usg=AOvVaw2SaSOB9ZeHwJjq7W6RnekE) and [supplier code of conduct](https://www.google.com/url?q=https://www.commscope.com/globalassets/digizuite/3347-supplier-code-of-conduct.pdf&sa=D&ust=1601935360380000&usg=AOvVaw1B_rUUmworoHc6D18l1A6e) (in different languages [here](https://www.google.com/url?q=https://www.commscope.com/corporate-responsibility-and-sustainability/supplier-responsibility/&sa=D&ust=1601935360381000&usg=AOvVaw1T-kw7n3TWv2ECDf-u43aN))
- Johnson & Johnson [responsibility standards for suppliers](https://www.google.com/url?q=https://www.jnj.com/_document/responsibility-standards-for-suppliers?id%3D0000015e-7c9c-d575-a1ff-fddef38c0000&sa=D&ust=1601935360381000&usg=AOvVaw2sOM9Gv_-NsG9RMmG4qGSV)
- Nike [manufacturing map](https://www.google.com/url?q=http://manufacturingmap.nikeinc.com/&sa=D&ust=1601935360382000&usg=AOvVaw1G_RKBE86oER7NbjZ1FKHA) on where their products are made
- Apple releases a [Supplier Responsibility Report](https://www.google.com/url?q=https://www.newsweek.com/apple-human-rights-violations-supply-chain-double-year-reports-reveals-836247&sa=D&ust=1601935360383000&usg=AOvVaw2YUGWJaU4EVq5Lz1N80YbS) and is honest about supply chain violations

Factors to assess before purchasing goods:

- Have you been able to see or use the product, in order to ensure its quality?
- Have you researched and compared different suppliers and pricing options?
- [Supplier information management tips](https://www.google.com/url?q=https://cporising.com/2015/08/21/four-supplier-management-best-practices/&sa=D&ust=1601935360383000&usg=AOvVaw0vyzgtqXjrYxm9PUNd6qCC):
- Having detailed, accurate, and centralized supplier information is a foundational part of managing relationships with suppliers – from product scoping to payment processing.
- This information can include quotes, contracts, contact details, locations, remittance information, certifications, performance ratings, risk scores, capabilities, and category coverage.
- Tactically, collecting, verifying, cleansing, and managing supplier information can drive significant cost savings. Strategically, supplier information management can drive greater collaboration and innovation with enterprise suppliers.
- Have you asked others in the aid community for their recommendation on reliable suppliers?
- Have you asked the supplier about the potential for a discount if you buy above a certain amount of product?
- If this is an option, is there another organization that also needs these products whom you could partner with to purchase items in bulk at a discounted rate?
- Are all partners aware of the per-unit cost of each item?
- The buyer, seller, and all intermediaries involved in a purchase should be aware of the per-unit cost of each item
- Have you contacted the [The World Supply Chain Federation](https://www.google.com/url?q=https://theworldwidesupplychainfederation.com/twscf&sa=D&ust=1601935360385000&usg=AOvVaw05nzXMRHcBpYWCMTigQEXE) (TWSCF) to get average factory rates for the item(s) that you are purchasing, in order to make a more informed decision?
- Have you set a specific deadline for the production of goods? Have you determined what will happen if the goods are not available by that deadline?
- Do you have a signed, written, and dated contract? Has a copy of this contract been made available to all parties and partners?
- Can you work directly with a seller/supplier rather than going through a middleman?
- Do you have a system in place to assess supplier performance?
- Ex. Supplier Performance Management (SPM) tools: [these tools](https://www.google.com/url?q=https://cporising.com/2015/08/21/four-supplier-management-best-practices/&sa=D&ust=1601935360385000&usg=AOvVaw0-xpXQyEnstvHnB9oQn53r) “allow procurement teams to rate and grade their suppliers along a series of performance metrics to ensure that their suppliers are providing value and adhering to contract terms and agreements. Those that use SPM processes and tools can develop supplier scorecards and surveys to track supplier performance, and collaborate with internal and external stakeholders to improve performance if/when needed”

Examples:

- Transparency International’s [guide to transparency in public procurement](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D13%26ved%3D2ahUKEwjTktCE9_noAhWfgnIEHf8ODR4QFjAMegQIAxAB%26url%3Dhttps%253A%252F%252Fwww.transparency.org%252Ffiles%252Fcontent%252Factivity%252F2015_TI_G20PositionPaper_PublicProcurement.pdf%26usg%3DAOvVaw3rqsAnUUpyOeCnll4rg5ki&sa=D&ust=1601935360386000&usg=AOvVaw28pXy_pwm2ZDSAPYYQ0c9L) (meant for governments but very applicable for aid organizations as well)
- NLPA [Purchasing Processes Assessment](https://www.google.com/url?q=https://www.nextlevelpurchasing.com/articles/purchasing-processes.php&sa=D&ust=1601935360387000&usg=AOvVaw31QaqUfkUiVYWpc8qfsLd8)
- Steps to [build a transparent relationship with suppliers](https://www.google.com/url?q=https://www.cuinsight.com/transparency-suppliers-important-may-realize.html&sa=D&ust=1601935360387000&usg=AOvVaw3xoJqHRTpKHgkxPgRKI4zS) (meant for credit unions, but broadly applicable)

### Obligations Suppliers Owe to Partners

Whether a for-profit or non-profit organization, suppliers also have obligations to their partner organizations.

Best practices for suppliers:

- Be honest and up-front about pricing. You should be able to explain to exact cost breakdowns to your partners, so they know where their money is going
- If any money is being kept as profit or going to an intermediary or other organization, you need to inform your partner organizations
- Ex. to make one unit of X item, we spend 30% of cost on materials, 50% on labor, and take 20% in profit
- Ensure the quality of your goods. It is your responsibility not just to supply items, but to ensure that the items that you supply are of sufficient quality for their intended purpose
- Use socially responsible labor practices - no child labor, no trafficked labor
- Consider environmental impact in your production processes
- Have a risk management procedure in place
- [Defined as:](https://www.google.com/url?q=https://cporising.com/2015/08/21/four-supplier-management-best-practices/&sa=D&ust=1601935360389000&usg=AOvVaw2BfcXhB5UGuzQ6CV-UIP-w) the program or series of strategies used to identify, define, quantify, mitigate and manage potential risks to supply and the resulting impact they can have upon the enterprise.
- These strategies will vary by industry and location, but [general strategies](https://www.google.com/url?q=https://cporising.com/2015/08/21/four-supplier-management-best-practices/&sa=D&ust=1601935360390000&usg=AOvVaw0NcJPkx2LtKiNsc-XMxRRr) include:
- Assigning a cross functional team to lead the supply risk program (this team could include members from partner organizations and be designed to assess and mitigate risk throughout the entire supply chain process)
- This team should encompass a wide variety of perspectives and expertise
- Creating a thorough supply risk identification and assessment process
- Map out all relevant risks to your project (financial, operational, political, regulatory, reputational, etc.)
- Developing and test a crisis management process
- Staying vigilant → never ‘set it and forget it’

Examples:

- Johnson & Johnson [responsibility standards for suppliers](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D17%26ved%3D2ahUKEwidoIWF-fnoAhXIlXIEHSIWCtEQFjAQegQIBhAB%26url%3Dhttps%253A%252F%252Fwww.jnj.com%252F_document%252Fresponsibility-standards-for-suppliers%253Fid%253D0000015e-7c9c-d575-a1ff-fddef38c0000%26usg%3DAOvVaw0MEYx5RXruGVS7ywPcJR-u&sa=D&ust=1601935360392000&usg=AOvVaw1paW58sTVwn5EuvSR1QnJG)
- CommScope’s [supplier code of conduct](https://www.google.com/url?q=https://www.commscope.com/globalassets/digizuite/3347-supplier-code-of-conduct.pdf&sa=D&ust=1601935360393000&usg=AOvVaw0Zv0s-DFhud148nrG7wGOC) (in different languages [here](https://www.google.com/url?q=https://www.commscope.com/corporate-responsibility-and-sustainability/supplier-responsibility/&sa=D&ust=1601935360394000&usg=AOvVaw07yP8RKktqPyoWt26qmAgu))
- Supplier management [best practices](https://www.google.com/url?q=https://softco.com/blog/7-supplier-management-best-practices/&sa=D&ust=1601935360394000&usg=AOvVaw0xlj2QcQiFa9GHGBV31Q1R)

## Shipping

### Considerations for Shippers

Before offering shipping services, shippers should ensure that they can fulfill the needs of partnership organizations and that the materials they are shipping are not harmful to others.

Considerations before offering shipping services:

- Is the requested timeline to ship the goods realistic?
- Is anything in the proposed shipment dangerous?
- If so, have sufficient and proper precautions been taken (e.g. special packaging, warning labels, protective gear for shippers, etc.)
- Is anything in the proposed shipment illegal?
- Make sure to consider customs requirements, such as restrictions on bringing animal products and fresh fruits and vegetables across borders
- Have you checked whether political/social disruption, natural disasters, or other ongoing crises may impact shipping routes or delayed shipping timelines?

### Obligations Shippers Owe to Partners

Shipping is a crucial part of the supply chain process: coordinating shipments can be a complex endeavor and a delay in shipping (or losing track of shipments) could mean lives lost.

Best practices for shippers:

- Shipments must be delivered in the agreed upon timeframe. If there are any delays or problems that arise in shipping, you should inform your partner organizations immediately
- Provide methods of supply chain traceability, allowing other partners and potentially the public a way to track the shipment of goods by your organization
- We suggest using digital tools such as our [Shipment Coordination Tool](https://www.google.com/url?q=https://distributeaid.org/tools/%23shipments&sa=D&ust=1601935360397000&usg=AOvVaw1yeFKU8iUtQS_zPiFoQs_L) to enable you and your partners to track shipments. This is an easy way to ensure all partners are kept up-to-date with the progress of the shipments, enabling distributors to prepare to receive them, buyers to keep their donors updated, etc.
- Consider environmental concerns and attempt to alleviate environmental harms where feasible
- Are packaging materials being reused and recycled, if possible?
- Use socially responsible labor practices
- Do shipping personnel get sufficient breaks and time-off?
- Are personnel adequately trained in how to handle and manage cargo?
- Develop and implement risk management strategies
- Do you have insurance on shipments?
- Are shipments going through or into dangerous areas? If so, have appropriate risk-mitigation strategies and security practices been employed?

Examples:

- Direct Relief provides a mapping tool [on their site](https://www.google.com/url?q=https://www.directrelief.org/about/transparency/&sa=D&ust=1601935360398000&usg=AOvVaw0Kaw2r2VzgOzpHhOWwC1QD) that tracks and measures the aid they distribute
- UN Global Compact [guide to traceability](https://www.google.com/url?q=https://www.bsr.org/reports/BSR_UNGC_Guide_to_Traceability.pdf&sa=D&ust=1601935360399000&usg=AOvVaw08Zq832l9uI88YA4VOrFLy)
- TradeReady’s [risk management strategies](https://www.google.com/url?q=http://www.tradeready.ca/2018/fittskills-refresher/7-strategies-the-big-risks-international-shipping/&sa=D&ust=1601935360399000&usg=AOvVaw1tQSiXSvvj65CBYzsM2W5j) for shipping goods internationally

## Distribution

### Considerations for Distributors

It’s important to avoid the waste that can occur when a shipment reaches a distributor who realizes the shipment product is not actually needed in their community. Distributors have a responsibility to ensure that supplies are actually needed and would be used by intended populations, and that these supplies aren’t pilfered by other outside actors.

Consider the following before agreeing to be responsible for distributing supplies:

- Does the population you intend to distribute supplies to actually need those supplies?
- For example, if partners are offering free soap it would be important to consider if the population you intend to distribute to has access to clean running water - if not, the soap may not be as useful to them as an alternative like hand sanitizer
- It’s also important to create accurate estimates of how much of a product your intended population actually needs to avoid waste and ensure other communities can benefit from supply donations
- Are these supplies going where they are most needed?
- Of course it can be difficult to weigh the needs of different communities, but it’s important to generally consider if supplies are going where they are best utilized. This may be especially relevant in time-sensitive emergency/crisis situations
- Do you have the capacity to store the supplies to be distributed, if needed?
- If goods need to be stored prior to or during the course of distribution, do you have an appropriately sized storage facility? Is the storage facility safe and appropriate to store the type of supplies in question? (E.g. protection from insects and animals, security and anti-theft measures, temperature control)
- If you are distributing supplies in conjunction with other community organizations, do you have a plan in place to avoid unintentionally duplicating or overlapping distribution efforts?
- Do you have a feedback mechanism in place so that target population or community members can report any irregularities or concerns with distribution?

Examples:

- [Template](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D3%26ved%3D2ahUKEwiw-NzZrProAhUDlXIEHZlZBRkQFjACegQIAxAB%26url%3Dhttp%253A%252F%252Fwww.nationalmasscarestrategy.org%252Fwp-content%252Fuploads%252F2015%252F06%252FMulti-Agency-Distribution-of-Emergency-Supplies-Plan-Template-2015.pdf%26usg%3DAOvVaw3d53FQ3LNOM9XTmgwD1wcd&sa=D&ust=1601935360402000&usg=AOvVaw041y6zMqI2w4B-Ett0MqwQ) for Multi-Agency Distribution of Emergency Supplies
- FEMA [Distribution Management Plan](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D1%26ved%3D2ahUKEwiw-NzZrProAhUDlXIEHZlZBRkQFjAAegQIARAB%26url%3Dhttps%253A%252F%252Fwww.fema.gov%252Fmedia-library-data%252F1567005162420-6a397b542cf5a7678781414cfa4e3661%252FFEMA_Distribution_Management_Plan_Guide_EMPG_FY2019.pdf%26usg%3DAOvVaw3uaNsrGkqSHw9BPvvmCd7P&sa=D&ust=1601935360403000&usg=AOvVaw21obXMS0Djjcl6zKavQ6l0)

### Obligations Distributors Owe to Partners

Distributors are the final link in ensuring that supplies make it into the hands of the intended population(s). Distributors must ensure that goods safely reach their final destination, completing the supply chain process.

Best practices for distributors:

- If partners are offering supplies only for a specific population (ex. a donor has sponsored free hygiene products, but they are specifically supposed to go to trans women of color), you must honor those requirements and ensure that all supplies are distributed only to that population group
- Do you have a way to verify that people you are distributing supplies to are members of the target population?
- If you can’t honor these types of specific distribution requests, don’t agree to distribute the supplies
- Government corruption in a given location may mean that some of a shipment will be confiscated and thus not reach its intended population, or that a fee/bribe must be paid before goods can be distributed
- If this is the case in your area, be sure to pre-emptively inform your partners of this possibility - and let them know if this does indeed incur
- Your organization and your partner organizations should carefully [consider the trade-off involved](https://www.google.com/url?q=https://odihpn.org/magazine/corruption-in-the-ngo-world-what-it-is-and-how-to-tackle-it/&sa=D&ust=1601935360405000&usg=AOvVaw3ZpBmg-DjeY5uTZcNwLWJz) in choosing to pay and realizing that this may fuel further corruption or even fund things like armed conflict or choosing not to perpetuate this sort of corruption with the consequence that humanitarian needs may go unmet
- It’s important to keep informed of the nature and level of corruption in countries which your organization and your partners operate (for example, consider [OECD reports on corruption](https://www.google.com/url?q=https://www.oecd.org/corruption-integrity/explore/countries/&sa=D&ust=1601935360406000&usg=AOvVaw1ecxV9e6ig2WqPx5ughNfW) in different countries and Transparency International’s [Corruption Index](https://www.google.com/url?q=https://www.transparency.org/cpi2019&sa=D&ust=1601935360406000&usg=AOvVaw1SCG0kHWSsg3TrqrqUi1Uz))
- Have clear procedures in place for the receipt, storage, handling, and accounting of supplies and you should share these procedures with your partner organizations
- It is imperative that the inventory is carefully monitored and tracked to ensure it is reaching its target population and not being pilfered or misused
- Provide methods of supply chain traceability, allowing other partners and potentially the public a way to track the shipment of goods by your organization

Examples:

- CARE’s comprehensive [distribution planning guide](https://www.google.com/url?q=https://www.careemergencytoolkit.org/programme-support/19-distribution/3-distribution-planning/&sa=D&ust=1601935360408000&usg=AOvVaw1uzAS2r1hniuq2x9PAdtP2)
- Legacy SYS [warehouse and distribution best practices](https://www.google.com/url?q=https://legacyscs.com/warehouse-and-distribution-center-11-best-practices/&sa=D&ust=1601935360409000&usg=AOvVaw3jnR2TH3J8q1RQ4RuFnrJh)

## Follow Up

### Reporting Procedures

Organizational accountability does not end when supplies are distributed. It’s important to have appropriate procedures in place to report any potential wrongdoing and operational concerns.

Reporting procedure best practices:

- Reporting mechanisms must be available to all stakeholders, including an aid organization’s donors, employees, partners, and the people they serve
- Complaint processes must be made simple and accessible in order to be effective. It may be a good idea to seek feedback from the people you serve to ensure that your organization’s process is easy for them to understand and complete
- Ensure complaints are responded to in a timely manner and inform complainants what will happen after their complaint is received (e.g. they will receive a written response to their complaint within 15 days)
- Policies must be put in place to protect whistleblowers' confidentiality and shield them from retaliation
- Rather than just waiting for complaints from stakeholders, it may be helpful to proactively seek stakeholder feedback
- Surveys can be distributed to stakeholders soliciting feedback on various parts of an aid operation
- Determine the best process for making complaints and feedback ‘actionable’ within your organization, and using it to improve your organizational processes

Examples:

- Red Cross test site [grievance process](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D6%26ved%3D2ahUKEwjRxI24_froAhVpU98KHZS5AYUQFjAFegQIBxAB%26url%3Dhttps%253A%252F%252Fwww.redcross.org%252Fcontent%252Fdam%252Fredcross%252Ftraining-services%252Fcna%252Fcalifornia-cna%252FPage%25252031%252520THE%252520GRIEVANCE%252520PROCESS%252520Page%25252031.pdf%26usg%3DAOvVaw2xETmhnHtCp_ZZ7TN380Zz&sa=D&ust=1601935360413000&usg=AOvVaw2fQkQWJQ7JES94fofY4gOe)
- Non-profit [whistleblower policy suggestions](https://www.google.com/url?q=https://www.pbmares.com/a-whistleblower-policy-protects-not-for-profits/&sa=D&ust=1601935360414000&usg=AOvVaw1jqCMj7qX3t3Xz6WbWiryf)
- How to respond to [informal stakeholder complaints](https://www.google.com/url?q=https://nonprofitrisk.org/resources/articles/i-have-a-complaint/&sa=D&ust=1601935360414000&usg=AOvVaw1CsuWuNFrBw7eLzY9oThin)
- Managing [feedback from nonprofit stakeholders](https://www.google.com/url?q=https://wiredimpact.com/blog/managing-feedback-nonprofit-stakeholders/&sa=D&ust=1601935360415000&usg=AOvVaw35dR4Gg6zSTRN4WqK7fJM1)

## Additional Resources

Additional resources your organization may find useful:

- UPS [supply chain visibility](https://www.google.com/url?q=https://www.ups.com/us/es/services/knowledge-center/article.page?name%3Dsupply-chain-visibility-traceability-transparency-and-mapping-explained%26kid%3Dart16d69e3b8b6&sa=D&ust=1601935360416000&usg=AOvVaw3irpaogMuqSTzZbKFjgJVQ): traceability, transparency, and mapping explained
- BSR [supply chain leadership ladder](https://www.google.com/url?q=https://www.bsr.org/reports/BSR_Report_Supply_Chain_Leadership_Ladder_2.0.pdf&sa=D&ust=1601935360417000&usg=AOvVaw1iqDpTwJ8oPfL4DKKkRfoE)
- Harvard Business Review [steps for general supply chain transparency](https://www.google.com/url?q=https://hbr.org/2019/08/what-supply-chain-transparency-really-means&sa=D&ust=1601935360418000&usg=AOvVaw3ZZb6SuyQiWdWwmv1hK_3n)
- SupplyShift’s four elements of a [successful supply chain strategy](https://www.google.com/url?q=https://www.supplyshift.net/4-elements-of-a-successful-supply-chain-transparency-strategy/&sa=D&ust=1601935360418000&usg=AOvVaw3l1ckKRCV9RtPn5ykOA9mG)
- Supply chain management [guidelines and resources](https://www.google.com/url?q=https://managementhelp.org/operationsmanagement/supply-chain-management.htm%23distribution&sa=D&ust=1601935360419000&usg=AOvVaw1ey9E2Jge3PqHP0jBQF_Mi)
- US Department of Labor [‘Comply Chain’ App](https://www.google.com/url?q=https://www.dol.gov/general/apps/ilab-comply-chain&sa=D&ust=1601935360419000&usg=AOvVaw04NLoCHJA9Jo2UttCBwOQ4) on how to develop a social compliance system for supply chain management
- Information on how to publish your organization’s data under the I[nternational Aid Transparency Initiative](https://www.google.com/url?q=https://iatistandard.org/en/guidance/&sa=D&ust=1601935360420000&usg=AOvVaw2k4p7OqulnERFkCm5PeLSr)
- Step-by-step guide on [procurement procedures](https://www.google.com/url?q=https://www.felp.ac.uk/taxonomy/term/119&sa=D&ust=1601935360420000&usg=AOvVaw3JjiQ-ghvdoGL7a3PCPQup) (meant for universities but broadly applicable)
- Guide on [effective supply chain accountability](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D1%26cad%3Drja%26uact%3D8%26ved%3D2ahUKEwjMzqDcj_roAhVUAp0JHaMWD24QFjAAegQIAxAB%26url%3Dhttps%253A%252F%252Fwww.iccr.org%252Feffective-supply-chain-accountability-investor-guidance-implementation-california-transparency%26usg%3DAOvVaw2aE3Veqq8Qv6cWKfX_vTv8&sa=D&ust=1601935360421000&usg=AOvVaw0r5WJ_FdZpgVcM4FtfH1oz) (document discusses new California law on supply chain accountability but has helpful/generally applicable tips and guidelines - and also lots of examples of accountability practices from different companies)
- Harvard Business Review article on [aligning incentives in supply chains](https://www.google.com/url?q=https://hbr.org/2004/11/aligning-incentives-in-supply-chains&sa=D&ust=1601935360422000&usg=AOvVaw01PUurhbU5R9H0GWjF59H6)
- Red Cross [ethics, rules, and policies](https://www.google.com/url?q=https://www.google.com/url?sa%3Dt%26rct%3Dj%26q%3D%26esrc%3Ds%26source%3Dweb%26cd%3D2%26cad%3Drja%26uact%3D8%26ved%3D2ahUKEwjRxI24_froAhVpU98KHZS5AYUQFjABegQIBhAB%26url%3Dhttps%253A%252F%252Fwww.redcross.org%252Fcontent%252Fdam%252Fredcross%252Fenterprise-assets%252Fpdfs%252Fm4240154_ethics_rules_and_policies.pdf%26usg%3DAOvVaw1v4XCmrwv5zBQk0JcMq0_H&sa=D&ust=1601935360422000&usg=AOvVaw3o7SAF_ydH6cMAWqpDSeDr)
