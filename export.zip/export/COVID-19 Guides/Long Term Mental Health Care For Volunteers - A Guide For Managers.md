---
title: "Long Term Mental Health Care For Volunteers - A Guide For Managers"
driveId: 1Dd8i_50q6aBz0Ys2ji8CQ1W9vCe1Gdif2Z3JcogvCzo
mimeType: application/vnd.google-apps.document
modifiedTime: 2020-06-08T14:37:18.058Z
---

#

Resilience in a Crisis: Long Term Mental Health Care for Volunteers -  
A Guide for Managers

[Resilienc](#h.fcbhuku2qgc)[e](#h.fcbhuku2qgc)[ in a Crisis: Long Term Mental Health Care For Volunteers -  
A Guide For Managers](#h.fcbhuku2qgc)        [1](#h.fcbhuku2qgc)

##

Overview

Mental health care is a critical factor for the safe and reliable work process for your team. It requires constant attention, and now that operations are settling into their new procedures with COVID-19 , you may notice that your volunteers start showing signs of empathy burnout or compassion fatigue. Both conditions are very common for frontline workers and/or volunteers, as they are being exposed to stressful situations for long periods of time, which can severely impact your mental health and ability to function.

This guide provides some resources and general tips on resilience during stressful times.

## Building Trust

### Accountability

A culture that fosters trust, accountability, and flexibility provides a stable foundation for both mental health and resiliency. This can be accomplished by establishing a mental health plan for your organization, implementing clear structures for support, and determining how often you will check in with your team members.

Volunteers should be provided with opportunities to take care of their mental health as often as necessary. It’s in their and your best interest in the long run to ensure mental health balance where possible a volunteer who overlooks their health may be able to work two months full time and then burn out, but a volunteer who invests 30 minutes a day to several times a week for self care may be able to work for six months or more.

## Understanding the different types of stress

Empathy/Compassion Fatigue (sometimes also referred to as vicarious traumatization or secondary traumatisation):  
Emotional and physical exhaustion leading to a diminished ability to empathize or feel compassion for others.

Burnout:  
A cumulative process marked by emotional exhaustion and withdrawal associated with increased workload and institutional stress. It is not trauma related.

Primary Traumatic Stress/ Vicarious Traumatisation:  
Inherent in witnessing or experiencing extreme events, including prolonged exposure to traumatic situations that contribute to a physical and mental traumatic response. Vicarious trauma stems from helping others who have witnessed some sort of  traumatic situation or event.

![](https://lh4.googleusercontent.com/JlSGJtJkBxVYOSGSGlfZmdyrBuuyXH-N29igx0JtEpqds7snLgekjiGs3icnWLgfzzCNBSahSmRLIKa3EvG2oSpdcgCWzf5UNRlXy4VNMtvAEae5mMgzczTHSrj1GBLGHOiqXWHq)

### Symptoms to watch out for as a manager

Volunteers may exhibit gradual or a very sudden onset of symptoms. Occasional signs of one or two symptoms may stem from everyday frustrations, but if you notice many of these symptoms, you should refer to and implement your mental healthcare plan.

Symptoms:

- Inability for teams to work well together, especially if they were doing so previously
- High frequency of volunteer absenteeism
- Recurring complaints about physical symptoms such as headaches, physical exhaustion or poor sleep
- General lack of focus, disorientation, severe mood swings or apathy
- Vocalisation of feeling that the work doesn’t make enough of an impact to matter, that they are ineffective of feeling guilty about not helping enough
- Frequent changes in volunteer or manager relationship dynamics
- Frequent breaching of organisational rules
- Signs of aggression or frustration being taken out through violence, and over reaction to frustrating situations or obstacles
- Volunteers not completing assigned tasks or constantly missing deadlines
- Unwillingness or lack of flexibility
- Constant vocal negativism to managers or coordinators who issue tasks (you should note that some light complaining/grumbling among staff members about management is a very normal and not cause for concern)
- Strong reluctance/ hesitation towards changing normal operations or procedures and disbelief that improvement is possible or worth achieving
- No clear goals or vision going forward

## Listening to your volunteers and encouraging them to reach out

Volunteers only commit themselves to causes they are passionate about,  so they may be eager to commit a lot of time initially, but you should be mindful in your planning not to set them up to fail. You should:

- Schedule their work week during your weekly or daily briefings where possible so they know what to expect and what is expected from them work wise
- Set a clear daily end time or max working hours per week and ensure volunteers stick to it to create a dependency routine
- Encourage volunteers to take regular breaks throughout the day; have them set their alarm as a reminder to take a 10 minute break every hour if needed
- Clarify personal and professional boundaries - what works for them and what doesn't? Are they working too many hours or is the environment not suitable for them? Plan around their limits and change their role or tasks  if necessary
- Ensure they have a platform to express what they need verbally to you or the  operations lead so that they feel they can take a break when needed and know it’s okay when they need to walk away for the rest of the day
- Set up processes or reach out procedures that allow for clear communication as volunteers may be unwilling to approach team leads if they feel they are busy with other tasks and they don't want to interrupt or distract them
- Create a mental healthcare pack that you update and distribute/make aware to volunteers regularly with your outreach protocols, resources for mental healthcare. Ensure you outline any services your organisation provides such as access to counselling or flexible working schedules so that volunteers can change their hours themselves
- Ensure you recognise and highlight volunteer achievements regularly to promote a sense of accomplishment

##

How to prepare volunteers for mental stress

When new volunteers join your team, let them know it’s important to respond to their assignments as humans, with vocal and visual stress, sadness, frustration and anxiety. When team members are not aware that they can be vulnerable, they tend to internalise and conceal their emotions. If they understand from the start that you expect them to talk to you if they start to feel or notice certain symptoms, they will know that they can safely confide in you. Some good ways to prepare volunteers are:

- Teach stress relief strategies at volunteer onboarding. Preface any teaching with a clear acknowledgment that everyone is impacted by pain and sorrow and that awareness can work to prevent long term damage
- Encourage volunteers to focus on strengths and accomplishments rather than fears and failures
- Educate volunteers that stress presents itself in many ways and it may be hard to spot the signs. Denial is a huge factor in empathy burnout for example
- Providing them with resources which could be everything from printed materials on relaxation techniques to dedicated support sessions or socialisation activities with other volunteers such as a virtual happy hour

## Making your plan

### Enforcing mental health breaks

A tailored approach and initiative when people need support can go a long way in ensuring that your NGO's greatest asset (your volunteers) can thrive and feel secure in their environment. By having clear structures in place,  you create a space of safety and support, enabling volunteers to be more likely to approach you for help before  reaching a critical point.

Below, we provide Distribute Aid's plan which you can use as an example to build upon for your own organisation structure.

### Example plan - Distribute Aid mental health plan

Initial Assessment:

\- If they have not approached you:  
If you are concerned about a volunteer, make an assessment of signs or symptoms they’re exhibiting. Reach out confidentially to any other heads of departments that they also work with and ask if they have noticed any changes or symptoms. If they haven’t noticed, then reach out the volunteer and directly offer support.

It’s important not to paraphrase, as volunteers may be unwilling to accept help if they feel the offer is not genuine. Instead of saying, “Let me know if you need anything” clearly outline your intention, “I just wanted to check in on how you’re doing and feeling at the moment. What help or support can I give you right now?”

\-If they have approached you:

Thank them for coming to talk to you. Do not judge or try to immediately fix their feelings, listen empathetically and respond with acceptance and understanding. Do not take responsibility for how they feel, just provide the environment and tools for healing. Ensure you both have your mental health plan packet and work through it together.

Start the mental healthcare plan

1) Have the volunteer take the[ PROQOL test](https://www.google.com/url?q=https://proqol.org/uploads/ProQOL_5_English_Self-Score.pdf&sa=D&ust=1601935360169000&usg=AOvVaw2-nsXd75PhoSqld4Xbo94Z). Other languages [available here](https://www.google.com/url?q=https://proqol.org/ProQol_Test.html&sa=D&ust=1601935360170000&usg=AOvVaw2R_h130It9PLt82RQ2LEUy).

2) Try to identify if they are suffering from burnout, empathy/compassion fatigue or Primary Traumatic Stress/Vicarious Traumatisation, which will help you determine what type of response is necessary.  You may simply need to give them a temporary break for a few days, or if they are experiencing trauma , they need to be removed from operations, effective immediately and referred to a medical professional.

If you identify burnout as the most likely culprit, start by evaluating the workload. Burnout normally (but not always) stems from what is being perceived as an overwhelming, unachievable amount of work that is impossible to keep on top of.

Talk through these options:  
\- Is it possible to restructure the workload to be more manageable?  
\- Is it possible to reduce the workload to a comfortable amount?

\- Is it possible to add someone else to share responsibility and help?

If the answer to these questions is no, then determine a new approach. Putting the volunteer back into the same situation and temporarily only taking away one or two tasks will not improve their situation.

The most appropriate measure might be to temporarily withdraw them from all service to give them a chance to relax and recharge. When they do return, be sure to have a more structured plan in place.

3\) Discuss all active tasks and projects, conduct a full, in depth handover, and decide how long they should take a break, starting with one full week. Provide a clear timeframe for how long you expect them to take off work, and encourage them to make use of the resources in their downtime from the resource packets. Do not contact them during this time for any reason - this is why it’s so important to conduct the in depth handover.

4) Have them sign out of all work accounts and mute all apps on their phone and laptop, as notifications can be triggering. Set a meeting date before they sign off, to check back in seven days later,  so they can discuss how they’re feeling.

5\) After one week, check in to see how they are, and do not mention how busy work has been without them, or any struggles or complications that have occurred during their time off. Doing so may provoke a sense of guilt and make the volunteer feel that they need to come back to help out even if they aren’t ready. Discuss how their week has been, how they feel, and how their symptoms have been while on break.

Make a judgement call: if you think that they need some more time off, don’t pose it as a question - tell them very clearly that you’d like them to take another a week off, and that you will meet again next week to check in. If they haven’t been using any resources, gently encourage them again to use some of the tools you have provided.

Repeat this process of checking in until the volunteer feels ready to work. Keep in mind that it may be too formal to have a video or phone chat; instead, it might be easier for them to communicate via text or social media (for example, with a coordinator or admin who does not live on site), and offer a safe space for them to be honest about how they’re truly feeling.

6) Create a work plan for them to reintegrate into work  Decide if they should start for the first week back working half days to ease back into work, or set a cap at half their working hours per week. Highlight the areas that were causing stress before and work together to create a plan of how work is managed. Decide together if any projects or tasks should be passed on to another member of the team.

Don’t let your volunteer feel that it is an issue or that you might overburden someone else. Assure them that it’s your job to manage the workload and you will work with other team members to ensure no-one has too much to handle.

7) Check back in after the first week back with a 1:1 to see if the volunteer is happy and feeling mentally healthy. If not, begin the mental health checklist again from number two.

## Resources

### Exercises for mood lifts

#### 1-Minute Fixes

- Smile - Cheesy, but it’s true\! The act of smiling really can impact your mood.
- Jump around - Get happy-making endorphins pumping fast with some jumping jacks, jump rope, or random flailing around (hey, no judgment here).
- Sniff certain scents - Inhaling the scent of orange (or essential orange oil) or lavender can reduce anxiety and improve mood.
- Chew gum - The repetitive action of gnawing on gum can promote relaxation and reduce stress.

#### 5-Minute Fixes

- Count your blessings - Think about or write down what you are thankful for. Even if there’s not time to write down everything, expressing gratitude creates an instant mood boost.
- Listen to a happy song - It’s quick; it’s easy; it’s an instant mood lifter. Sing along for extra benefit.
- Achieve a goal - Even small successes can have big mood payoffs. Toss a crumpled ball of paper into the trash can Michael Jordan style, win a game of Solitaire, pick up a pencil off the floor using only your toes—in these moments, your team will be basking in the glory of accomplishment.
- Meditation - is a quick, effective way to chill out and improve our outlook, and it might even make us smarter. Just a few minutes of sitting quietly, focusing on the breath, and maybe chanting a few Oms (silently or out loud) can uplift your team’s mood.
- Laugh - Laughter can cheer us up and decrease anxiety—and the best news is it does not have to be “genuine” to have a positive effect. So even when it seems like there is absolutely nothing funny in all of this world, busting out a big guffaw might just change your mind.
- Notice small miracles - Cultivating positivity and a sense of wonder can build positive outlook.  Feeling stuck? Look around for small wonders (a butterfly, an act of kindness).

####

10-Minute Fixes

- Call an upbeat friend - If you want to be happy and calm, spend time around calm, happy people. If you only have a few minutes, call one of them.
- Declutter - Getting organised can help us feel instantly calmer. Just five to ten minutes is enough to tackle a small project, like organizing a desk or the kitchen.
- Celebrate good times - Look at happy photos or spend a minute or so thinking back on positive memories, as nostalgia can trigger happiness.
- Get some sun - A boost of vitamin D can keep the blues at bay. Head outside for a brisk walk around the block. If that’s not possible, station yourself near a window for a few minutes.

Full list [available here](https://www.google.com/url?q=https://greatist.com/happiness/34-ways-bust-bad-mood-ten-minutes%231&sa=D&ust=1601935360177000&usg=AOvVaw33ZAZncHhCyHbq8I2smHdj).

### Other general recommendations  

Physical exercise is a great way to relieve stress, as our bodies tend to hold onto it. When you’re feeling tense you could try:

- Consciously stretching out your body. If you have the time and access to the internet - find a short 10/20 minute yoga stretching video on YouTube
- Activity that moves your body, you could take a run or bicycle for 20 minutes, or even just put on some music and jump and dance around for a few tracks

In general you should try to keep a balanced healthy diet when you can, eat foods you enjoy and treat yourself occasionally to something special. Try to limit your alcohol consumption when working on projects that are stressful, as it can mask emotions and affect your body's ability to sleep well.  Watch some things that will make you laugh - scroll for some memes or videos that make you laugh to release good endorphins.

Both community members and volunteers may find this situation overwhelming. You can address this by providing them with access to mental health resources your operation has and encouraging them make use of online counselling tools.

###

Online Resources:

[http://champsonline.org/assets/files/ToolsProducts/OEResources/CF-Resources-Handout.pdf](https://www.google.com/url?q=http://champsonline.org/assets/files/ToolsProducts/OEResources/CF-Resources-Handout.pdf&sa=D&ust=1601935360179000&usg=AOvVaw333x1IIFOWB-CYibLXQho4)  
[https://themindfield.world/](https://www.google.com/url?q=https://themindfield.world/&sa=D&ust=1601935360180000&usg=AOvVaw2wMPUMgf0LzWDPC2EXulyW)  
[https://www.talkspace.com/](https://www.google.com/url?q=https://www.talkspace.com/&sa=D&ust=1601935360181000&usg=AOvVaw01GODu4q_NJwASNWT0lsJo)  
[https://www.bacp.co.uk/search/Therapist](https://www.google.com/url?q=https://www.bacp.co.uk/search/Therapists&sa=D&ust=1601935360181000&usg=AOvVaw1LqeHiAYaqvkD1k7HMfHHY)

Apps to manage anxiety and mood (unfortunately these apps will not necessarily work in every country):

- [Headspace](https://www.google.com/url?q=https://www.headspace.com/&sa=D&ust=1601935360182000&usg=AOvVaw2elAXkgKrrU8iOrJZABqMw) - offering premium service for free to healthcare workers + teachers (and the basic service is free to all users)
- [CalmHarm](https://www.google.com/url?q=https://calmharm.co.uk/&sa=D&ust=1601935360182000&usg=AOvVaw3SMR3NRMuavpSDAgRiimo9)
- [Calm](https://www.google.com/url?q=https://www.calm.com/&sa=D&ust=1601935360183000&usg=AOvVaw1_Tv8NC7Qnn8KHbQN6uJ66)
- [CatchIt](https://www.google.com/url?q=https://www.nhs.uk/apps-library/catch-it/&sa=D&ust=1601935360184000&usg=AOvVaw2C7hrSpxVPWYxxaoEa3slj)
- [Moodpath](https://www.google.com/url?q=https://mymoodpath.com/en/&sa=D&ust=1601935360184000&usg=AOvVaw14LAqVS1_Imy8JH7TuCya1)
- [Insight Time](https://www.google.com/url?q=https://insighttimer.com/&sa=D&ust=1601935360185000&usg=AOvVaw2vFoypzo-uRD-XMP2bwkTX)r
- [Soundcloud](https://www.google.com/url?q=https://soundcloud.com/user-68945296/sets/mindfulness-mark-williams&sa=D&ust=1601935360185000&usg=AOvVaw0ebTeEYGp3W3GDR_0kzhBp) - meditation tracts from ‘Mindfulness’ by Mark Williams and Danny Penman, Hachette Audio UK
- [Spotify](https://www.google.com/url?q=https://open.spotify.com/album/3hviXAOrmsknmItGHVdajQ&sa=D&ust=1601935360186000&usg=AOvVaw0yez4rYROsiecZi9jBVBHl) - ‘Mindful Meditations’ podcast

Apps reviewed and rated by the Anxiety and Depression Association of America:

- [https://adaa.org/finding-help/mobile-apps](https://www.google.com/url?q=https://adaa.org/finding-help/mobile-apps&sa=D&ust=1601935360187000&usg=AOvVaw1RQeaWYZMf9yAVeBLGsPlu)

List and description of other mental health apps:

- [https://www.psycom.net/25-best-mental-health-apps](https://www.google.com/url?q=https://www.psycom.net/25-best-mental-health-apps&sa=D&ust=1601935360187000&usg=AOvVaw1r1K4Rdo4sMhfzTjisN-fv)

###

Physical Health

Apps to monitor and track workouts, as well as provide motivation:

- [https://www.techradar.com/best/workout-apps](https://www.google.com/url?q=https://www.techradar.com/best/workout-apps&sa=D&ust=1601935360188000&usg=AOvVaw0epFJR61gYMis2BPnJv1dd)

Common household items that can be used in workouts:

- [https://www.bicycling.com/skills-tips/g23451830/how-to-use-household-items-to-exercise-at-home/](https://www.google.com/url?q=https://www.bicycling.com/skills-tips/g23451830/how-to-use-household-items-to-exercise-at-home/&sa=D&ust=1601935360189000&usg=AOvVaw3LzhJX5t44PpFBmn63yExx) [https://www.verywellfit.com/everyday-items-workout-use-85820](https://www.google.com/url?q=https://www.verywellfit.com/everyday-items-workout-use-85820&sa=D&ust=1601935360190000&usg=AOvVaw3D4ufSbjxdaQ1P-y_uEuda)

At home workouts:

- [https://www.youtube.com/user/blogilates/search?query=apartment](https://www.google.com/url?q=https://www.youtube.com/user/blogilates/search?query%3Dapartment&sa=D&ust=1601935360190000&usg=AOvVaw3z-DkaJWbyGP11kNPVcmrh)
- [https://www.fitnessmagazine.com/workout/lose-weight/total-body/equipment-free-at-home-workout-everyday-items/](https://www.google.com/url?q=https://www.fitnessmagazine.com/workout/lose-weight/total-body/equipment-free-at-home-workout-everyday-items/&sa=D&ust=1601935360191000&usg=AOvVaw1kEB8BLG7jlGJckFvExIjB)
- [https://www.active.com/fitness/articles/turn-your-home-into-a-gym-at-home-workout-with-household-items?page=1](https://www.google.com/url?q=https://www.active.com/fitness/articles/turn-your-home-into-a-gym-at-home-workout-with-household-items?page%3D1&sa=D&ust=1601935360192000&usg=AOvVaw1Ym6mnyeLGb6KQ8k4fvmIe)
- [https://www.youtube.com/user/yogawithadriene](https://www.google.com/url?q=https://www.youtube.com/user/yogawithadriene&sa=D&ust=1601935360192000&usg=AOvVaw3TTrn8Y6NIZxcq-gN5vXNe)
- [https://www.youtube.com/channel/UCJEi1foUiGObzzQM3QA2H5A](https://www.google.com/url?q=https://www.youtube.com/channel/UCJEi1foUiGObzzQM3QA2H5A&sa=D&ust=1601935360193000&usg=AOvVaw3uj4L1R4y4JZSAj_flQxRo) (Alo Yoga)
- [https://www.youtube.com/user/popsugartvfit](https://www.google.com/url?q=https://www.youtube.com/user/popsugartvfit&sa=D&ust=1601935360194000&usg=AOvVaw0HUwuAh3tk3oxkvn7psSlc)

At-home workout streaming services:

- [https://www.cnbc.com/2020/03/16/best-home-workout-streaming-services-to-try-during-covid-19-pandemic.html](https://www.google.com/url?q=https://www.cnbc.com/2020/03/16/best-home-workout-streaming-services-to-try-during-covid-19-pandemic.html&sa=D&ust=1601935360194000&usg=AOvVaw3OVpLWBcGnnRKKXZkuhnjU)  
  [https://www.nhs.uk/conditions/nhs-fitness-studio/](https://www.google.com/url?q=https://www.nhs.uk/conditions/nhs-fitness-studio/&sa=D&ust=1601935360195000&usg=AOvVaw092SxuqESd9wtUVEDm-hks)

Tips on working out at home:

- [https://www.webmd.com/fitness-exercise/features/no-gym-required-how-to-get-fit-at-home\#1](https://www.google.com/url?q=https://www.webmd.com/fitness-exercise/features/no-gym-required-how-to-get-fit-at-home%231&sa=D&ust=1601935360196000&usg=AOvVaw2YiqA2FCJk2d5tEfQQYt7-)
